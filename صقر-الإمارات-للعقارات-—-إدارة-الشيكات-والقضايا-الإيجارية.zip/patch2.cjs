const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace('res.json({\n      valid: true,\n      receiptNumber: receipt.receiptNumber,', 
`
    // Fetch tenant name and mask it
    let maskedTenantName = "N/A";
    if (receipt.tenantId) {
      const tenantSnap = await db.collection('tenants').doc(receipt.tenantId).get();
      if (tenantSnap.exists) {
        const tenantData = tenantSnap.data();
        const rawName = tenantData.nameEn || tenantData.nameAr || "";
        const parts = rawName.split(" ");
        if (parts.length > 0) {
          maskedTenantName = parts[0] + " " + (parts[1] ? parts[1].charAt(0) + ".****" : "****");
        }
      }
    }

    res.json({
      valid: true,
      receiptNumber: receipt.receiptNumber,
      tenantName: maskedTenantName,`);
fs.writeFileSync('server.ts', code);
