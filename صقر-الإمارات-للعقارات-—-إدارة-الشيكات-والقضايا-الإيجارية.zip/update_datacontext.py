import re

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    content = f.read()

if "dailyDeposits:" not in content:
    # 1. Import DailyDepositRecord
    if "DailyDepositRecord" not in content:
        content = content.replace("OwnerTransferRecord,", "OwnerTransferRecord,\n  DailyDepositRecord,")
    
    # 2. Add to DataContextType
    context_type_insertion = """
  dailyDeposits: DailyDepositRecord[];
  addDailyDeposit: (deposit: Omit<DailyDepositRecord, "id" | "createdAt" | "createdBy">) => Promise<{ success: boolean; error?: string; id?: string }>;
  updateDailyDeposit: (id: string, updates: Partial<DailyDepositRecord>) => Promise<{ success: boolean; error?: string }>;
"""
    content = content.replace("  ownerTransfers: OwnerTransferRecord[];", context_type_insertion + "  ownerTransfers: OwnerTransferRecord[];")
    
    # 3. Add state
    state_insertion = """
  const [dailyDeposits, setDailyDeposits] = useState<DailyDepositRecord[]>([]);
"""
    content = content.replace("  const [ownerTransfers, setOwnerTransfers] = useState<OwnerTransferRecord[]>([]);", state_insertion + "  const [ownerTransfers, setOwnerTransfers] = useState<OwnerTransferRecord[]>([]);")

    # 4. Add methods
    methods_insertion = """
  const addDailyDeposit = async (deposit: Omit<DailyDepositRecord, "id" | "createdAt" | "createdBy">) => {
    try {
      if (!currentUser) throw new Error("Unauthorized");
      const newDeposit: DailyDepositRecord = {
        ...deposit,
        id: `DEP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        createdBy: currentUser.name,
        createdAt: new Date().toISOString(),
      };
      setDailyDeposits((prev) => [...prev, newDeposit]);
      return { success: true, id: newDeposit.id };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateDailyDeposit = async (id: string, updates: Partial<DailyDepositRecord>) => {
    try {
      if (!currentUser) throw new Error("Unauthorized");
      setDailyDeposits((prev) => prev.map((d) => d.id === id ? { ...d, ...updates } : d));
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };
"""
    content = content.replace("  const addOwnerTransfer = async ", methods_insertion + "  const addOwnerTransfer = async ")
    
    # 5. Add to value
    value_insertion = """
        dailyDeposits,
        addDailyDeposit,
        updateDailyDeposit,
"""
    content = content.replace("        ownerTransfers,", value_insertion + "        ownerTransfers,")
    
    with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
        f.write(content)
    print("Updated DataContext.tsx")
else:
    print("DataContext.tsx already updated")
