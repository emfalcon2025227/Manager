import re
with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

# Fix importData loops
text = text.replace(
    'for (let i = 0; i < docsToSave.length; i += CHUNK_SIZE) {\n        const chunk = docsToSave.slice(i, i + CHUNK_SIZE);',
    'for (let i = 0; i < docsToSave.length; i += CHUNK_SIZE) {\n        const chunk = docsToSave.slice(i, i + CHUNK_SIZE);\n        const batch = writeBatch(db);'
)

# Wait, `importTenantsBatch` has something similar
text = text.replace(
    'for (let i = 0; i < docsToSave.length; i += CHUNK_SIZE) {\n        const chunk = docsToSave.slice(i, i + CHUNK_SIZE);\n        for (const item of chunk) {',
    'for (let i = 0; i < docsToSave.length; i += CHUNK_SIZE) {\n        const chunk = docsToSave.slice(i, i + CHUNK_SIZE);\n        const batch = writeBatch(db);\n        for (const item of chunk) {'
)
# Ah wait, the second replace will replace the first one if I'm not careful. I will just do regex.
