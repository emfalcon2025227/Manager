const fs = require('fs');
let code = fs.readFileSync('src/components/master/ContractPaymentCenterModal.tsx', 'utf8');

// Add file reference logic
code = code.replace(
  'const [bankName, setBankName] = useState("");',
  `const [bankName, setBankName] = useState("");
  const [attachment, setAttachment] = useState<{fileName: string, driveFileId?: string, driveWebViewLink?: string} | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  
  const handleFileAttach = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAttachment({
      fileName: file.name,
      driveWebViewLink: URL.createObjectURL(file) // Mock for preview
    });
  };`
);

// Add the attachment in the submit object
code = code.replace(
  'chequeDate\n      } : undefined',
  `chequeDate\n      } : undefined,\n      attachment: attachment ? attachment : undefined`
);

// Add the file upload UI
const uiUpload = `
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                  {language === "ar" ? "المرفقات (إيصال/شيك)" : "Attachments (Receipt/Cheque)"}
                </label>
                <div className="flex items-center gap-2">
                  <input type="file" ref={fileInputRef} onChange={handleFileAttach} className="hidden" />
                  <button type="button" onClick={() => fileInputRef.current?.click()} className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50">
                    Upload File
                  </button>
                  {attachment && <span className="text-xs text-slate-500 font-mono truncate max-w-[200px]">{attachment.fileName}</span>}
                </div>
              </div>
`;

code = code.replace(
  `              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                  {language === "ar" ? "رقم المرجع (اختياري)" : "Reference #"}
                </label>
                <input type="text" value={referenceNumber} onChange={(e) => setReferenceNumber(e.target.value)} className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs" />
              </div>`,
  `              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                  {language === "ar" ? "رقم المرجع (اختياري)" : "Reference #"}
                </label>
                <input type="text" value={referenceNumber} onChange={(e) => setReferenceNumber(e.target.value)} className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs" />
              </div>
              ${uiUpload}`
);

fs.writeFileSync('src/components/master/ContractPaymentCenterModal.tsx', code);
