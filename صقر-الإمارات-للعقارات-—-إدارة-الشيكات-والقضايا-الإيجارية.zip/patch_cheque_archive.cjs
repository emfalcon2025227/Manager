const fs = require('fs');
let code = fs.readFileSync('src/components/cheques/AddChequeModal.tsx', 'utf8');

// Add addArchiveItem
code = code.replace(/extractChequeOCR,\n    linkChequesToCase,\n  } = useData\(\);/, `extractChequeOCR,
    linkChequesToCase,
    addArchiveItem,
  } = useData();`);

// Add state
const stateInsertion = `
  const [smartCaptureArchiveDoc, setSmartCaptureArchiveDoc] = useState<{ base64: string, mime: string } | null>(null);
`;
code = code.replace(/const \[isSmartCaptureOpen, setIsSmartCaptureOpen\] = useState\(false\);/, "const [isSmartCaptureOpen, setIsSmartCaptureOpen] = useState(false);\n" + stateInsertion);

// Modify handler
const handlerOld = `const handleSmartCaptureApprove = (result: any, imageBase64: string, mimeType: string) => {`;
const handlerNew = `const handleSmartCaptureApprove = (result: any, imageBase64: string, mimeType: string, saveToArchive: boolean) => {
    if (saveToArchive) {
      setSmartCaptureArchiveDoc({ base64: imageBase64, mime: mimeType });
    } else {
      setSmartCaptureArchiveDoc(null);
    }`;
code = code.replace(handlerOld, handlerNew);

// Add to commitSave
const commitSaveOld = `const newChq = addCheque(`;
const commitSaveNew = `const newChq = addCheque(`;
// wait, the function returns a new cheque, so I need to find `const newChq = addCheque(` and add code after it. But what if it's `addCheque({ ... })` and doesn't assign to `newChq`?

