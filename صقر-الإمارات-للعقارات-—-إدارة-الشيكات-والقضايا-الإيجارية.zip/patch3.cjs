const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Add import
if (!code.includes('PublicReceiptVerification')) {
  code = code.replace(
    'import { CollectionRecord } from "./types";',
    'import { CollectionRecord } from "./types";\nimport { PublicReceiptVerification } from "./components/public/PublicReceiptVerification";'
  );
}

// 2. Add route handling in App()
const routerCode = `
export default function App() {
  const path = window.location.pathname;
  if (path.startsWith("/verify/receipt/")) {
    const token = path.replace("/verify/receipt/", "");
    return (
      <ErrorBoundary>
        <LanguageProvider>
          <PublicReceiptVerification token={token} />
        </LanguageProvider>
      </ErrorBoundary>
    );
  }

  return (
`;

code = code.replace('export default function App() {\n  return (', routerCode);

fs.writeFileSync('src/App.tsx', code);
