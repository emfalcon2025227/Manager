const fs = require('fs');
let file = 'src/components/settings/SettingsView.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/useState<RiskWeightSettings>\(riskWeights\);/g, 'useState<RiskWeightSettings>(riskWeights || { bouncedCheques: 40, paymentDelays: 30, legalCases: 30 });');
content = content.replace(/e\.preventDefault\(\);/g, 'e?.preventDefault?.();');

fs.writeFileSync(file, content);
