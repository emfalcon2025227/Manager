const fs = require("fs");
async function test() {
  try {
    const res = await fetch("http://localhost:3000/api/ocr/v2/extract", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        documentType: "EMIRATES_ID",
        imagePayload: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
        mimeType: "image/png",
        model: "accurate",
        prompt: "Extract Emirates ID document fields..."
      })
    });
    console.log("Status:", res.status);
    const json = await res.json();
    console.log("Response:", JSON.stringify(json, null, 2));
  } catch (e) {
    console.error("Fetch error:", e);
  }
}
test();
