const fs = require('fs');
const path = 'src/components/emiratesId/EmiratesIdScannerModal.tsx';
let content = fs.readFileSync(path, 'utf8');

const target = `
      if (ocrResult.success && ocrResult.data) {
        const fullOcrData: EmiratesIdData = {
          emiratesIdNumber: ocrResult.data.emiratesIdNumber || "784-XXXX-XXXXXXX-X",
          fullName: ocrResult.data.fullName || "Extracted Name",
          arabicName: ocrResult.data.arabicName || "الاسم المستخرج",
          englishName: ocrResult.data.englishName || "Extracted Name",
          dateOfBirth: ocrResult.data.dateOfBirth || "1990-01-01",
          gender: ocrResult.data.gender || "MALE",
          nationality: ocrResult.data.nationality || "Other",
          cardNumber: ocrResult.data.cardNumber || "000000",
          issueDate: ocrResult.data.issueDate || "2024-01-01",
          expiryDate: ocrResult.data.expiryDate || "2029-01-01",
          identitySource: "OCR",
          verificationStatus: "UNVERIFIED",
          captureDate: new Date().toISOString(),
          readerInformation: "OCR Extractor Model",
        };
`.trim();

const replacement = `
      if (ocrResult.success && ocrResult.data) {
        const fullOcrData: EmiratesIdData = {
          emiratesIdNumber: ocrResult.data.emiratesIdNumber || "",
          fullName: ocrResult.data.fullName || "",
          arabicName: ocrResult.data.arabicName || "",
          englishName: ocrResult.data.englishName || "",
          dateOfBirth: ocrResult.data.dateOfBirth || "",
          gender: ocrResult.data.gender || "",
          nationality: ocrResult.data.nationality || "",
          cardNumber: ocrResult.data.cardNumber || "",
          issueDate: ocrResult.data.issueDate || "",
          expiryDate: ocrResult.data.expiryDate || "",
          identitySource: "OCR",
          verificationStatus: "UNVERIFIED",
          captureDate: new Date().toISOString(),
          readerInformation: ocrResult.data.readerInformation || "OCR V2 Model",
        };
`.trim();

if(content.includes(target)) {
    content = content.replace(target, replacement);
    fs.writeFileSync(path, content, 'utf8');
    console.log("Success");
} else {
    console.log("Target not found");
}
