const fs = require('fs');
let content = fs.readFileSync('src/components/financials/FinancialReportsView.tsx', 'utf8');

// 1. Change the VAT data generation
const targetVatGen = `              category: "VAT_INPUT",
              vatAmount: calculatedVAT,
              debit: exp.amount, // Taxable Base
              credit: calculatedVAT, // VAT Amount
              balance: exp.amount + calculatedVAT, // Total with VAT`;

const replacementVatGen = `              category: "VAT_INPUT",
              taxableBase: exp.amount,
              vatRate: vatRateUsed,
              vatAmount: calculatedVAT,
              taxDirection: "INPUT_VAT",
              debit: exp.amount,
              credit: calculatedVAT,
              balance: exp.amount + calculatedVAT,`;

content = content.replace(targetVatGen, replacementVatGen);

const targetVatGen2 = `              category: "VAT_OUTPUT",
              vatAmount: com.vatAmount || 0,
              debit: com.netRevenueAmount || com.totalCommissionAmount - (com.vatAmount || 0), // Taxable Base
              credit: com.vatAmount || 0, // VAT Amount
              balance: com.totalCommissionAmount, // Total`;

const replacementVatGen2 = `              category: "VAT_OUTPUT",
              taxableBase: com.netRevenueAmount || com.totalCommissionAmount - (com.vatAmount || 0),
              vatRate: vRate,
              vatAmount: com.vatAmount || 0,
              taxDirection: "OUTPUT_VAT",
              debit: com.netRevenueAmount || com.totalCommissionAmount - (com.vatAmount || 0),
              credit: com.vatAmount || 0,
              balance: com.totalCommissionAmount,`;

content = content.replace(targetVatGen2, replacementVatGen2);

// 2. Change the table rendering
const targetTable = `                        <tr>
                          <th className="px-4 py-3 print:px-2 print:py-1.5 whitespace-nowrap">{isAr ? "التاريخ" : "Date"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5 whitespace-nowrap">{isAr ? "المرجع" : "Ref"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5">{isAr ? "بيانات الطرف والعقار والوحدة" : "Party, Property & Unit Details"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5">{isAr ? "البيان والتفاصيل" : "Description"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "مدين (AED)" : "Debit"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "دائن (AED)" : "Credit"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "الرصيد (AED)" : "Balance"}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {group.items.length > 0 ? (
                          group.items.map((item, idx) => (
                            <tr key={item.id || idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                              <td className="px-4 py-3 print:px-2 print:py-1.5 font-mono text-slate-600 dark:text-slate-400 whitespace-nowrap">
                                {item.date || "-"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 font-mono text-slate-500 whitespace-nowrap">
                                {item.reference || "-"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 font-mono text-indigo-600 dark:text-indigo-400 font-semibold line-clamp-2 print:line-clamp-none">
                                {item.entityDetails || "---"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 text-slate-900 dark:text-white font-medium line-clamp-2 print:line-clamp-none">
                                {item.description}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-rose-600 whitespace-nowrap">
                                {item.debit > 0 ? item.debit.toLocaleString() : "-"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-emerald-600 whitespace-nowrap">
                                {item.credit > 0 ? item.credit.toLocaleString() : "-"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-slate-700 dark:text-slate-300 font-bold whitespace-nowrap">
                                {item.balance ? item.balance.toLocaleString() : "-"}
                              </td>
                            </tr>`;

const replacementTable = `                        <tr>
                          <th className="px-4 py-3 print:px-2 print:py-1.5 whitespace-nowrap">{isAr ? "التاريخ" : "Date"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5 whitespace-nowrap">{isAr ? "المرجع" : "Ref"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5">{isAr ? "بيانات الطرف والعقار والوحدة" : "Party, Property & Unit Details"}</th>
                          <th className="px-4 py-3 print:px-2 print:py-1.5">{isAr ? "البيان والتفاصيل" : "Description"}</th>
                          {selectedReportId === "vat_tax_report" ? (
                            <>
                              <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "الاتجاه الضريبي" : "Tax Direction"}</th>
                              <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "الوعاء الضريبي" : "Taxable Base"}</th>
                              <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "النسبة" : "Rate"}</th>
                              <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "قيمة الضريبة" : "VAT Amount"}</th>
                            </>
                          ) : (
                            <>
                              <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "مدين (AED)" : "Debit"}</th>
                              <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "دائن (AED)" : "Credit"}</th>
                              <th className="px-4 py-3 print:px-2 print:py-1.5 text-right whitespace-nowrap">{isAr ? "الرصيد (AED)" : "Balance"}</th>
                            </>
                          )}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {group.items.length > 0 ? (
                          group.items.map((item, idx) => (
                            <tr key={item.id || idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                              <td className="px-4 py-3 print:px-2 print:py-1.5 font-mono text-slate-600 dark:text-slate-400 whitespace-nowrap">
                                {item.date || "-"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 font-mono text-slate-500 whitespace-nowrap">
                                {item.reference || "-"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 font-mono text-indigo-600 dark:text-indigo-400 font-semibold line-clamp-2 print:line-clamp-none">
                                {item.entityDetails || "---"}
                              </td>
                              <td className="px-4 py-3 print:px-2 print:py-1.5 text-slate-900 dark:text-white font-medium line-clamp-2 print:line-clamp-none">
                                {item.description}
                              </td>
                              {selectedReportId === "vat_tax_report" ? (
                                <>
                                  <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono whitespace-nowrap">
                                    <span className={\`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold \${item.taxDirection === 'OUTPUT_VAT' ? 'bg-indigo-50 text-indigo-700' : 'bg-emerald-50 text-emerald-700'}\`}>
                                      {item.taxDirection === 'OUTPUT_VAT' ? (isAr ? "ضريبة مخرجات" : "OUTPUT VAT") : (isAr ? "ضريبة مدخلات" : "INPUT VAT")}
                                    </span>
                                  </td>
                                  <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-slate-700 whitespace-nowrap">
                                    {(item.taxableBase || 0).toLocaleString()}
                                  </td>
                                  <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-slate-500 whitespace-nowrap">
                                    {item.vatRate}%
                                  </td>
                                  <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                                    {(item.vatAmount || 0).toLocaleString()}
                                  </td>
                                </>
                              ) : (
                                <>
                                  <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-rose-600 whitespace-nowrap">
                                    {item.debit > 0 ? item.debit.toLocaleString() : "-"}
                                  </td>
                                  <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-emerald-600 whitespace-nowrap">
                                    {item.credit > 0 ? item.credit.toLocaleString() : "-"}
                                  </td>
                                  <td className="px-4 py-3 print:px-2 print:py-1.5 text-right font-mono text-slate-700 dark:text-slate-300 font-bold whitespace-nowrap">
                                    {item.balance ? item.balance.toLocaleString() : "-"}
                                  </td>
                                </>
                              )}
                            </tr>`;

content = content.replace(targetTable, replacementTable);
fs.writeFileSync('src/components/financials/FinancialReportsView.tsx', content);
console.log("Patch applied to FinancialReportsView.");
