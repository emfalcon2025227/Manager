const fs = require('fs');

// Fix server.ts (add explicit typing to (req, res))
let serverCode = fs.readFileSync('server.ts', 'utf8');
serverCode = serverCode.replace(/import \{ startScheduler, runBackup, runRestore \} from "\.\/server\/backupService";/g, 'import { startScheduler, runBackup, runRestore } from "./src/server-utils/backupService";');
fs.writeFileSync('server.ts', serverCode);

console.log("Imports fixed.");
