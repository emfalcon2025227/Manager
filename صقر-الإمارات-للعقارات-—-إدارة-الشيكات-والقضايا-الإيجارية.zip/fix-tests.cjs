const fs = require('fs');
let file = 'src/utils/phase24OperationalIntelligenceTests.ts';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/mockDoc\.driveWebViewLink\.includes/g, 'mockDoc.driveWebViewLink?.includes');

fs.writeFileSync(file, content);

let file2 = 'src/tests/phase2FinancialTests.ts';
let content2 = fs.readFileSync(file2, 'utf8');
content2 = content2.replace(/adminFee\.vatAmount/g, '(adminFee.vatAmount || 0)');
fs.writeFileSync(file2, content2);
