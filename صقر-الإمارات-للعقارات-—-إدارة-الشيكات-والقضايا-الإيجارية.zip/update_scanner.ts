import fs from 'fs';

const scannerModalCode = `import React, { useState, useEffect, useRef } from "react";
import { Camera, RefreshCw, Check, AlertCircle, Settings, Shield, Sliders, Maximize2, RotateCw } from "lucide-react";
import { Modal } from "../common/Modal";
import { scannerService, ScannerDevice } from "../../services/scannerService";
import { useLanguage } from "../../context/LanguageContext";

export interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanComplete: (imageBase64: string, mimeType: string) => void;
  documentType?: string;
}

export const ScannerModal: React.FC<ScannerModalProps> = ({
  isOpen,
  onClose,
  onScanComplete,
  documentType,
}) => {
  const { language } = useLanguage();
  const isAr = language === "ar";
  
  const [devices, setDevices] = useState<ScannerDevice[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  
  // Settings
  const [resolutionDpi, setResolutionDpi] = useState<number>(300);
  const [colorMode, setColorMode] = useState<"COLOR" | "GRAYSCALE" | "MONO">("COLOR");
  const [autoCrop, setAutoCrop] = useState<boolean>(true);
  const [paperSize, setPaperSize] = useState<string>("A4");
  
  // State
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatusMsg, setScanStatusMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Webcam fallback for visual feedback before scan
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);

  // Result
  const [scanResult, setScanResult] = useState<{ imageBase64: string, mimeType: string } | null>(null);
  const [rotation, setRotation] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadDevices();
      startCamera();
      setScanResult(null);
      setRotation(0);
      setIsFullscreen(false);
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [isOpen]);

  const loadDevices = async () => {
    const list = await scannerService.getAvailableScanners();
    setDevices(list);
    if (list.length > 0) {
      setSelectedDeviceId(list[0].id);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "environment", width: { ideal: 1920 }, height: { ideal: 1080 } } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
      }
    } catch (err) {
      console.warn("Camera not available for preview:", err);
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const handleExecuteScan = async () => {
    setIsScanning(true);
    setErrorMsg(null);
    setScanResult(null);
    setRotation(0);
    setScanStatusMsg(isAr ? "جاري الاتصال بالماسح الضوئي..." : "Connecting to scanner...");

    try {
      // Simulate scan process delay for UX
      await new Promise((resolve) => setTimeout(resolve, 800));
      setScanStatusMsg(isAr ? "جاري مسح المستند..." : "Scanning document...");
      
      const scanRes = await scannerService.acquireScan({
        deviceId: selectedDeviceId,
        resolutionDpi,
        colorMode,
        autoCrop,
      });

      if (scanRes.success && scanRes.imageBase64) {
        setScanResult({ imageBase64: scanRes.imageBase64, mimeType: scanRes.mimeType });
      } else {
        throw new Error(scanRes.error || (isAr ? "تعذر الاتصال بالماسح الضوئي." : "Could not connect to scanner."));
      }
    } catch (err: any) {
      setErrorMsg(
        err?.message ||
          (isAr
            ? "تعذر الاتصال بالماسح الضوئي."
            : "Could not connect to scanner.")
      );
    } finally {
      setIsScanning(false);
    }
  };

  const handleConfirm = () => {
    if (scanResult) {
      // We pass the base64 to the consumer
      onScanComplete(scanResult.imageBase64, scanResult.mimeType);
      onClose();
    }
  };

  const handleRescan = () => {
    setScanResult(null);
    setRotation(0);
    setErrorMsg(null);
  };

  // Safe UI texts based on documentType
  const getDocTypeName = () => {
    if (!documentType) return isAr ? "مستند عام" : "General Document";
    switch(documentType) {
      case "CHEQUE": return isAr ? "شيك بنكي" : "Bank Cheque";
      case "EMIRATES_ID": return isAr ? "بطاقة هوية" : "Emirates ID";
      case "PASSPORT": return isAr ? "جواز سفر" : "Passport";
      case "CONTRACT": 
      case "LEASE": return isAr ? "عقد إيجار" : "Lease Contract";
      case "RECEIPT": return isAr ? "إيصال دفع" : "Payment Receipt";
      default: return documentType;
    }
  };

  // Re-export as DocumentScannerModal to preserve standard naming (alias)
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isAr ? "ماسح المستندات (Universal Document Scanner)" : "Universal Document Scanner"}
    >
      <div className={\`flex flex-col text-slate-800 \${isFullscreen ? "fixed inset-4 z-50 bg-white dark:bg-slate-900 rounded-xl shadow-2xl p-4 overflow-auto" : "space-y-4"}\`}>
        {isFullscreen && (
           <div className="flex justify-between items-center mb-4">
             <h2 className="text-xl font-bold dark:text-white">{isAr ? "ماسح المستندات" : "Document Scanner"}</h2>
             <button onClick={() => setIsFullscreen(false)} className="px-4 py-2 bg-slate-200 dark:bg-slate-700 rounded-lg text-sm">{isAr ? "إغلاق وضع ملء الشاشة" : "Close Fullscreen"}</button>
           </div>
        )}
        
        {/* Header & Subtitle */}
        {!isFullscreen && (
          <div className="bg-slate-900 text-white p-3 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-blue-400" />
              <div className="flex flex-col">
                <span className="font-bold">
                  {isAr ? "محرك المسح الشامل للمستندات" : "Universal Scanner Engine"}
                </span>
                <span className="text-slate-400 text-[10px]">
                  {isAr ? "مسح الشيكات والمستندات والهوية والعقود وغيرها" : "Scan cheques, IDs, A4 documents, and more"}
                </span>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <span className="px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded font-mono font-bold mb-1">
                {isAr ? "متصل ومعتمد" : "READY"}
              </span>
              <span className="text-[10px] text-slate-400">
                {isAr ? "نوع المستند المستهدف:" : "Target Type:"} <strong className="text-white">{getDocTypeName()}</strong>
              </span>
            </div>
          </div>
        )}

        {/* Settings Controls (Only show if not in fullscreen or if we want them in fullscreen, let's keep them always but compact) */}
        {!scanResult && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
            <div className="col-span-2 md:col-span-1">
              <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">
                {isAr ? "الماسح المتاح" : "Device"}
              </label>
              <select
                value={selectedDeviceId}
                onChange={(e) => setSelectedDeviceId(e.target.value)}
                disabled={isScanning}
                className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg p-1.5 font-medium dark:text-white"
              >
                {devices.map((dev) => (
                  <option key={dev.id} value={dev.id}>
                    {dev.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">
                {isAr ? "حجم الورق" : "Paper Size"}
              </label>
              <select
                value={paperSize}
                onChange={(e) => setPaperSize(e.target.value)}
                disabled={isScanning}
                className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg p-1.5 font-medium dark:text-white"
              >
                <option value="A4">A4</option>
                <option value="ID">{isAr ? "بطاقة (ID)" : "ID Card"}</option>
                <option value="CHEQUE">{isAr ? "شيك (Cheque)" : "Cheque"}</option>
                <option value="AUTO">{isAr ? "تلقائي (Auto)" : "Auto"}</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">
                {isAr ? "دقة المسح" : "DPI"}
              </label>
              <select
                value={resolutionDpi}
                onChange={(e) => setResolutionDpi(Number(e.target.value))}
                disabled={isScanning}
                className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg p-1.5 font-medium dark:text-white"
              >
                <option value={200}>200 DPI</option>
                <option value={300}>300 DPI</option>
                <option value={600}>600 DPI</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">
                {isAr ? "اللون" : "Color"}
              </label>
              <select
                value={colorMode}
                onChange={(e) => setColorMode(e.target.value as any)}
                disabled={isScanning}
                className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg p-1.5 font-medium dark:text-white"
              >
                <option value="COLOR">{isAr ? "ألوان (Color)" : "Color"}</option>
                <option value="GRAYSCALE">{isAr ? "تدرج رمادي" : "Grayscale"}</option>
                <option value="MONO">{isAr ? "أبيض وأسود" : "B&W"}</option>
              </select>
            </div>
            <div className="flex items-end pb-0.5">
              <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300 font-bold">
                <input 
                  type="checkbox" 
                  checked={autoCrop} 
                  onChange={(e) => setAutoCrop(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" 
                />
                {isAr ? "قص تلقائي" : "Auto Crop"}
              </label>
            </div>
          </div>
        )}

        {/* Live Framing & Scanning Viewport */}
        <div className={\`relative w-full \${isFullscreen ? "flex-1 min-h-[60vh]" : "h-[60vh] max-h-[500px] min-h-[300px]"} bg-slate-950 rounded-2xl overflow-hidden border-2 border-slate-800 flex items-center justify-center transition-all\`}>
          
          {/* Controls Overlay */}
          {scanResult && (
             <div className="absolute top-4 right-4 flex gap-2 z-30">
               <button onClick={() => setRotation(r => r - 90)} className="bg-black/60 p-2 rounded-lg text-white hover:bg-black/80 backdrop-blur" title={isAr ? "تدوير يسار" : "Rotate Left"}><RotateCw className="w-5 h-5 -scale-x-100" /></button>
               <button onClick={() => setRotation(r => r + 90)} className="bg-black/60 p-2 rounded-lg text-white hover:bg-black/80 backdrop-blur" title={isAr ? "تدوير يمين" : "Rotate Right"}><RotateCw className="w-5 h-5" /></button>
               {!isFullscreen && (
                  <button onClick={() => setIsFullscreen(true)} className="bg-black/60 p-2 rounded-lg text-white hover:bg-black/80 backdrop-blur" title={isAr ? "ملء الشاشة" : "Fullscreen"}><Maximize2 className="w-5 h-5" /></button>
               )}
             </div>
          )}

          {!scanResult ? (
            cameraActive ? (
              <video
                ref={videoRef}
                playsInline
                muted
                className="w-full h-full object-cover opacity-60"
              />
            ) : (
              <div className="text-center p-6 text-slate-400">
                <Camera className="w-12 h-12 mx-auto mb-2 text-slate-600 animate-pulse" />
                <p className="text-xs font-medium">
                  {isAr
                    ? "الماسح الضوئي جاهز للبدء. ثبّت المستند واضغط على بدء المسح."
                    : "Scanner device ready. Align document and click Start Scan."}
                </p>
              </div>
            )
          ) : (
            <img 
               src={scanResult.imageBase64} 
               alt="Scanned Document" 
               className="w-full h-full object-contain transition-transform duration-300" 
               style={{ transform: \`rotate(\${rotation}deg)\` }}
            />
          )}

          {/* Dynamic Framing Guide Box based on Paper Size */}
          {!scanResult && !isScanning && (
            <div className={\`absolute \${paperSize === 'A4' ? 'inset-y-4 inset-x-12' : paperSize === 'ID' ? 'inset-y-24 inset-x-20' : 'inset-y-20 inset-x-8'} border-2 border-dashed border-blue-400/70 rounded-xl pointer-events-none flex flex-col justify-between p-3 transition-all duration-500\`}>
              <div className="flex justify-between items-center text-[10px] text-blue-300 font-mono bg-slate-950/70 px-2 py-0.5 rounded backdrop-blur">
                <span>{paperSize} BOUNDARY</span>
                <span>{resolutionDpi} DPI ALIGNED</span>
              </div>
              <div className="text-center text-[11px] text-blue-200 font-bold bg-slate-950/70 px-3 py-1 rounded backdrop-blur self-center">
                {isAr ? "ضع المستند داخل الإطار المخصص" : "Align document inside standard bounding frame"}
              </div>
              <div className="text-right text-[10px] text-blue-300 font-mono bg-slate-950/70 px-2 py-0.5 rounded backdrop-blur self-end">
                UNIVERSAL SCAN
              </div>
            </div>
          )}

          {/* Scanning Overlay State */}
          {isScanning && (
            <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center text-white z-20 space-y-3">
              <RefreshCw className="w-10 h-10 text-blue-400 animate-spin" />
              <p className="font-bold text-sm text-blue-300">{scanStatusMsg}</p>
              <div className="w-48 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 animate-pulse w-full"></div>
              </div>
            </div>
          )}
        </div>
        <canvas ref={canvasRef} className="hidden" />

        {/* Quality indicator / Info */}
        {scanResult && !errorMsg && (
          <div className="bg-emerald-50 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 p-2 rounded-lg text-xs flex justify-between items-center px-4">
             <span className="font-medium">{isAr ? "جودة المسح الضوئي مقبولة" : "Acceptable Scan Quality"}</span>
             <span className="font-mono text-[10px] opacity-70">A4 • {resolutionDpi} DPI • {colorMode}</span>
          </div>
        )}

        {/* Error Notification */}
        {errorMsg && (
          <div className="p-3 bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-300 rounded-xl text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold mb-0.5">
                {isAr ? "تنبيه الماسح الضوئي" : "Scanner Alert"}
              </p>
              <p>{errorMsg}</p>
            </div>
          </div>
        )}

        {/* Action Controls */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            disabled={isScanning}
            className="px-4 py-2 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-xs font-bold transition-all"
          >
            {isAr ? "إلغاء" : "Cancel"}
          </button>
          
          <div className="flex gap-2">
             {!scanResult ? (
                <button
                  type="button"
                  onClick={handleExecuteScan}
                  disabled={isScanning}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-blue-600/20 transition-all disabled:opacity-50"
                >
                  {isScanning ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>{isAr ? "جاري تشغيل الماسح الضوئي..." : "Scanning Hardware..."}</span>
                    </>
                  ) : (
                    <>
                      <Camera className="w-4 h-4" />
                      <span>{isAr ? "بدء المسح الضوئي" : "Start Scan"}</span>
                    </>
                  )}
                </button>
             ) : (
                <>
                  <button
                    type="button"
                    onClick={handleRescan}
                    className="px-4 py-2.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-2 transition-all"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>{isAr ? "إعادة المسح" : "Rescan"}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirm}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition-all"
                  >
                    <Check className="w-4 h-4" />
                    <span>{isAr ? "تأكيد المستند" : "Confirm Document"}</span>
                  </button>
                </>
             )}
          </div>
        </div>
      </div>
    </Modal>
  );
};

export const DocumentScannerModal = ScannerModal;
`
fs.writeFileSync('src/components/cheques/ScannerModal.tsx', scannerModalCode);
