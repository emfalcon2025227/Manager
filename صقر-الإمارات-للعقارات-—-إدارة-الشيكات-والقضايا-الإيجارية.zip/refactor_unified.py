import re

with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

# Make processUnifiedPayment async
text = text.replace(
    "const processUnifiedPayment = (params: {",
    "const processUnifiedPayment = async (params: {"
)
text = text.replace(
    "}): { success: boolean; receipt?: CollectionRecord; error?: string } => {",
    "}): Promise<{ success: boolean; receipt?: CollectionRecord; error?: string }> => {\n    const batch = writeBatch(db);"
)
text = text.replace(
    "safeSetDoc(doc(db, \"cheques\", newChq.id), newChq);",
    "batch.set(doc(db, \"cheques\", newChq.id), sanitizeForFirestore(newChq));"
)
text = text.replace(
    "safeSetDoc(doc(db, \"collections\", receipt.id), receipt);",
    "batch.set(doc(db, \"collections\", receipt.id), sanitizeForFirestore(receipt));"
)
text = text.replace(
    "safeSetDoc(doc(db, \"payment_allocations\", alloc.id), alloc);",
    "batch.set(doc(db, \"payment_allocations\", alloc.id), sanitizeForFirestore(alloc));"
)
text = text.replace(
    "safeSetDoc(doc(db, \"commissions\", c.id), updatedCom, { merge: true });",
    "batch.set(doc(db, \"commissions\", c.id), sanitizeForFirestore(updatedCom), { merge: true });"
)
text = text.replace(
    "safeSetDoc(doc(db, \"cheques\", c.id), updatedChq, { merge: true });",
    "batch.set(doc(db, \"cheques\", c.id), sanitizeForFirestore(updatedChq), { merge: true });"
)
text = text.replace(
    "safeSetDoc(doc(db, \"leases\", l.id), updatedLease, { merge: true });",
    "batch.set(doc(db, \"leases\", l.id), sanitizeForFirestore(updatedLease), { merge: true });"
)
text = text.replace(
    "safeSetDoc(doc(db, \"cheques\", c.id), updated, { merge: true });",
    "batch.set(doc(db, \"cheques\", c.id), sanitizeForFirestore(updated), { merge: true });"
)

# And add await batch.commit() before return { success: true, receipt };
text = text.replace(
    "return { success: true, receipt };",
    "await batch.commit();\n    return { success: true, receipt };"
)

# Same for liquidateUnallocatedAdvance
text = text.replace(
    "const liquidateUnallocatedAdvance = (params: {",
    "const liquidateUnallocatedAdvance = async (params: {"
)
text = text.replace(
    "}): { success: boolean; allocatedCount: number; error?: string } => {",
    "}): Promise<{ success: boolean; allocatedCount: number; error?: string }> => {\n    const batch = writeBatch(db);"
)
text = text.replace(
    "safeSetDoc(doc(db, \"payment_allocations\", newAlloc.id), newAlloc);",
    "batch.set(doc(db, \"payment_allocations\", newAlloc.id), sanitizeForFirestore(newAlloc));"
)
text = text.replace(
    "safeSetDoc(doc(db, \"collections\", item.col.id), { amountApplied: newApplied }, { merge: true });",
    "batch.set(doc(db, \"collections\", item.col.id), { amountApplied: newApplied }, { merge: true });"
)
# Wait, safeSetDoc(doc(db, "payment_allocations", newAlloc.id), newAlloc); was already replaced! So we should use a global replacement maybe?
# The problem is we need batch.commit() at the end.

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)

