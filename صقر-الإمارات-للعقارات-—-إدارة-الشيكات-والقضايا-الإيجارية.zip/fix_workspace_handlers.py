import re

with open('src/components/master/LeaseWorkspaceModal.tsx', 'r') as f:
    text = f.read()

text = text.replace('const handleSubmitPayment = (e: React.FormEvent) => {', 'const handleSubmitPayment = async (e: React.FormEvent) => {')
text = text.replace('const handleLiquidateAdvance = () => {', 'const handleLiquidateAdvance = async () => {')
text = text.replace('const handleConfirmDirectCollection = () => {', 'const handleConfirmDirectCollection = async () => {')
text = text.replace('const handleConfirmPartialCollection = () => {', 'const handleConfirmPartialCollection = async () => {')

with open('src/components/master/LeaseWorkspaceModal.tsx', 'w') as f:
    f.write(text)
