const fs = require('fs');
let code = fs.readFileSync('src/components/master/TenantsView.tsx', 'utf8');

code = code.replace(/import { EmiratesIdScannerModal } from "\.\.\/emiratesId\/EmiratesIdScannerModal";/, 'import { SmartDocumentCaptureModal } from "../ai/SmartDocumentCaptureModal";');
code = code.replace(/import { EmiratesIdData } from "\.\.\/\.\.\/services\/emiratesIdService";/, '');

const newModal = `<SmartDocumentCaptureModal
        isOpen={isEidModalOpen}
        onClose={() => setIsEidModalOpen(false)}
        documentType="EMIRATES_ID"
        onApprove={(result) => {
          if (result.emiratesIdNumber?.value) setEmiratesId(result.emiratesIdNumber.value);
          if (result.arabicName?.value) setFullNameAr(result.arabicName.value);
          if (result.englishName?.value) setFullNameEn(result.englishName.value);
          
          if (!nameEn && result.englishName?.value) setNameEn(result.englishName.value);
          if (!nameAr && result.arabicName?.value) setNameAr(result.arabicName.value);
          if (result.nationality?.value) setNationality(result.nationality.value);
          
          setIsEidModalOpen(false);
        }}
      />`;
code = code.replace(/<EmiratesIdScannerModal[\s\S]*?\/>/, newModal);

fs.writeFileSync('src/components/master/TenantsView.tsx', code);
console.log('patched TenantsView');
