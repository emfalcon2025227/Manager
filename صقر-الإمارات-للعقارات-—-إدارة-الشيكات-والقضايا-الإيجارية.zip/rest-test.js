const fs = require('fs');
const config = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));
const projectId = config.projectId;
const dbId = config.firestoreDatabaseId || '(default)';
console.log('Project:', projectId, 'DB:', dbId);
