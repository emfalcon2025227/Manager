import re

with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

text = re.sub(
    r'(const chunk = docsToSave\.slice\(i, i \+ CHUNK_SIZE\);\n\s*)(for \(const item of chunk\))',
    r'\1const batch = writeBatch(db);\n        \2',
    text
)

text = re.sub(
    r'(const chunk = propertiesToSave\.slice\(i, i \+ CHUNK_SIZE\);\n\s*)(for \(const item of chunk\))',
    r'\1const batch = writeBatch(db);\n        \2',
    text
)

text = re.sub(
    r'(const chunk = unitsToSave\.slice\(i, i \+ CHUNK_SIZE\);\n\s*)(for \(const item of chunk\))',
    r'\1const batch = writeBatch(db);\n        \2',
    text
)

text = re.sub(
    r'(const chunk = casesToSave\.slice\(i, i \+ CHUNK_SIZE\);\n\s*)(for \(const item of chunk\))',
    r'\1const batch = writeBatch(db);\n        \2',
    text
)

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
