const fs = require('fs');
let file = 'src/components/master/LeaseWorkspaceModal.tsx';
let content = fs.readFileSync(file, 'utf8');

// The file has `const safeLease = lease as NonNullable<typeof lease>;` around line 878.
// Wait, `if (!lease) return null;` was inserted randomly by my previous string replace?
// Let's check where it got inserted.
