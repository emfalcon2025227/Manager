import re
import sys

with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

def get_func_bounds(name):
    pattern = r"  const " + name + r" = [\s\S]*?=> {"
    match = re.search(pattern, text)
    if not match:
        print("Not found:", name)
        return None, None
    start = match.start()
    depth = 0
    in_str = False
    str_char = ''
    i = start
    while i < len(text):
        c = text[i]
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == str_char:
                in_str = False
        else:
            if c in ["'", '"', '`']:
                in_str = True
                str_char = c
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    return start, i + 1
        i += 1
    return None, None

def replace_func(name, new_code):
    global text
    start, end = get_func_bounds(name)
    if start is not None:
        text = text[:start] + new_code + text[end:]
        print("Replaced:", name)

# 1. recordCollection
recordCollection_new = '''  const recordCollection = async (params: {
    chequeId: string;
    amountEntered: number;
    bouncedFeeAmount?: number;
    paymentMethod: PaymentMethod;
    payerName: string;
    notes?: string;
    transactionReference?: string;
    approvalCode?: string;
    fromCase?: boolean;
  }): Promise<{ success: boolean; appliedAmount: number; isOverpayment: boolean; error?: string; receipt?: CollectionRecord }> => {
    try {
      const result = await runTransaction(db, async (transaction) => {
        const chequeRef = doc(db, "cheques", params.chequeId);
        const chequeSnap = await transaction.get(chequeRef);
        if (!chequeSnap.exists()) throw new Error("Cheque not found");
        
        const cheque = chequeSnap.data() as Cheque;
        const caseCheck = checkCaseControlledCheque(params.chequeId);
        if (caseCheck.isControlled && !params.fromCase) {
          throw new Error(language === "ar" ? `هذا الشيك محجوز على ذمة قضية قانونية مفتوحة رقم ${caseCheck.caseNumber}، ولا يمكن تحصيله إلا من داخل القضية.` : `This cheque is reserved under open legal case #${caseCheck.caseNumber}.`);
        }

        if (cheque.status === "CLEARED" || cheque.status === "REPLACED" || cheque.status === "CANCELLED" || (cheque.outstanding <= 0 && cheque.status === "COLLECTED")) {
          throw new Error(language === "ar" ? `لا يمكن تحصيل شيك غير سارٍ أو مسدد بالكامل مسبقاً (الحالة: ${cheque.status}).` : `Cannot record payment for an inactive or already fully settled cheque (Status: ${cheque.status}).`);
        }

        if (isCardPayment(params.paymentMethod) && !params.approvalCode) {
          throw new Error(language === "ar" ? "يجب إدخال رقم الموافقة (Approval Code) عند الدفع بالبطاقة الائتمانية." : "Approval Code is mandatory for card payments.");
        }

        const outstanding = cheque.outstanding;
        const isOverpayment = params.amountEntered > outstanding;
        const appliedAmount = Math.min(params.amountEntered, outstanding);

        const newTotalApplied = cheque.totalApplied + appliedAmount;
        const newOutstanding = cheque.amount - newTotalApplied;
        const isFullyCollected = newOutstanding <= 0;

        const newCollectionStatus: CollectionStatus = isFullyCollected ? "FULLY_COLLECTED_AFTER_BOUNCE" : "PARTIAL_COLLECTION";
        const newChequeStatus: ChequeStatus = isFullyCollected ? "COLLECTED" : cheque.status;

        const bouncedFee = params.bouncedFeeAmount || 0;
        const isBouncedFeeAlreadyCollected = cheque.bouncedFeeCollected;
        const finalBouncedFee = isBouncedFeeAlreadyCollected ? 0 : bouncedFee;

        const receiptId = "col-" + Date.now();
        const receiptNumber = "RCP-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000);

        const colAuditEntry: ChequeAuditEntry = {
          id: "aud-" + Date.now(),
          previousStatus: cheque.status,
          newStatus: newChequeStatus,
          timestamp: new Date().toISOString(),
          performedBy: currentUser?.nameAr || currentUser?.nameEn || "System User",
          performedByUserId: currentUser?.id || "system",
          reference: params.transactionReference,
          notes: `تحصيل مالي: تم تطبيق ${appliedAmount.toLocaleString()} درهم بموجب السند #${receiptNumber}. المتبقي: ${Math.max(0, newOutstanding).toLocaleString()} درهم.`,
        };

        const updatedChqWithAudit: Cheque = {
          ...cheque,
          totalApplied: newTotalApplied,
          outstanding: Math.max(0, newOutstanding),
          collectionStatus: newCollectionStatus,
          status: newChequeStatus,
          bouncedFeeCollected: true,
          bouncedFeeCollectedAmount: (cheque.bouncedFeeCollectedAmount || 0) + finalBouncedFee,
          auditTrail: [colAuditEntry, ...(cheque.auditTrail || [])],
        };

        transaction.set(chequeRef, sanitizeForFirestore(updatedChqWithAudit), { merge: true });

        const receipt: CollectionRecord = {
          id: receiptId,
          receiptNumber: receiptNumber,
          chequeId: cheque.id,
          caseId: cheque.convertedToCaseId,
          tenantId: cheque.tenantId,
          ownerId: cheque.ownerId,
          paymentDate: new Date().toISOString().split("T")[0],
          amountEntered: params.amountEntered,
          amountApplied: appliedAmount,
          bouncedFeeAmount: finalBouncedFee > 0 ? finalBouncedFee : undefined,
          paymentMethod: params.paymentMethod,
          transactionReference: params.transactionReference,
          approvalCode: params.approvalCode,
          payerName: params.payerName,
          collectedBy: currentUser?.nameEn || "Finance Officer",
          collectedByUserId: currentUser?.id || "usr-03",
          notes: params.notes,
          createdAt: new Date().toISOString(),
        };

        transaction.set(doc(db, "collections", receiptId), sanitizeForFirestore(receipt));

        const allocId = "pal-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7);
        const alloc: PaymentAllocation = {
          id: allocId,
          collectionId: receiptId,
          targetType: "CHEQUE",
          targetId: cheque.id,
          allocatedAmount: appliedAmount,
          allocationDate: receipt.paymentDate,
          status: "ACTIVE",
          createdAt: new Date().toISOString(),
        };

        transaction.set(doc(db, "payment_allocations", allocId), sanitizeForFirestore(alloc));

        let updatedCase = null;
        if (cheque.convertedToCaseId) {
          const caseRef = doc(db, "cases", cheque.convertedToCaseId);
          const caseSnap = await transaction.get(caseRef);
          if (caseSnap.exists()) {
             // We can't rely on recalculateCaseFinancials easily without full state.
             // We will trigger recalculateCaseFinancials outside the transaction for simplicity.
          }
        }

        return { updatedChqWithAudit, receipt, alloc, isFullyCollected, appliedAmount, isOverpayment };
      });

      // Update local state
      setCheques((prev) => prev.map((c) => (c.id === params.chequeId ? result.updatedChqWithAudit : c)));
      setCollections((prev) => [result.receipt, ...prev]);
      setPaymentAllocations((prev) => [...prev, result.alloc]);

      if (result.isFullyCollected) {
        syncChequeWithLease(result.updatedChqWithAudit, "COLLECTED");
      }
      if (result.updatedChqWithAudit.convertedToCaseId) {
        setCases((prevCases) =>
          prevCases.map((c) => {
            if (c.id === result.updatedChqWithAudit.convertedToCaseId) {
              const uCase = recalculateCaseFinancials(c, cheques.map((ch) => (ch.id === result.updatedChqWithAudit.id ? result.updatedChqWithAudit : ch)), propertyExpenses);
              safeSetDoc(doc(db, "cases", c.id), uCase, { merge: true });
              return uCase;
            }
            return c;
          })
        );
      }

      logAudit("FINANCIAL_PAYMENT", "COLLECTION", result.receipt.id, `Receipt #${result.receipt.receiptNumber}`, `Collected ${result.appliedAmount.toLocaleString()} AED against Cheque #${result.updatedChqWithAudit.chequeNumber}.`);

      setTimeout(() => { recalculateTenantRisk(result.updatedChqWithAudit.tenantId); }, 150);

      return { success: true, appliedAmount: result.appliedAmount, isOverpayment: result.isOverpayment, receipt: result.receipt };
    } catch (e: any) {
      console.error(e);
      return { success: false, appliedAmount: 0, isOverpayment: false, error: e.message };
    }
  };'''

replace_func('recordCollection', recordCollection_new)

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
