const admin = require("firebase-admin");
const { getFirestore } = require("firebase-admin/firestore");
try {
  admin.initializeApp({ projectId: "gen-lang-client-0196715356" });
  const db = getFirestore(undefined, "ai-studio-remixremixremixr-8c567d77-3b0d-4111-85f4-1551be3cdb6b");
  db.collection("properties").limit(1).get().then(snap => {
      console.log("Docs found:", snap.size);
  }).catch(e => console.error("Network failed:", e.message));
} catch(e) {
  console.log("Init Failed:", e);
}
