import re

with open("src/types.ts", "r", encoding="utf-8") as f:
    content = f.read()

deposit_interface = """
export interface DailyDepositRecord {
  id: string;
  depositDate: string;
  transactionDate: string;
  amount: number;
  paymentSource: "COLLECTION" | "RECEIPT" | "OWNER_TRANSFER" | "CHEQUE" | "OTHER";
  sourceId: string;
  bank: string;
  bankAccount: string;
  depositReference: string;
  depositSlipNumber?: string;
  relatedOwnerId?: string;
  relatedTenantId?: string;
  relatedContractId?: string;
  depositType: "CASH" | "CHEQUE" | "BANK_TRANSFER" | "OTHER";
  proofStatus: "MISSING" | "UPLOADED" | "VERIFIED";
  reconciliationStatus: "UNRECONCILED" | "RECONCILED" | "EXCEPTION";
  createdBy: string;
  createdAt: string;
  submittedBy?: string;
  submittedAt?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  reconciledBy?: string;
  reconciledAt?: string;
  status: "DRAFT" | "SUBMITTED" | "VERIFIED" | "RECONCILED" | "EXCEPTION" | "REVERSED";
  notes?: string;
  proofDocumentId?: string;
  differenceAmount?: number;
}
"""

if "export interface DailyDepositRecord" not in content:
    content = content.replace("export interface OwnerTransferRecord {", deposit_interface + "\nexport interface OwnerTransferRecord {")
    with open("src/types.ts", "w", encoding="utf-8") as f:
        f.write(content)
    print("Added DailyDepositRecord to types.ts")
else:
    print("DailyDepositRecord already exists")
