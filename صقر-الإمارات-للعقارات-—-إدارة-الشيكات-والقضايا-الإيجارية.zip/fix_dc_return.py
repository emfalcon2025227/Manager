import re

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()

# Let's fix the return block of DataProvider
dc = re.sub(r'addDailyDeposit,\s*dailyDeposits,', 'addDailyDeposit,\n        dailyDeposits,', dc)
# Check for double dailyDeposits
dc = re.sub(r'dailyDeposits,\s*dailyDeposits,', 'dailyDeposits,', dc)

# Fix PeriodReconciliationInput issue:
# src/context/DataContext.tsx(7312,9): error TS1117: An object literal cannot have multiple properties with the same name.
# It seems `dailyDeposits` is listed twice in some object literal. Let's find it.
dc = re.sub(r'dailyDeposits,\s*dailyDeposits,', 'dailyDeposits,', dc)

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)

