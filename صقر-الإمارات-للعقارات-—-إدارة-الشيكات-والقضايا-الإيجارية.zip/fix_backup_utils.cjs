const fs = require('fs');
let code = fs.readFileSync('src/server-utils/backupService.ts', 'utf8');

code = code.replace(/import \* as admin from 'firebase-admin';/, `import { initializeApp, cert } from 'firebase-admin/app';\nimport { getFirestore } from 'firebase-admin/firestore';`);
code = code.replace(/admin\.initializeApp\(\{\n\s*credential: admin\.credential\.cert\(serviceAccount\)\n\s*\}\);/, `initializeApp({ credential: cert(serviceAccount) });`);
code = code.replace(/const db = admin\.firestore\(\);/g, `const db = getFirestore();`);
code = code.replace(/snap\.forEach\(doc => \{/g, `snap.forEach((doc: any) => {`);
code = code.replace(/archive\.on\('error', reject\);/, `archive.on('error', (err: any) => reject(err));`);
code = code.replace(/import archiver from 'archiver';/, `import archiver from 'archiver';\n// @ts-ignore`);

fs.writeFileSync('src/server-utils/backupService.ts', code);
console.log("Fixed backupService.ts");
