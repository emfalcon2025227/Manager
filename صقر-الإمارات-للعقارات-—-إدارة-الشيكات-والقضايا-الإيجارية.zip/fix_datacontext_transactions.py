import sys

with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

def replace_block(text, start_str, new_code):
    start = text.find(start_str)
    if start == -1:
        print("Not found:", start_str)
        return text
    
    depth = 0
    in_str = False
    str_char = ''
    i = start
    while i < len(text):
        c = text[i]
        if in_str:
            if c == '\\':
                i += 2
                continue
            if c == str_char:
                in_str = False
        else:
            if c in ["'", '"', '`']:
                in_str = True
                str_char = c
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    text = text[:start] + new_code + text[i+1:]
                    print("Replaced block starting with", start_str[:30])
                    return text
        i += 1
    return text

text = replace_block(text, "  const recordCollection = (params: {", '''  const recordCollection = async (params: {
    chequeId: string;
    amountEntered: number;
    bouncedFeeAmount?: number;
    paymentMethod: PaymentMethod;
    payerName: string;
    notes?: string;
    transactionReference?: string;
    approvalCode?: string;
    fromCase?: boolean;
  }): Promise<{ success: boolean; appliedAmount: number; isOverpayment: boolean; error?: string; receipt?: CollectionRecord }> => {
    try {
      const result = await runTransaction(db, async (transaction) => {
        const chequeRef = doc(db, "cheques", params.chequeId);
        const chequeSnap = await transaction.get(chequeRef);
        if (!chequeSnap.exists()) throw new Error("Cheque not found");
        
        const cheque = chequeSnap.data() as Cheque;
        const caseCheck = checkCaseControlledCheque(params.chequeId);
        if (caseCheck.isControlled && !params.fromCase) {
          throw new Error(language === "ar" ? `هذا الشيك محجوز على ذمة قضية قانونية مفتوحة رقم ${caseCheck.caseNumber}، ولا يمكن تحصيله إلا من داخل القضية.` : `This cheque is reserved under open legal case #${caseCheck.caseNumber}.`);
        }

        if (cheque.status === "CLEARED" || cheque.status === "REPLACED" || cheque.status === "CANCELLED" || (cheque.outstanding <= 0 && cheque.status === "COLLECTED")) {
          throw new Error(language === "ar" ? `لا يمكن تحصيل شيك غير سارٍ أو مسدد بالكامل مسبقاً (الحالة: ${cheque.status}).` : `Cannot record payment for an inactive or already fully settled cheque (Status: ${cheque.status}).`);
        }

        if (isCardPayment(params.paymentMethod) && !params.approvalCode) {
          throw new Error(language === "ar" ? "يجب إدخال رقم الموافقة (Approval Code) عند الدفع بالبطاقة الائتمانية." : "Approval Code is mandatory for card payments.");
        }

        const outstanding = cheque.outstanding;
        const isOverpayment = params.amountEntered > outstanding;
        const appliedAmount = Math.min(params.amountEntered, outstanding);

        const newTotalApplied = cheque.totalApplied + appliedAmount;
        const newOutstanding = cheque.amount - newTotalApplied;
        const isFullyCollected = newOutstanding <= 0;

        const newCollectionStatus: CollectionStatus = isFullyCollected ? "FULLY_COLLECTED_AFTER_BOUNCE" : "PARTIAL_COLLECTION";
        const newChequeStatus: ChequeStatus = isFullyCollected ? "COLLECTED" : cheque.status;

        const bouncedFee = params.bouncedFeeAmount || 0;
        const isBouncedFeeAlreadyCollected = cheque.bouncedFeeCollected;
        const finalBouncedFee = isBouncedFeeAlreadyCollected ? 0 : bouncedFee;

        const receiptId = "col-" + Date.now();
        const receiptNumber = "RCP-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000);

        const colAuditEntry: ChequeAuditEntry = {
          id: "aud-" + Date.now(),
          previousStatus: cheque.status,
          newStatus: newChequeStatus,
          timestamp: new Date().toISOString(),
          performedBy: currentUser?.nameAr || currentUser?.nameEn || "System User",
          performedByUserId: currentUser?.id || "system",
          reference: params.transactionReference,
          notes: `تحصيل مالي: تم تطبيق ${appliedAmount.toLocaleString()} درهم بموجب السند #${receiptNumber}. المتبقي: ${Math.max(0, newOutstanding).toLocaleString()} درهم.`,
        };

        const updatedChqWithAudit: Cheque = {
          ...cheque,
          totalApplied: newTotalApplied,
          outstanding: Math.max(0, newOutstanding),
          collectionStatus: newCollectionStatus,
          status: newChequeStatus,
          bouncedFeeCollected: true,
          bouncedFeeCollectedAmount: (cheque.bouncedFeeCollectedAmount || 0) + finalBouncedFee,
          auditTrail: [colAuditEntry, ...(cheque.auditTrail || [])],
        };

        transaction.set(chequeRef, sanitizeForFirestore(updatedChqWithAudit), { merge: true });

        const receipt: CollectionRecord = {
          id: receiptId,
          receiptNumber: receiptNumber,
          chequeId: cheque.id,
          caseId: cheque.convertedToCaseId,
          tenantId: cheque.tenantId,
          ownerId: cheque.ownerId,
          paymentDate: new Date().toISOString().split("T")[0],
          amountEntered: params.amountEntered,
          amountApplied: appliedAmount,
          bouncedFeeAmount: finalBouncedFee > 0 ? finalBouncedFee : undefined,
          paymentMethod: params.paymentMethod,
          transactionReference: params.transactionReference,
          approvalCode: params.approvalCode,
          payerName: params.payerName,
          collectedBy: currentUser?.nameEn || "Finance Officer",
          collectedByUserId: currentUser?.id || "usr-03",
          notes: params.notes,
          createdAt: new Date().toISOString(),
        };

        transaction.set(doc(db, "collections", receiptId), sanitizeForFirestore(receipt));

        const allocId = "pal-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7);
        const alloc: PaymentAllocation = {
          id: allocId,
          collectionId: receiptId,
          targetType: "CHEQUE",
          targetId: cheque.id,
          allocatedAmount: appliedAmount,
          allocationDate: receipt.paymentDate,
          status: "ACTIVE",
          createdAt: new Date().toISOString(),
        };

        transaction.set(doc(db, "payment_allocations", allocId), sanitizeForFirestore(alloc));

        return { updatedChqWithAudit, receipt, alloc, isFullyCollected, appliedAmount, isOverpayment };
      });

      setCheques((prev) => prev.map((c) => (c.id === params.chequeId ? result.updatedChqWithAudit : c)));
      setCollections((prev) => [result.receipt, ...prev]);
      setPaymentAllocations((prev) => [...prev, result.alloc]);

      if (result.isFullyCollected) {
        syncChequeWithLease(result.updatedChqWithAudit, "COLLECTED");
      }
      if (result.updatedChqWithAudit.convertedToCaseId) {
        setCases((prevCases) =>
          prevCases.map((c) => {
            if (c.id === result.updatedChqWithAudit.convertedToCaseId) {
              const uCase = recalculateCaseFinancials(c, cheques.map((ch) => (ch.id === result.updatedChqWithAudit.id ? result.updatedChqWithAudit : ch)), propertyExpenses);
              safeSetDoc(doc(db, "cases", c.id), uCase, { merge: true });
              return uCase;
            }
            return c;
          })
        );
      }

      logAudit("FINANCIAL_PAYMENT", "COLLECTION", result.receipt.id, `Receipt #${result.receipt.receiptNumber}`, `Collected ${result.appliedAmount.toLocaleString()} AED against Cheque #${result.updatedChqWithAudit.chequeNumber}.`);

      setTimeout(() => { recalculateTenantRisk(result.updatedChqWithAudit.tenantId); }, 150);

      return { success: true, appliedAmount: result.appliedAmount, isOverpayment: result.isOverpayment, receipt: result.receipt };
    } catch (e: any) {
      console.error(e);
      return { success: false, appliedAmount: 0, isOverpayment: false, error: e.message };
    }
  };''')

text = replace_block(text, "  const clearCheque = (params: {", '''  const clearCheque = async (params: {
    chequeId: string;
    clearingDate: string;
    clearingRef?: string;
    clearingProofUrl?: string;
    notes?: string;
    userId?: string;
    userName?: string;
  }): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await runTransaction(db, async (transaction) => {
        const targetRef = doc(db, "cheques", params.chequeId);
        const targetSnap = await transaction.get(targetRef);
        if (!targetSnap.exists()) throw new Error("Cheque not found");
        const target = targetSnap.data() as Cheque;

        const caseCheck = checkCaseControlledCheque(params.chequeId);
        if (caseCheck.isControlled) {
          throw new Error(language === "ar" ? `عذراً، هذا الشيك محجوز على ذمة قضية.` : `Sorry, this cheque is reserved under an active legal case.`);
        }

        if (target.status === "CLEARED") throw new Error(language === "ar" ? "الشيك تمت مقاصته وصرفه في الحساب البنكي مسبقاً." : "This cheque has already been cleared.");
        if (target.status === "COLLECTED") throw new Error(language === "ar" ? "تم تحصيل هذا الشيك مسبقاً بموجب سند قبض." : "This cheque has already been collected.");
        if (target.status === "CANCELLED" || target.status === "REPLACED") throw new Error(language === "ar" ? `لا يمكن مقاصة شيك غير سارٍ (${target.status}).` : `Cannot clear a ${target.status} cheque.`);

        if (!params.clearingProofUrl) throw new Error(language === "ar" ? "يجب إرفاق إثبات المقاصة / التحصيل البنكي لاعتماد الصرف." : "Bank clearing proof is strictly required.");
        if (!params.clearingRef || !params.clearingRef.trim()) throw new Error(language === "ar" ? "يجب إدخال رقم المرجع المصرفي لعملية المقاصة البنكية." : "Bank clearing reference number is required.");

        const oldStatus = target.status;
        const nowIso = new Date().toISOString();

        const auditEntry: ChequeAuditEntry = {
          id: "aud-" + Date.now(),
          previousStatus: oldStatus,
          newStatus: "CLEARED",
          timestamp: nowIso,
          performedBy: params.userName || currentUser?.nameAr || currentUser?.nameEn || "System User",
          performedByUserId: params.userId || currentUser?.id || "system",
          reference: params.clearingRef,
          proofUrl: params.clearingProofUrl,
          notes: params.notes,
        };

        const updated: Cheque = {
          ...target,
          status: "CLEARED",
          clearingDate: params.clearingDate,
          clearingRef: params.clearingRef || target.clearingRef,
          clearingProofUrl: params.clearingProofUrl || target.clearingProofUrl,
          clearingNotes: params.notes || target.clearingNotes,
          clearedByUserId: params.userId || currentUser?.id || "system",
          outstanding: 0,
          totalApplied: target.amount,
          auditTrail: [auditEntry, ...(target.auditTrail || [])],
        };

        transaction.set(targetRef, sanitizeForFirestore(updated), { merge: true });

        const colId = "col-" + Date.now();
        const receiptNumber = "RCP-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000);
        const receipt: CollectionRecord = {
          id: colId,
          receiptNumber: receiptNumber,
          chequeId: target.id,
          tenantId: target.tenantId,
          ownerId: target.ownerId,
          paymentDate: params.clearingDate,
          amountEntered: target.amount,
          amountApplied: target.amount,
          paymentMethod: "BANK_TRANSFER",
          transactionReference: params.clearingRef,
          notes: params.notes,
          collectedBy: params.userName || currentUser?.nameEn || "System",
          collectedByUserId: params.userId || currentUser?.id || "sys",
          createdAt: nowIso,
        };
        transaction.set(doc(db, "collections", colId), sanitizeForFirestore(receipt));

        const allocId = "pal-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7);
        const alloc: PaymentAllocation = {
          id: allocId,
          collectionId: colId,
          targetType: "CHEQUE",
          targetId: target.id,
          allocatedAmount: target.amount,
          allocationDate: params.clearingDate,
          status: "ACTIVE",
          createdAt: nowIso,
        };
        transaction.set(doc(db, "payment_allocations", allocId), sanitizeForFirestore(alloc));

        return { updated, receipt, alloc };
      });

      setCheques((prev) => prev.map((c) => (c.id === params.chequeId ? result.updated : c)));
      setCollections((prev) => [result.receipt, ...prev]);
      setPaymentAllocations((prev) => [...prev, result.alloc]);

      syncChequeWithLease(result.updated, "CLEARED");
      dispatchChequeCollectedNotification(result.updated.id);

      logAudit("FINANCIAL_RECORD_EDIT", "CHEQUE", params.chequeId, `Cheque #${result.updated.chequeNumber}`, `Cleared and reconciled in bank.`);
      setTimeout(() => { recalculateTenantRisk(result.updated.tenantId); }, 150);

      return { success: true };
    } catch (e: any) {
      console.error(e);
      return { success: false, error: e.message };
    }
  };''')

text = replace_block(text, "  const depositCheque = (params: {", '''  const depositCheque = async (params: {
    chequeId: string;
    depositedDate: string;
    depositSlipNumber?: string;
    depositedBankName?: string;
    depositProofUrl?: string;
    notes?: string;
    userId?: string;
    userName?: string;
  }): Promise<{ success: boolean; error?: string }> => {
    try {
      const result = await runTransaction(db, async (transaction) => {
        const targetRef = doc(db, "cheques", params.chequeId);
        const targetSnap = await transaction.get(targetRef);
        if (!targetSnap.exists()) throw new Error("Cheque not found");
        const target = targetSnap.data() as Cheque;

        const caseCheck = checkCaseControlledCheque(params.chequeId);
        if (caseCheck.isControlled) {
          throw new Error(language === "ar" ? `عذراً، هذا الشيك محجوز على ذمة قضية.` : `Sorry, this cheque is reserved under an active legal case.`);
        }

        if (target.status === "DEPOSITED") throw new Error(language === "ar" ? "الشيك مودع مسبقاً." : "This cheque is already deposited.");
        if (target.status === "CLEARED" || target.status === "COLLECTED") throw new Error(language === "ar" ? "لا يمكن إيداع شيك مسوى مسبقاً." : "This cheque has already been cleared or collected.");
        if (target.status === "CANCELLED" || target.status === "REPLACED") throw new Error(language === "ar" ? `لا يمكن إيداع شيك غير سارٍ (${target.status}).` : `Cannot deposit a ${target.status} cheque.`);

        if (!params.depositProofUrl && !params.depositSlipNumber) throw new Error(language === "ar" ? "يجب إرفاق إثبات الإيداع أو إدخال رقم الحافظة." : "Bank deposit proof or slip number is required.");

        const oldStatus = target.status;
        const nowIso = new Date().toISOString();

        const auditEntry: ChequeAuditEntry = {
          id: "aud-" + Date.now(),
          previousStatus: oldStatus,
          newStatus: "DEPOSITED",
          timestamp: nowIso,
          performedBy: params.userName || currentUser?.nameAr || currentUser?.nameEn || "System User",
          performedByUserId: params.userId || currentUser?.id || "system",
          reference: params.depositSlipNumber,
          proofUrl: params.depositProofUrl,
          notes: params.notes,
        };

        const updated: Cheque = {
          ...target,
          status: "DEPOSITED",
          depositedDate: params.depositedDate,
          depositSlipNumber: params.depositSlipNumber || target.depositSlipNumber,
          depositedBankName: params.depositedBankName || target.depositedBankName,
          depositProofUrl: params.depositProofUrl || target.depositProofUrl,
          depositNotes: params.notes || target.depositNotes,
          auditTrail: [auditEntry, ...(target.auditTrail || [])],
        };

        transaction.set(targetRef, sanitizeForFirestore(updated), { merge: true });

        return updated;
      });

      setCheques((prev) => prev.map((c) => (c.id === params.chequeId ? result : c)));
      syncChequeWithLease(result, "DEPOSITED");

      logAudit("FINANCIAL_RECORD_EDIT", "CHEQUE", params.chequeId, `Cheque #${result.chequeNumber}`, `Deposited in bank.`);

      return { success: true };
    } catch (e: any) {
      console.error(e);
      return { success: false, error: e.message };
    }
  };''')

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)

print("Done replacing.")
