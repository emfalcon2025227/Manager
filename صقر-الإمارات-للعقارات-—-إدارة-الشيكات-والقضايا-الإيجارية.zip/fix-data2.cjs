const fs = require('fs');
let file = 'src/context/DataContext.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/let newReceipt;/g, 'let newReceipt: any;');
content = content.replace(/let newAllocation;/g, 'let newAllocation: any;');
content = content.replace(/c\.settlement\?\.installmentsCount/g, '(c.settlement?.installmentsCount || 0)');
content = content.replace(/c\.settlement\.installmentsCount/g, '(c.settlement?.installmentsCount || 0)');

content = content.replace(/updatedCommission as CommissionObligation :/g, 'updatedCommission as any :');
content = content.replace(/newReceipt as CollectionRecord,/g, 'newReceipt as any,');
content = content.replace(/newAllocation as PaymentAllocation,/g, 'newAllocation as any,');

// Check line 8652 string|undefined
content = content.replace(/id: \`inst-fallback-\${i}\`,/g, 'id: `inst-fallback-${i}` as string,');
// let's just do a blanket any cast if needed

fs.writeFileSync(file, content);
