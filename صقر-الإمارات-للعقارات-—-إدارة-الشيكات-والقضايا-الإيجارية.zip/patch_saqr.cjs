const fs = require('fs');
let content = fs.readFileSync('src/components/financials/SaqrOfficeAccountView.tsx', 'utf8');

const target = `      // 2. Administrative Fees collected
      if (col.adminFeeAmount && col.adminFeeAmount > 0) {
        list.push({
          id: \`admin-\${col.id}\`,
          date: col.paymentDate || col.createdAt.slice(0, 10),
          type: "DEPOSIT",
          amount: col.adminFeeAmount,
          category: "ADMIN_FEE",
          categoryName: isAr ? "رسوم إدارية" : "Administrative Fee",
          description: isAr ? \`رسوم إدارية محصلة من سند قبض رقم \${col.id.slice(-6)}\` : \`Admin fee collected from receipt #\${col.id.slice(-6)}\`,
          source: col.payerName || (isAr ? "مستأجر" : "Tenant"),
          reference: col.transactionReference,
          isAuto: true,
          createdAt: col.createdAt,
        });
      }`;

const replacement = `      // 2. Administrative Fees collected
      if (col.adminFeeAmount && col.adminFeeAmount > 0) {
        let totalNet = 0;
        let totalVat = 0;
        const relatedAllocations = paymentAllocations.filter(a => a.collectionId === col.id && a.targetType === "COMMISSION" && a.status === "ACTIVE");
        relatedAllocations.forEach(alloc => {
          const comm = commissions.find(c => c.id === alloc.targetId);
          if (comm && comm.totalCommissionAmount > 0) {
            const ratio = alloc.allocatedAmount / comm.totalCommissionAmount;
            totalNet += (comm.netRevenueAmount || 0) * ratio;
            totalVat += (comm.vatAmount || 0) * ratio;
          }
        });
        if (totalNet === 0 && totalVat === 0) {
          totalNet = col.adminFeeAmount;
        } else {
          totalNet = Math.round(totalNet * 100) / 100;
          totalVat = Math.round(totalVat * 100) / 100;
        }
        list.push({
          id: \`admin-\${col.id}\`,
          date: col.paymentDate || col.createdAt.slice(0, 10),
          type: "DEPOSIT",
          amount: col.adminFeeAmount,
          netRevenue: totalNet,
          vatAmount: totalVat,
          category: "ADMIN_FEE",
          categoryName: isAr ? "رسوم إدارية" : "Administrative Fee",
          description: isAr ? \`رسوم إدارية محصلة من سند قبض رقم \${col.id.slice(-6)}\` : \`Admin fee collected from receipt #\${col.id.slice(-6)}\`,
          source: col.payerName || (isAr ? "مستأجر" : "Tenant"),
          reference: col.transactionReference,
          isAuto: true,
          createdAt: col.createdAt,
        });
      }`;

content = content.replace(target, replacement);
fs.writeFileSync('src/components/financials/SaqrOfficeAccountView.tsx', content);
console.log("Patch applied.");
