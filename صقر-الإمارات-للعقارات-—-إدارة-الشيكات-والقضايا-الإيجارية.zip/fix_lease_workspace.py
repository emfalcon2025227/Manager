import re
with open('src/components/master/LeaseWorkspaceModal.tsx', 'r') as f:
    text = f.read()

text = text.replace(
    "const res = recordLeasePayment(",
    "const res = await recordLeasePayment("
)
text = text.replace(
    "const res = liquidateUnallocatedAdvance(",
    "const res = await liquidateUnallocatedAdvance("
)
text = text.replace(
    "const res = updateChequeWithSafetyConfirmation(",
    "const res = await updateChequeWithSafetyConfirmation("
)

text = re.sub(r'const handleAddPayment = \(\) => \{', r'const handleAddPayment = async () => {', text)
text = re.sub(r'const handleLiquidate = \(\) => \{', r'const handleLiquidate = async () => {', text)
text = re.sub(r'const handleChequeAction = \(cheque: Cheque, action: string\) => \{', r'const handleChequeAction = async (cheque: Cheque, action: string) => {', text)
text = re.sub(r'const handleSubmitAction = \(\) => \{', r'const handleSubmitAction = async () => {', text)

with open('src/components/master/LeaseWorkspaceModal.tsx', 'w') as f:
    f.write(text)
