import re
with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()

dc = dc.replace("        deleteJournalEntry,\n        dailyDeposits,\n        ownerTransfers,", "        deleteJournalEntry,\n        ownerTransfers,")

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)
