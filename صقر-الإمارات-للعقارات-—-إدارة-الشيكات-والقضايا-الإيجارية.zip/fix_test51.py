import re
with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    t51 = f.read()

# Replace any occurrence of the object with "as any" again
t51 = re.sub(r'\{\s+id: "DEP-1",\s+depositReference: "REF-123",\s+amount: 50000,\s+status: "DEPOSITED"\s+\}', '({ id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "DEPOSITED" } as any)', t51)
t51 = re.sub(r'\{\s+id: "DEP-DUP",\s+depositReference: "REF-123",\s+amount: 50000,\s+status: "DEPOSITED"\s+\}', '({ id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "DEPOSITED" } as any)', t51)
t51 = re.sub(r'\{\s*id: "DEP-1",\s*depositReference: "REF-123",\s*amount: 50000,\s*status: "RECONCILED"\s*\}', '({ id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)
t51 = re.sub(r'\{\s*id: "DEP-DUP",\s*depositReference: "REF-123",\s*amount: 50000,\s*status: "RECONCILED"\s*\}', '({ id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t51)

with open("src/utils/phase52DailyDepositsControlTests.ts", "r", encoding="utf-8") as f:
    t52 = f.read()

t52 = re.sub(r'\s*createdAt: today,\s*createdBy: "System",\s*payerName: "John Doe"', '\n      payerName: "John Doe"', t52)

with open("src/utils/phase52DailyDepositsControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t52)
