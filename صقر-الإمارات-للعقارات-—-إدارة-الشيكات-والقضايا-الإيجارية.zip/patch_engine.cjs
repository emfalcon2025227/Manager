const fs = require('fs');
let code = fs.readFileSync('src/services/ocr/v2/OCRV2Engine.ts', 'utf-8');
code = code.replace(
`        if (jsonRes.success && jsonRes.rawText) {
          rawJsonText = jsonRes.rawText;
          diagnostics.addCheckpoint("08", "MODEL_RESPONSE_RECEIVED", "PASS", \`Received response from \${model}\`);
          break;
        } else if (jsonRes.data) {
          rawJsonText = JSON.stringify(jsonRes.data);
          diagnostics.addCheckpoint("08", "MODEL_RESPONSE_RECEIVED", "PASS", \`Received structured data from \${model}\`);
          break;
        }`,
`        if (jsonRes.success && jsonRes.rawText) {
          rawJsonText = jsonRes.rawText;
          diagnostics.addCheckpoint("08", "MODEL_RESPONSE_RECEIVED", "PASS", \`Received response from \${model}\`);
          break;
        } else if (jsonRes.success && jsonRes.data) {
          rawJsonText = JSON.stringify(jsonRes.data);
          diagnostics.addCheckpoint("08", "MODEL_RESPONSE_RECEIVED", "PASS", \`Received structured data from \${model}\`);
          break;
        } else if (jsonRes.error) {
          if (jsonRes.error.includes("GEMINI_AUTH_UNAUTHORIZED") || jsonRes.error.includes("Gemini API")) {
             return {
               success: false,
               status: "FAILED",
               profile: profileKey,
               data: {},
               fields: {},
               diagnostics: {
                 traceId,
                 model: usedModel,
                 attempts,
                 processingMs: Date.now() - startTime,
                 imageVariant: processed.variant,
                 errorCode: "GEMINI_AUTH_UNAUTHORIZED",
                 errorMsg: "تأكد من إعداد مفتاح Gemini API صحيح في الإعدادات. المفتاح الحالي غير صالح.",
                 checkpoints: diagnostics.getCheckpoints()
               }
             };
          }
          console.warn("[OCRV2Engine] Model error:", jsonRes.error);
        }`
);
fs.writeFileSync('src/services/ocr/v2/OCRV2Engine.ts', code, 'utf-8');
