import re

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    t51 = f.read()

# Let's replace the object literals more robustly
t51 = re.sub(r'\{\s*id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "RECONCILED" \}', '({ id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)
t51 = re.sub(r'\{\s*id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "RECONCILED" \}', '({ id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t51)

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()
    
# Remove from PeriodReconciliationInput ONLY!
# The problem is that PeriodReconciliationInput is around line 7310
# So let's look for "dailyDeposits: PeriodReconciliationInput"

dc = re.sub(r'      dailyDeposits,\n\s*addDailyDeposit,', '      dailyDeposits,', dc)
dc = re.sub(r'      dailyDeposits,\n\s*dailyDeposits,', '      dailyDeposits,', dc)

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)

