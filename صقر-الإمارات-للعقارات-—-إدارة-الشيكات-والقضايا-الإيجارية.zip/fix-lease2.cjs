const fs = require('fs');
let file = 'src/components/master/LeaseWorkspaceModal.tsx';
let content = fs.readFileSync(file, 'utf8');

// Undo previous safeLease insertion
content = content.replace("if (!lease) return null;\n\n  // SAFEGUARD\n  const safeLease = lease as NonNullable<typeof lease>;", "if (!lease) return null;");

content = content.replace(
  /const lease = leases\.find\(\(l\) => l\.id === initialLease\?\.id\) \|\| initialLease;/,
  'const lease = (leases.find((l) => l.id === initialLease?.id) || initialLease) as Lease;'
);

content = content.replace(/lease\?\./g, 'lease.');

// Fix chequeId/chequeNumber error in map
content = content.replace(/const displayChequeNumber = inst\.chequeNumber \|\|/g, 'const displayChequeNumber = (inst as any).chequeNumber ||');
content = content.replace(/\(inst\.chequeId \?/g, '((inst as any).chequeId ?');
content = content.replace(/\(inst\.chequeId\./g, '((inst as any).chequeId.');

fs.writeFileSync(file, content);
