const fs = require('fs');
let content = fs.readFileSync('src/components/financials/FinancialsView.tsx', 'utf8');

// 1. Add state for the VAT Breakdown Modal
const stateTarget = `  const [activeTab, setActiveTab] = useState<"COLLECTIONS" | "COMMISSIONS" | "PAYABLES" | "SUMMARY">("COLLECTIONS");`;
const stateReplacement = `  const [activeTab, setActiveTab] = useState<"COLLECTIONS" | "COMMISSIONS" | "PAYABLES" | "SUMMARY">("COLLECTIONS");
  const [selectedVatCommission, setSelectedVatCommission] = useState<any | null>(null);`;
content = content.replace(stateTarget, stateReplacement);

// 2. Make the VAT text clickable
const targetVatText = `                          {c.vatAmount && c.vatAmount > 0 && !isReversed && (
                            <div className="text-[10px] text-slate-500 dark:text-slate-400 font-normal mt-0.5">
                              ({isAr ? "شامل ضريبة:" : "Incl. VAT:"} {c.vatAmount.toLocaleString()})
                            </div>
                          )}`;
const replacementVatText = `                          {c.vatAmount && c.vatAmount > 0 && !isReversed && (
                            <button 
                              onClick={() => setSelectedVatCommission(c)}
                              className="text-[10px] text-indigo-500 hover:text-indigo-700 hover:underline dark:text-indigo-400 font-normal mt-0.5 flex items-center gap-1"
                            >
                              <span>{isAr ? "شامل ضريبة:" : "Incl. VAT:"} {c.vatAmount.toLocaleString()}</span>
                            </button>
                          )}`;
content = content.replace(targetVatText, replacementVatText);

// 3. Add the Modal component at the end
const targetModalEnd = `      {/* REVERSAL MODAL */}`;
const replacementModalEnd = `      {/* VAT BREAKDOWN MODAL */}
      <AnimatePresence>
        {selectedVatCommission && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              onClick={() => setSelectedVatCommission(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-700"
            >
              <div className="bg-indigo-50 dark:bg-indigo-950/40 p-5 border-b border-indigo-100 dark:border-indigo-900 flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-black text-indigo-900 dark:text-indigo-100 mb-1">
                    {isAr ? "تفاصيل ضريبة القيمة المضافة" : "VAT Breakdown Details"}
                  </h3>
                  <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                    {selectedVatCommission.commissionType === "ADMIN_FEE" 
                      ? (isAr ? "رسوم إدارية" : "Administrative Fee") 
                      : (isAr ? selectedVatCommission.commissionType : selectedVatCommission.commissionType)}
                  </p>
                </div>
                <button onClick={() => setSelectedVatCommission(null)} className="p-2 bg-white dark:bg-slate-800 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 transition">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-400">{isAr ? "إجمالي الرسم" : "Gross Fee"}</span>
                  <span className="text-sm font-black text-slate-900 dark:text-white">{selectedVatCommission.totalCommissionAmount.toLocaleString()} AED</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-400">{isAr ? "نسبة ضريبة القيمة المضافة" : "VAT Rate"}</span>
                  <span className="text-sm font-black text-slate-900 dark:text-white">{selectedVatCommission.vatRate || 5}%</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-400">{isAr ? "قيمة الضريبة" : "VAT Amount"}</span>
                  <span className="text-sm font-black text-rose-600">{selectedVatCommission.vatAmount?.toLocaleString() || "0"} AED</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-400">{isAr ? "صافي إيراد المكتب" : "Net Office Revenue"}</span>
                  <span className="text-sm font-black text-emerald-600">{selectedVatCommission.netRevenueAmount?.toLocaleString() || (selectedVatCommission.totalCommissionAmount - (selectedVatCommission.vatAmount || 0)).toLocaleString()} AED</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-400">{isAr ? "المبلغ المحصل" : "Collected Amount"}</span>
                  <span className="text-sm font-black text-blue-600">{selectedVatCommission.collectedAmount.toLocaleString()} AED</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-400">{isAr ? "المبلغ المتبقي" : "Remaining Amount"}</span>
                  <span className="text-sm font-black text-amber-600">{selectedVatCommission.outstandingBalance.toLocaleString()} AED</span>
                </div>
                <div className="flex justify-between items-center py-2 pt-2">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-400">{isAr ? "حالة التحصيل" : "Collection Status"}</span>
                  <span className={\`px-2.5 py-1 text-xs font-bold rounded-full \${
                    selectedVatCommission.status === "FULLY_COLLECTED"
                      ? "bg-emerald-100 text-emerald-700"
                      : selectedVatCommission.status === "PARTIALLY_COLLECTED"
                      ? "bg-amber-100 text-amber-700"
                      : "bg-slate-100 text-slate-700"
                  }\`}>
                    {isAr ? (selectedVatCommission.status === "FULLY_COLLECTED" ? "تم التحصيل بالكامل" : selectedVatCommission.status === "PARTIALLY_COLLECTED" ? "محصل جزئياً" : "قيد الانتظار") : selectedVatCommission.status}
                  </span>
                </div>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 flex justify-end">
                <button onClick={() => setSelectedVatCommission(null)} className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-white rounded-xl text-sm font-bold transition">
                  {isAr ? "إغلاق" : "Close"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* REVERSAL MODAL */}`;
content = content.replace(targetModalEnd, replacementModalEnd);

fs.writeFileSync('src/components/financials/FinancialsView.tsx', content);
console.log("Patch applied to FinancialsView.");
