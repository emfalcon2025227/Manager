const fs = require('fs');

function fixIdx(file) {
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, 'utf8');
    content = content.replace(/\.map\(\(doc\) =>/g, '.map((doc, idx) =>');
    content = content.replace(/\.map\(\(c\) =>/g, '.map((c, idx) =>');
    content = content.replace(/\.map\(\(chq\) =>/g, '.map((chq, idx) =>');
    content = content.replace(/\.map\(\(record\) =>/g, '.map((record, idx) =>');
    fs.writeFileSync(file, content);
  }
}

fixIdx('src/components/archive/ArchiveView.tsx');
fixIdx('src/components/cases/CasesView.tsx');
fixIdx('src/components/cheques/ChequesView.tsx');
fixIdx('src/components/cheques/DueChecksView.tsx');
fixIdx('src/components/collections/CollectionsView.tsx');
