const fs = require('fs');
let code = fs.readFileSync('src/server-utils/backupService.ts', 'utf8');

code = code.replace(/import \* as archiver from 'archiver';/, `import archiver from 'archiver';`);
code = code.replace(/const archive = archiver\('zip', \{ zlib: \{ level: 9 \} \}\);/, `const archiverModule = require('archiver');\n        const archive = archiverModule('zip', { zlib: { level: 9 } });`);
code = code.replace(/import archiver from 'archiver';/, ``);

fs.writeFileSync('src/server-utils/backupService.ts', code);
console.log("Fixed backupService.ts");
