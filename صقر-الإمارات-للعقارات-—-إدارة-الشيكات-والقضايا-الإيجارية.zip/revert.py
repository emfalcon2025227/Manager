import re

with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

text = text.replace('batch.set(doc(db, "cheques", newChq.id), sanitizeForFirestore(newChq));', 'safeSetDoc(doc(db, "cheques", newChq.id), newChq);')
text = text.replace('batch.set(doc(db, "collections", receipt.id), sanitizeForFirestore(receipt));', 'safeSetDoc(doc(db, "collections", receipt.id), receipt);')
text = text.replace('batch.set(doc(db, "payment_allocations", alloc.id), sanitizeForFirestore(alloc));', 'safeSetDoc(doc(db, "payment_allocations", alloc.id), alloc);')
text = text.replace('batch.set(doc(db, "commissions", c.id), sanitizeForFirestore(updatedCom), { merge: true });', 'safeSetDoc(doc(db, "commissions", c.id), updatedCom, { merge: true });')
text = text.replace('batch.set(doc(db, "cheques", c.id), sanitizeForFirestore(updatedChq), { merge: true });', 'safeSetDoc(doc(db, "cheques", c.id), updatedChq, { merge: true });')
text = text.replace('batch.set(doc(db, "leases", l.id), sanitizeForFirestore(updatedLease), { merge: true });', 'safeSetDoc(doc(db, "leases", l.id), updatedLease, { merge: true });')
text = text.replace('batch.set(doc(db, "cheques", c.id), sanitizeForFirestore(updated), { merge: true });', 'safeSetDoc(doc(db, "cheques", c.id), updated, { merge: true });')
text = text.replace('batch.set(doc(db, "payment_allocations", newAlloc.id), sanitizeForFirestore(newAlloc));', 'safeSetDoc(doc(db, "payment_allocations", newAlloc.id), newAlloc);')
text = text.replace('batch.set(doc(db, "collections", item.col.id), { amountApplied: newApplied }, { merge: true });', 'safeSetDoc(doc(db, "collections", item.col.id), { amountApplied: newApplied }, { merge: true });')

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
