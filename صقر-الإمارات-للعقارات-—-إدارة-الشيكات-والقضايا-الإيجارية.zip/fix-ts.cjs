const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'import admin from "firebase-admin";',
  'import { initializeApp, getApps } from "firebase-admin/app";'
);
code = code.replace(
  'if (!admin.apps.length) {\n    admin.initializeApp();',
  'if (!getApps().length) {\n    initializeApp();'
);

// Fix TS errors related to 'receipt is possibly undefined'
code = code.replace(
  'const receipt = docSnap.data();',
  'const receipt = docSnap.data();\n    if (!receipt) return res.status(404).json({ valid: false, error: "NOT_FOUND" });'
);
code = code.replace(
  'const tenantData = tenantSnap.data();',
  'const tenantData = tenantSnap.data();\n        if (tenantData) {'
);
code = code.replace(
  'const rawName = tenantData.nameEn || tenantData.nameAr || "";',
  'const rawName = tenantData.nameEn || tenantData.nameAr || "";'
);
code = code.replace(
  'if (parts.length > 0) {\n          maskedTenantName = parts[0] + " " + (parts[1] ? parts[1].charAt(0) + ".****" : "****");\n        }\n      }\n    }',
  'if (parts.length > 0) {\n          maskedTenantName = parts[0] + " " + (parts[1] ? parts[1].charAt(0) + ".****" : "****");\n        }\n        }\n      }\n    }'
);

fs.writeFileSync('server.ts', code);
