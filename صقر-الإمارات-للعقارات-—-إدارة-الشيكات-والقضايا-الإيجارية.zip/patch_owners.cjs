const fs = require('fs');
let code = fs.readFileSync('src/components/master/OwnersView.tsx', 'utf8');

code = code.replace(/import { EmiratesIdScannerModal } from "\.\.\/emiratesId\/EmiratesIdScannerModal";/, 'import { SmartDocumentCaptureModal } from "../ai/SmartDocumentCaptureModal";');
code = code.replace(/import { EmiratesIdData } from "\.\.\/\.\.\/services\/emiratesIdService";/, '');

const oldModal = `<EmiratesIdScannerModal
        isOpen={isEidModalOpen}
        onClose={() => setIsEidModalOpen(false)}
        onConfirm={(data) => {
          setEmiratesId(data.emiratesIdNumber);
          setFullNameAr(data.arabicName);
          setFullNameEn(data.englishName);
          setDateOfBirth(data.dateOfBirth);
          setGender(data.gender);
          setCardNumber(data.cardNumber);
          setIssueDate(data.issueDate);
          setExpiryDate(data.expiryDate);
          
          if (!nameEn) setNameEn(data.englishName);
          if (!nameAr) setNameAr(data.arabicName);
          if (data.nationality) setNationality(data.nationality);
          
          setIsEidModalOpen(false);
        }}
      />`;

const newModal = `<SmartDocumentCaptureModal
        isOpen={isEidModalOpen}
        onClose={() => setIsEidModalOpen(false)}
        documentType="EMIRATES_ID"
        onApprove={(result) => {
          if (result.emiratesIdNumber?.value) setEmiratesId(result.emiratesIdNumber.value);
          if (result.arabicName?.value) setFullNameAr(result.arabicName.value);
          if (result.englishName?.value) setFullNameEn(result.englishName.value);
          
          if (!nameEn && result.englishName?.value) setNameEn(result.englishName.value);
          if (!nameAr && result.arabicName?.value) setNameAr(result.arabicName.value);
          
          setIsEidModalOpen(false);
        }}
      />`;
code = code.replace(/<EmiratesIdScannerModal[\s\S]*?\/>/, newModal);

fs.writeFileSync('src/components/master/OwnersView.tsx', code);
console.log('patched OwnersView');
