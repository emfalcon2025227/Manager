import re
with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

# Only keep the await batch.commit() in processUnifiedPayment and liquidateUnallocatedAdvance.
# How? Let's just find all "await batch.commit();\n    return { success: true, receipt };"
# and change them back, EXCEPT inside processUnifiedPayment.

text = text.replace(
    'await batch.commit();\n    return { success: true, receipt };',
    'return { success: true, receipt };'
)

# And now manually add them back at the end of processUnifiedPayment
match = re.search(r'(const processUnifiedPayment = async \(params: \{[\s\S]*?\}\): Promise<\{ success: boolean; receipt\?: CollectionRecord; error\?: string \}> => \{\n[\s\S]*?)(    return \{ success: true, receipt \};\n  \};\n)', text)
if match:
    text = text[:match.start(2)] + "    await batch.commit();\n" + match.group(2) + text[match.end(2):]

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
