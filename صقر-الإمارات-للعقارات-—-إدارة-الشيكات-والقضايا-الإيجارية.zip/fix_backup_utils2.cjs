const fs = require('fs');
let code = fs.readFileSync('src/server-utils/backupService.ts', 'utf8');

code = code.replace(/import archiver from 'archiver';/, `import archiver from 'archiver';`); // Actually just use any if needed
// Let's replace the resolve line
code = code.replace(/output\.on\('close', resolve\);/, `output.on('close', () => resolve(true));`);

// For TS1192:
code = code.replace(/import archiver from 'archiver';/, `import * as archiver from 'archiver';`);

fs.writeFileSync('src/server-utils/backupService.ts', code);
console.log("Fixed backupService.ts");
