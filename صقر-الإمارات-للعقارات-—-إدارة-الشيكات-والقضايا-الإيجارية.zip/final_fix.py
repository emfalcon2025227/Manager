import re

# Fix DataContext PeriodReconciliationInput
with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()
dc = dc.replace("      addDailyDeposit,", "      dailyDeposits,")
with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)

# Fix phase51 tests correctly
with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    t51 = f.read()

# Replace any occurrence of the object with "as any"
t51 = re.sub(r'\{\s+id: "DEP-1",\s+depositReference: "REF-123",\s+amount: 50000,\s+status: "RECONCILED",\s+\}', '({ id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)
t51 = re.sub(r'\{\s+id: "DEP-DUP",\s+depositReference: "REF-123",\s+amount: 50000,\s+status: "RECONCILED",\s+\}', '({ id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)

# Also there's one where id: "DEP-1" is by itself
t51 = re.sub(r'\{ id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "RECONCILED" \}', '({ id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)
t51 = re.sub(r'\{ id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "RECONCILED" \}', '({ id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any)', t51)

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t51)
    
# Fix phase52 tests
with open("src/utils/phase52DailyDepositsControlTests.ts", "r", encoding="utf-8") as f:
    t52 = f.read()

t52 = t52.replace('import { ContinuousFinancialControlEngine as FinancialEngine } from "../services/continuousFinancialControlEngine";', '')
t52 = t52.replace('const engine = new FinancialEngine();', '')
t52 = t52.replace('status: "COLLECTED",', '')
with open("src/utils/phase52DailyDepositsControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t52)

