import re

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    content = f.read()
    
# Find the exact syntax error at the end.
