const fs = require('fs');
let code = fs.readFileSync('src/components/ai/SmartDocumentCaptureModal.tsx', 'utf8');

const stateInsertion = `
  const [extractedData, setExtractedData] = useState<any>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [saveToArchive, setSaveToArchive] = useState(true);
`;
code = code.replace(/const \[extractedData, setExtractedData\] = useState<any>\(null\);\n  const \[isScannerOpen, setIsScannerOpen\] = useState\(false\);/, stateInsertion);

const interfaceInsertion = `
  onApprove: (
    result: ExtractionResult,
    imageBase64: string,
    mimeType: string,
    saveToArchive: boolean
  ) => void;
`;
code = code.replace(/onApprove: \([\s\S]*?\) => void;/, interfaceInsertion);

const approveInsertion = `
    onApprove(result, sourceImage!, sourceMime, saveToArchive);
`;
code = code.replace(/onApprove\(result, sourceImage!, sourceMime\);/, approveInsertion);

const uiInsertion = `
              <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-col gap-3">
                <label className="flex items-center gap-2 cursor-pointer text-sm text-slate-700 font-medium">
                  <input
                    type="checkbox"
                    checked={saveToArchive}
                    onChange={(e) => setSaveToArchive(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  {isAr ? "حفظ المستند في الأرشيف الإلكتروني" : "Save Document to Electronic Archive"}
                </label>
                <div className="flex justify-between">
                  <button
                    onClick={handleRetake}
                    className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-100 font-medium"
                  >
                    {isAr ? "إلغاء وإعادة" : "Cancel & Retake"}
                  </button>
                  <button
                    onClick={handleApprove}
                    className="px-6 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 font-bold flex items-center gap-2"
                  >
                    {isAr ? "موافقة واستخدام" : "Approve & Use Data"}
                  </button>
                </div>
              </div>
`;
code = code.replace(/<div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-between">[\s\S]*?<\/div>/, uiInsertion);

fs.writeFileSync('src/components/ai/SmartDocumentCaptureModal.tsx', code);
console.log('patched SmartDocumentCaptureModal');
