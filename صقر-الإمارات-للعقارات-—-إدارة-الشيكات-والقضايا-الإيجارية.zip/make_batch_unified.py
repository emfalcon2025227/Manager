import re

with open('src/context/DataContext.tsx', 'r') as f:
    content = f.read()

# Find processUnifiedPayment
match = re.search(r'(const processUnifiedPayment = async \(params: \{[\s\S]*?\}\): Promise<\{ success: boolean; receipt\?: CollectionRecord; error\?: string \}> => \{\n)([\s\S]*?)(  \};\n\n  const updateChequeWithSafetyConfirmation)', content)

if match:
    prefix = match.group(1)
    body = match.group(2)
    suffix = match.group(3)

    # Insert batch = writeBatch(db) at the beginning of the body
    body = "    const batch = writeBatch(db);\n" + body

    # Replace safeSetDoc with batch.set
    body = body.replace(
        'safeSetDoc(doc(db, "cheques", newChq.id), newChq);',
        'batch.set(doc(db, "cheques", newChq.id), sanitizeForFirestore(newChq));'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "collections", receipt.id), receipt);',
        'batch.set(doc(db, "collections", receipt.id), sanitizeForFirestore(receipt));'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "payment_allocations", alloc.id), alloc);',
        'batch.set(doc(db, "payment_allocations", alloc.id), sanitizeForFirestore(alloc));'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "commissions", c.id), updatedCom, { merge: true });',
        'batch.set(doc(db, "commissions", c.id), sanitizeForFirestore(updatedCom), { merge: true });'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "cheques", c.id), updatedChq, { merge: true });',
        'batch.set(doc(db, "cheques", c.id), sanitizeForFirestore(updatedChq), { merge: true });'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "leases", l.id), updatedLease, { merge: true });',
        'batch.set(doc(db, "leases", l.id), sanitizeForFirestore(updatedLease), { merge: true });'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "cheques", c.id), updated, { merge: true });',
        'batch.set(doc(db, "cheques", c.id), sanitizeForFirestore(updated), { merge: true });'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "cheques", cheque.id), { leaseId: l.id, propertyId: l.propertyId, unitId: l.unitId }, { merge: true });',
        'batch.set(doc(db, "cheques", cheque.id), sanitizeForFirestore({ leaseId: l.id, propertyId: l.propertyId, unitId: l.unitId }), { merge: true });'
    )

    # Note: syncChequeWithLease is NOT in processUnifiedPayment, so we won't accidentally touch it!

    body = body.replace(
        'return { success: true, receipt };',
        'await batch.commit();\n    return { success: true, receipt };'
    )

    new_content = content[:match.start()] + prefix + body + suffix + content[match.end():]
    with open('src/context/DataContext.tsx', 'w') as f:
        f.write(new_content)
    print("Patched processUnifiedPayment")
else:
    print("Could not find processUnifiedPayment")

