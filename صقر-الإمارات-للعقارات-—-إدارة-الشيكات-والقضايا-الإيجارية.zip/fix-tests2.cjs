const fs = require('fs');
let file = 'src/utils/phase24OperationalIntelligenceTests.ts';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/mockDoc\.driveWebViewLink\?\.includes/g, '!!mockDoc.driveWebViewLink?.includes');

fs.writeFileSync(file, content);
