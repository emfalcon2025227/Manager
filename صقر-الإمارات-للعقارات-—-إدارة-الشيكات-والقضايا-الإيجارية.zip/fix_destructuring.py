import re

with open("src/components/financials/DailyDepositsControlCenterView.tsx", "r", encoding="utf-8") as f:
    content = f.read()

content = content.replace("    receipts,\n", "")

with open("src/components/financials/DailyDepositsControlCenterView.tsx", "w", encoding="utf-8") as f:
    f.write(content)
