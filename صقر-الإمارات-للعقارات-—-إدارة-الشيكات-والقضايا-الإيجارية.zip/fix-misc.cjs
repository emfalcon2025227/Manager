const fs = require('fs');
let file;
let content;

file = 'src/components/leases/RenewalView.tsx';
if (fs.existsSync(file)) {
    content = fs.readFileSync(file, 'utf8');
    content = content.replace(/lease: selectedLease/g, 'lease: selectedLease || undefined');
    fs.writeFileSync(file, content);
}

file = 'src/components/maintenance/TechniciansModal.tsx';
if (fs.existsSync(file)) {
    content = fs.readFileSync(file, 'utf8');
    content = content.replace(/id: editingTech\?.id/g, 'id: editingTech?.id || ""');
    fs.writeFileSync(file, content);
}

file = 'src/components/master/LeaseEditorModal.tsx';
if (fs.existsSync(file)) {
    content = fs.readFileSync(file, 'utf8');
    content = content.replace(/value={inst\.chequeId}/g, 'value={inst.chequeId || ""}');
    fs.writeFileSync(file, content);
}

file = 'src/components/financials/OfficePettyCashView.tsx';
if (fs.existsSync(file)) {
    content = fs.readFileSync(file, 'utf8');
    content = content.replace(/transactionId: tx\?\.id/g, 'transactionId: tx?.id || ""');
    content = content.replace(/value={transactionId}/g, 'value={transactionId || ""}');
    fs.writeFileSync(file, content);
}

file = 'src/components/financials/PropertyExpensesView.tsx';
if (fs.existsSync(file)) {
    content = fs.readFileSync(file, 'utf8');
    content = content.replace(/exp\.vatAmount/g, '(exp.vatAmount || 0)');
    content = content.replace(/setPaymentMethod\(exp\.paymentMethod\)/g, 'setPaymentMethod(exp.paymentMethod || "TRANSFER")');
    fs.writeFileSync(file, content);
}

