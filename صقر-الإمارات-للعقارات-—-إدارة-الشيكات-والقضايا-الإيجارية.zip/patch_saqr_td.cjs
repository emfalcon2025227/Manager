const fs = require('fs');
let content = fs.readFileSync('src/components/financials/SaqrOfficeAccountView.tsx', 'utf8');

const target = `                    <td className="py-3 px-4 text-left font-mono font-black text-sm">
                      <span className={tx.type === "DEPOSIT" ? "text-emerald-600" : "text-rose-600"}>
                        {tx.type === "DEPOSIT" ? "+" : "-"} AED {tx.amount.toLocaleString()}
                      </span>
                    </td>`;

const replacement = `                    <td className="py-3 px-4 text-left">
                      <div className={\`font-mono font-black text-sm \${tx.type === "DEPOSIT" ? "text-emerald-600" : "text-rose-600"}\`}>
                        {tx.type === "DEPOSIT" ? "+" : "-"} AED {tx.amount.toLocaleString()}
                      </div>
                      {tx.netRevenue !== undefined && tx.vatAmount !== undefined && (
                        <div className="text-[10px] text-slate-500 mt-1 flex flex-col items-start font-mono">
                          <span>{isAr ? "الصافي:" : "Net:"} {tx.netRevenue.toLocaleString()}</span>
                          <span>{isAr ? "ضريبة:" : "VAT:"} {tx.vatAmount.toLocaleString()}</span>
                        </div>
                      )}
                    </td>`;

content = content.replace(target, replacement);
fs.writeFileSync('src/components/financials/SaqrOfficeAccountView.tsx', content);
console.log("Patch applied.");
