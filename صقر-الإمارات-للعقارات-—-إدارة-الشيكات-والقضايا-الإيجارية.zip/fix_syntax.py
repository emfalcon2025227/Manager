import re

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    content = f.read()

# Let's clean up the broken addDailyDeposit and updateDailyDeposit that might be duplicated.
# We will just write a regex to replace everything from the first "setDailyDeposits((prev) => [...prev, newDeposit]);" 
# to "const addDailyDeposit = async"
content = re.sub(r'      setDailyDeposits\(\(prev\) => \[\.\.\.prev, newDeposit\]\);\n      return \{ success: true, id: newDeposit\.id \};\n    \} catch \(err: any\) \{\n      return \{ success: false, error: err\.message \};\n    \}\n  \};\n\n    const addDailyDeposit = async', '    const addDailyDeposit = async', content)

# Also let's fix missing commas or closing brackets.
# Honestly it might be easier to just remove the broken block and insert it correctly above addOwnerTransfer.

# Let's remove from "const addDailyDeposit = async (deposit: Omit<DailyDepositRecord," up to the start of "const addOwnerTransfer"
# and replace it.

content = re.sub(r'  const addDailyDeposit = async \(deposit: Omit<DailyDepositRecord.*?  const addOwnerTransfer = async ', '  const addOwnerTransfer = async ', content, flags=re.DOTALL)
content = re.sub(r'  const updateDailyDeposit = async \(id: string, updates: Partial<DailyDepositRecord>.*?  const addOwnerTransfer = async ', '  const addOwnerTransfer = async ', content, flags=re.DOTALL)


# Now insert it cleanly above addOwnerTransfer
replacement = """
  const addDailyDeposit = async (deposit: Omit<DailyDepositRecord, "id" | "createdAt" | "createdBy">) => {
    try {
      if (!currentUser) throw new Error("Unauthorized");
      const newDeposit: DailyDepositRecord = {
        ...deposit,
        id: `DEP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        createdBy: currentUser.nameEn,
        createdAt: new Date().toISOString(),
      };
      setDailyDeposits((prev) => [...prev, newDeposit]);
      return { success: true, id: newDeposit.id };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateDailyDeposit = async (id: string, updates: Partial<DailyDepositRecord>) => {
    try {
      if (!currentUser) throw new Error("Unauthorized");
      setDailyDeposits((prev) => prev.map((d) => d.id === id ? { ...d, ...updates } : d));
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const addOwnerTransfer = async """

content = content.replace('  const addOwnerTransfer = async ', replacement)

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(content)
