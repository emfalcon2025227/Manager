import re

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    t51 = f.read()

# Let's just blindly replace all of those objects with type cast
t51 = t51.replace("id: \"DEP-1\",\n      depositReference: \"REF-123\",\n      amount: 50000,\n      status: \"RECONCILED\"", "id: \"DEP-1\", depositReference: \"REF-123\", amount: 50000, status: \"RECONCILED\" } as any, { id: \"ignore\"")
t51 = t51.replace("id: \"DEP-DUP\",\n        depositReference: \"REF-123\",\n        amount: 50000,\n        status: \"RECONCILED\"", "id: \"DEP-DUP\", depositReference: \"REF-123\", amount: 50000, status: \"RECONCILED\" } as any, { id: \"ignore\"")

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t51)

with open("src/utils/phase52DailyDepositsControlTests.ts", "r", encoding="utf-8") as f:
    t52 = f.read()

t52 = t52.replace("const mockCollections: CollectionRecord[] = [", "const mockCollections: any[] = [")

with open("src/utils/phase52DailyDepositsControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t52)

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()

dc = dc.replace("      dailyDeposits,\n      updateDailyDeposit,", "      dailyDeposits,")
dc = dc.replace("      addDailyDeposit,", "      addDailyDeposit,\n      dailyDeposits,")
dc = dc.replace("      dailyDeposits,\n      dailyDeposits,", "      dailyDeposits,")
with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)

