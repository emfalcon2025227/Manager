const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

if (!code.includes("server/backupService")) {
    const importStr = `
import { startScheduler, runBackup, runRestore } from "./server/backupService";
import { getAuth } from "firebase-admin/auth";
`;
    code = code.replace('import express from "express";', `import express from "express";\n${importStr}`);
}

const apiCode = `
app.post("/api/backups/manual", async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
        
        const token = authHeader.split('Bearer ')[1];
        const decoded = await getAuth().verifyIdToken(token);
        
        // Ensure user is authorized (check Firestore users collection)
        const admin = require('firebase-admin');
        const db = admin.firestore();
        const userDoc = await db.collection("users").doc(decoded.uid).get();
        if (!userDoc.exists) return res.status(403).json({ error: 'Forbidden' });
        const role = userDoc.data().role;
        if (role !== 'SYSTEM_OWNER' && role !== 'SUPER_ADMIN') {
            return res.status(403).json({ error: 'Insufficient permissions' });
        }
        
        const result = await runBackup('MANUAL');
        res.json({ success: true, result });
    } catch (e: any) {
        console.error("Manual backup error:", e);
        res.status(500).json({ error: e.message });
    }
});

app.post("/api/backups/restore", async (req, res) => {
    try {
        const { backupId } = req.body;
        if (!backupId) return res.status(400).json({ error: 'Missing backupId' });
        
        const authHeader = req.headers.authorization;
        if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
        
        const token = authHeader.split('Bearer ')[1];
        const decoded = await getAuth().verifyIdToken(token);
        
        // Ensure user is authorized
        const admin = require('firebase-admin');
        const db = admin.firestore();
        const userDoc = await db.collection("users").doc(decoded.uid).get();
        if (!userDoc.exists) return res.status(403).json({ error: 'Forbidden' });
        const user = userDoc.data();
        if (user.role !== 'SYSTEM_OWNER' && user.role !== 'SUPER_ADMIN') {
            return res.status(403).json({ error: 'Insufficient permissions for Restore' });
        }
        
        const result = await runRestore(backupId, decoded.uid, decoded.email || user.email);
        res.json({ success: true, result });
    } catch (e: any) {
        console.error("Restore error:", e);
        res.status(500).json({ error: e.message });
    }
});
`;

if (!code.includes("/api/backups/manual")) {
    code = code.replace(/app\.listen\(PORT, "0\.0\.0\.0", \(\) => \{/, `${apiCode}\n  app.listen(PORT, "0.0.0.0", () => {`);
}

if (!code.includes("startScheduler()")) {
    code = code.replace(/console\.log\(\`Server running on http:\/\/localhost:\$\{PORT\}\`\);/, "console.log(`Server running on http://localhost:${PORT}`);\n    startScheduler();");
}

fs.writeFileSync('server.ts', code);
console.log("server.ts patched.");
