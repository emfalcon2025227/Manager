import re

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()

# Fix 1: Remove updateDailyDeposit from reconcileFinancialPeriod
dc = dc.replace("        dailyDeposits,\n        updateDailyDeposit,\n        ownerTransfers,", "        dailyDeposits,\n        ownerTransfers,")

# Fix 2: At 11338: dailyDeposits, updateDailyDeposit -> dailyDeposits, addDailyDeposit, updateDailyDeposit
dc = dc.replace("      value={{\n        dailyDeposits,\n        updateDailyDeposit,\n        isQuotaExceeded,", "      value={{\n        dailyDeposits,\n        addDailyDeposit,\n        updateDailyDeposit,\n        isQuotaExceeded,")

# Fix 3: Remove duplicate dailyDeposits, updateDailyDeposit at 11486 (if any)
# We can just remove the block:
#         deleteJournalEntry,
#         dailyDeposits,
#         updateDailyDeposit,
#         ownerTransfers,
dc = dc.replace("        deleteJournalEntry,\n\n        dailyDeposits,\n        updateDailyDeposit,\n        ownerTransfers,", "        deleteJournalEntry,\n        ownerTransfers,")

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)
