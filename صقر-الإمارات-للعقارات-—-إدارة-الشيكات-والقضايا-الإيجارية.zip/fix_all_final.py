import re

# 1. DataContext.tsx
with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    content = f.read()

if "const [dailyDeposits, setDailyDeposits]" not in content:
    # Just insert it right after the DataProvider declaration
    content = content.replace("export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {", "export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {\n  const [dailyDeposits, setDailyDeposits] = useState<DailyDepositRecord[]>([]);")

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(content)

# 2. phase51ContinuousFinancialControlTests.ts
with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    test51 = f.read()

test51 = test51.replace("id: \"DEP-1\",", "id: \"DEP-1\" as any,")
test51 = test51.replace("id: \"DEP-DUP\",", "id: \"DEP-DUP\" as any,")

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(test51)

# 3. phase52DailyDepositsControlTests.ts
with open("src/utils/phase52DailyDepositsControlTests.ts", "r", encoding="utf-8") as f:
    test52 = f.read()

test52 = test52.replace("import { \n  FinancialEngine, \n  ReconciliationResult \n} from \"../services/continuousFinancialControlEngine\";", "import { ContinuousFinancialControlEngine as FinancialEngine } from \"../services/continuousFinancialControlEngine\";")
test52 = test52.replace("OwnerTransferRecord,\n  ReceiptRecord", "OwnerTransferRecord")
test52 = test52.replace("propertyId: \"P-1\",", "")
test52 = test52.replace("unitId: \"U-1\",", "")
test52 = test52.replace("unitId: \"U-2\",", "")
test52 = test52.replace("tenantId: \"T-1\",", "")
test52 = test52.replace("tenantId: \"T-2\",", "")
test52 = test52.replace("contractId: \"C-1\",", "")
test52 = test52.replace("contractId: \"C-2\",", "")

with open("src/utils/phase52DailyDepositsControlTests.ts", "w", encoding="utf-8") as f:
    f.write(test52)

