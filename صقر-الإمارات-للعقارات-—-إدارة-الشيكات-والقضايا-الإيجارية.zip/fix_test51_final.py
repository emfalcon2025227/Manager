import re
with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    t = f.read()

t = t.replace('id: "DEP-1",\n        depositReference', 'id: "DEP-1" as any,\n        depositReference')
t = t.replace('id: "DEP-DUP",\n        depositReference', 'id: "DEP-DUP" as any,\n        depositReference')

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t)
