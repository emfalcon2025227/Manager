import re

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    content = f.read()

# Fix Omit in context type
content = content.replace('addDailyDeposit: (deposit: Omit<DailyDepositRecord, "id" | "createdAt" | "createdBy">) =>', 'addDailyDeposit: (deposit: Omit<DailyDepositRecord, "id" | "createdAt" | "createdBy">) =>')

# Let's completely recreate the dailyDeposits logic by finding where ownerTransfers is,
# since the python script might have botched it.

# Remove the broken methods
content = re.sub(r'  const addDailyDeposit = async \(deposit: Omit<DailyDepositRecord.*?  \};\n', '', content, flags=re.DOTALL)
content = re.sub(r'  const updateDailyDeposit = async \(id: string, updates: Partial.*?  \};\n', '', content, flags=re.DOTALL)

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(content)
