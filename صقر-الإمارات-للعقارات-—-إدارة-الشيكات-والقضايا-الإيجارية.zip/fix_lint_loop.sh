#!/bin/bash
while true; do
  if grep -q "error TS" lint_output.txt; then
    break
  fi
  sleep 1
done
