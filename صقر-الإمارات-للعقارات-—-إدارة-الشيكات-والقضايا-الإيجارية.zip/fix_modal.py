import re
with open('src/components/master/ContractPaymentCenterModal.tsx', 'r') as f:
    text = f.read()

text = text.replace(
    "const handleSubmit = (e: React.FormEvent) => {",
    "const handleSubmit = async (e: React.FormEvent) => {"
)
text = text.replace(
    "const res = recordLeasePayment({",
    "const res = await recordLeasePayment({"
)

text = text.replace(
    "const handleLiquidateAdvance = () => {",
    "const handleLiquidateAdvance = async () => {"
)
text = text.replace(
    "const res = liquidateUnallocatedAdvance({",
    "const res = await liquidateUnallocatedAdvance({"
)

with open('src/components/master/ContractPaymentCenterModal.tsx', 'w') as f:
    f.write(text)
