const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

async function run() {
  // 15MB payload
  const largeBase64 = "a".repeat(15 * 1024 * 1024);
  try {
    console.log("Sending large request...");
    const res = await fetch("http://localhost:3000/api/ocr/extract-cheque", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imageBase64: largeBase64, mimeType: "image/jpeg" })
    });
    console.log("Status:", res.status);
    const text = await res.text();
    console.log("Response:", text.substring(0, 100));
  } catch (e) {
    console.error("Error:", e);
  }
}
run();
