const fs = require('fs');

let content = fs.readFileSync('src/context/DataContext.tsx', 'utf8');

const oldImplStart = `  const collectAdministrativeFee = (`;
const idx = content.indexOf(oldImplStart);
if (idx === -1) {
  console.log('Impl not found');
  process.exit(1);
}
const reverseIdx = content.indexOf(`  const reverseCommissionObligation = `, idx);
if (reverseIdx === -1) {
  console.log('Reverse not found');
  process.exit(1);
}

const newImpl = `  const collectAdministrativeFee = async (
    id: string,
    amount: number,
    paymentMethod: PaymentMethod,
    referenceNumber?: string,
    notes?: string,
    idempotencyKey?: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const userId = currentUser?.id || "sys";
      const userName = currentUser?.nameAr || currentUser?.nameEn || "مدير النظام";

      // Deterministic IDs for idempotency
      const receiptId = idempotencyKey ? \`col-adm-\${idempotencyKey}\` : \`col-adm-\${id}-\${Date.now()}\`;
      const allocationId = idempotencyKey ? \`all-adm-\${idempotencyKey}\` : \`all-adm-\${id}-\${Date.now()}\`;

      let updatedCommission: CommissionObligation | null = null;
      let newReceipt: CollectionRecord | null = null;
      let newAllocation: PaymentAllocation | null = null;

      await runTransaction(db, async (transaction) => {
        const commRef = doc(db, "commissions", id);
        const commSnap = await transaction.get(commRef);

        if (!commSnap.exists()) {
          throw new Error("سجل الرسوم غير موجود.");
        }

        const commData = commSnap.data();

        if (commData.status === "FULLY_COLLECTED") {
          throw new Error("تم تحصيل هذه الرسوم بالكامل مسبقاً.");
        }

        const availableBalance = commData.totalCommissionAmount - (commData.collectedAmount || 0);
        if (amount > availableBalance + 0.01) {
          throw new Error("المبلغ يتجاوز الرصيد المتبقي.");
        }

        const receiptRef = doc(db, "collections", receiptId);
        const receiptSnap = await transaction.get(receiptRef);
        if (receiptSnap.exists()) {
          // Idempotency: Already processed!
          return;
        }

        // Determine payer name directly within transaction closure (since tenants/owners are in state and we have access)
        let refinedPayerName = userName;
        if (commData.partyType === "TENANT" && commData.tenantId) {
          const t = tenants.find(tt => tt.id === commData.tenantId);
          if (t) refinedPayerName = language === "ar" ? t.nameAr : t.nameEn;
        } else if (commData.partyType === "OWNER" && commData.ownerId) {
          const o = owners.find(oo => oo.id === commData.ownerId);
          if (o) refinedPayerName = language === "ar" ? o.nameAr : o.nameEn;
        }

        updatedCommission = {
          ...commData,
          collectedAmount: (commData.collectedAmount || 0) + amount,
          status: (commData.collectedAmount || 0) + amount >= commData.totalCommissionAmount - 0.01 ? "FULLY_COLLECTED" : "PARTIALLY_COLLECTED",
          paymentMethod,
          transactionReference: referenceNumber,
          notes: notes ? (commData.notes ? \`\${commData.notes} | \${notes}\` : notes) : commData.notes,
          updatedAt: new Date().toISOString(),
          updatedById: userId,
          updatedByName: userName,
        };

        newReceipt = {
          id: receiptId,
          receiptNumber: "RCP-ADM-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000),
          tenantId: commData.tenantId || "",
          ownerId: commData.ownerId || "",
          paymentDate: new Date().toISOString().split("T")[0],
          amountEntered: amount,
          amountApplied: amount,
          adminFeeAmount: amount, // SYNCHRONIZATION FIELD for SaqrOfficeAccountView
          paymentMethod,
          transactionReference: referenceNumber,
          payerName: refinedPayerName,
          collectedBy: userName,
          collectedByUserId: userId,
          notes: notes || \`Administrative Fee Collection: \${commData.commissionType}\`,
          createdAt: new Date().toISOString(),
          idempotencyKey,
        };

        newAllocation = {
          id: allocationId,
          collectionId: receiptId,
          targetType: "COMMISSION",
          targetId: id,
          targetDescription: \`Administrative Fee: \${commData.commissionType}\`,
          allocatedAmount: amount,
          allocationDate: newReceipt.paymentDate,
          status: "ACTIVE",
          createdAt: newReceipt.createdAt,
          createdById: userId,
          idempotencyKey,
        };

        transaction.set(commRef, updatedCommission, { merge: true });
        transaction.set(receiptRef, newReceipt);
        transaction.set(doc(db, "payment_allocations", allocationId), newAllocation);
      });

      // If return was early due to idempotency, no state update needed
      if (!updatedCommission || !newReceipt || !newAllocation) {
        return { success: true };
      }

      setCommissions((prev) => prev.map((c) => (c.id === id ? updatedCommission : c)));
      setCollections((prev) => [newReceipt, ...prev]);
      setPaymentAllocations((prev) => [newAllocation, ...prev]);

      logAudit(
        "FINANCIAL_PAYMENT",
        "COLLECTION",
        newReceipt.id,
        \`Receipt #\${newReceipt.receiptNumber}\`,
        \`تحصيل رسوم إدارية بمبلغ \${amount.toLocaleString()} AED (\${paymentMethod})\`
      );

      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  };

`;

content = content.substring(0, idx) + newImpl + content.substring(reverseIdx);
fs.writeFileSync('src/context/DataContext.tsx', content);
console.log('done');
