import re
with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

# 1. processUnifiedPayment
text = re.sub(
    r'(const processUnifiedPayment = async \(params: \{[\s\S]*?\}\): Promise<\{ success: boolean; receipt\?: CollectionRecord; error\?: string \}> => \{\n)',
    r'\1    const batch = writeBatch(db);\n',
    text
)

# 2. liquidateUnallocatedAdvance
text = re.sub(
    r'(const liquidateUnallocatedAdvance = async \(params: \{[\s\S]*?\}\): Promise<\{ success: boolean; allocatedCount: number; error\?: string \}> => \{\n)',
    r'\1    const batch = writeBatch(db);\n',
    text
)

# 3. importData chunk logic (I'll just restore them safely)
text = text.replace(
    'for (let i = 0; i < chunks.length; i++) {\n          const chunk = chunks[i];',
    'for (let i = 0; i < chunks.length; i++) {\n          const batch = writeBatch(db);\n          const chunk = chunks[i];'
)
text = text.replace(
    'for (let i = 0; i < tenantChunks.length; i++) {\n          const chunk = tenantChunks[i];',
    'for (let i = 0; i < tenantChunks.length; i++) {\n          const batch = writeBatch(db);\n          const chunk = tenantChunks[i];'
)
text = text.replace(
    'for (let i = 0; i < receiptsChunks.length; i++) {\n            const chunk = receiptsChunks[i];',
    'for (let i = 0; i < receiptsChunks.length; i++) {\n            const batch = writeBatch(db);\n            const chunk = receiptsChunks[i];'
)

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
