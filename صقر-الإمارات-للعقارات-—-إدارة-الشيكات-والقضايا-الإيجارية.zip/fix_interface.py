import re
with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

text = text.replace(
    "recordLeasePayment: (params: {",
    "recordLeasePayment: (params: {"
) # just to locate it, wait, it's easier:

text = re.sub(
    r"recordLeasePayment: \(params: \{([\s\S]*?)\}\) => \{ success: boolean; receipt\?: CollectionRecord; error\?: string \};",
    r"recordLeasePayment: (params: {\1}) => Promise<{ success: boolean; receipt?: CollectionRecord; error?: string }>;",
    text
)
text = re.sub(
    r"liquidateUnallocatedAdvance: \(params: \{([\s\S]*?)\}\) => \{ success: boolean; allocatedCount: number; error\?: string \};",
    r"liquidateUnallocatedAdvance: (params: {\1}) => Promise<{ success: boolean; allocatedCount: number; error?: string }>;",
    text
)
text = re.sub(
    r"updateChequeWithSafetyConfirmation: \(params: ChequeSecurityConfirmationParams\) => \{ success: boolean; receipt\?: CollectionRecord; error\?: string \};",
    r"updateChequeWithSafetyConfirmation: (params: ChequeSecurityConfirmationParams) => Promise<{ success: boolean; receipt?: CollectionRecord; error?: string }>;",
    text
)

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
