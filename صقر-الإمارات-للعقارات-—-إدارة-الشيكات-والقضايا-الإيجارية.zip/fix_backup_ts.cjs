const fs = require('fs');

// Fix backupService.ts
let code = fs.readFileSync('server/backupService.ts', 'utf8');
code = code.replace(/const year = p\('year'\)!;/g, "const year = p('year') || 'YYYY';");
code = code.replace(/const month = p\('month'\)!;/g, "const month = p('month') || 'MM';");
fs.writeFileSync('server/backupService.ts', code);

// Fix server.ts (add explicit typing to (req, res))
let serverCode = fs.readFileSync('server.ts', 'utf8');
serverCode = serverCode.replace(/app\.post\("\/api\/backups\/manual", async \(req, res\) => \{/g, 'app.post("/api/backups/manual", async (req: express.Request, res: express.Response): Promise<void> => {');
serverCode = serverCode.replace(/app\.post\("\/api\/backups\/restore", async \(req, res\) => \{/g, 'app.post("/api/backups/restore", async (req: express.Request, res: express.Response): Promise<void> => {');
serverCode = serverCode.replace(/const decoded = await getAuth\(\)\.verifyIdToken\(token\);/g, "const decoded = await getAuth().verifyIdToken(token);");
fs.writeFileSync('server.ts', serverCode);

console.log("Types fixed.");
