const fs = require('fs');

let content = fs.readFileSync('server.ts', 'utf8');

const regex = /async function generateContentWithFallback[\s\S]*?throw lastError \|\| new Error\("All AI models unavailable"\);\n\}/;
const replacement = `async function generateContentWithFallback(ai: GoogleGenAI, requestParams: {
  models?: string[];
  contents: any;
  config?: any;
}) {
  const models = requestParams.models || [
    AI_DOCUMENT_MODEL,
    ...AI_DOCUMENT_FALLBACK_MODELS
  ];
  let lastError: any = null;

  for (const model of models) {
    try {
      const resp = await ai.models.generateContent({
        model,
        contents: requestParams.contents,
        config: requestParams.config,
      });
      if (resp && resp.text) {
        return { text: resp.text, model };
      }
    } catch (err: any) {
      if (isAuthError(err)) {
        console.info("[Gemini AI] API key unauthorized or unconfigured (401). Switching to local fallback pipeline.");
        isKeyMarkedUnauthorized = true;
        aiClient = null;
        throw new Error("GEMINI_AUTH_UNAUTHORIZED");
      }
      lastError = err;
      if (err?.status === 429 || err?.message?.includes("429") || err?.message?.includes("quota") || err?.message?.includes("RESOURCE_EXHAUSTED")) {
        continue;
      }
    }

    if (requestParams.config?.responseSchema) {
      try {
        const resp = await ai.models.generateContent({
          model,
          contents: requestParams.contents,
          config: { responseMimeType: "application/json" },
        });
        if (resp && resp.text) {
          return { text: resp.text, model };
        }
      } catch (err: any) {
        if (isAuthError(err)) {
          isKeyMarkedUnauthorized = true;
          aiClient = null;
          throw new Error("GEMINI_AUTH_UNAUTHORIZED");
        }
        lastError = err;
        if (err?.status === 429 || err?.message?.includes("429") || err?.message?.includes("quota") || err?.message?.includes("RESOURCE_EXHAUSTED")) {
          continue;
        }
      }
    }

    try {
      const resp = await ai.models.generateContent({
        model,
        contents: requestParams.contents,
      });
      if (resp && resp.text) {
        return { text: resp.text, model };
      }
    } catch (err: any) {
      if (isAuthError(err)) {
        isKeyMarkedUnauthorized = true;
        aiClient = null;
        throw new Error("GEMINI_AUTH_UNAUTHORIZED");
      }
      lastError = err;
      if (err?.status === 429 || err?.message?.includes("429") || err?.message?.includes("quota") || err?.message?.includes("RESOURCE_EXHAUSTED")) {
        continue;
      }
    }
  }

  throw lastError || new Error("All AI models unavailable");
}`;

content = content.replace(regex, replacement);
fs.writeFileSync('server.ts', content, 'utf8');
