import re

with open('src/context/DataContext.tsx', 'r') as f:
    content = f.read()

match = re.search(r'(const liquidateUnallocatedAdvance = async \(params: \{[\s\S]*?\}\): Promise<\{ success: boolean; allocatedCount: number; error\?: string \}> => \{\n)([\s\S]*?)(  \};\n\n  const collectAdministrativeFee)', content)

if match:
    prefix = match.group(1)
    body = match.group(2)
    suffix = match.group(3)

    body = "    const batch = writeBatch(db);\n" + body

    body = body.replace(
        'safeSetDoc(doc(db, "payment_allocations", newAlloc.id), newAlloc);',
        'batch.set(doc(db, "payment_allocations", newAlloc.id), sanitizeForFirestore(newAlloc));'
    )
    body = body.replace(
        'safeSetDoc(doc(db, "collections", item.col.id), { amountApplied: newApplied }, { merge: true });',
        'batch.set(doc(db, "collections", item.col.id), sanitizeForFirestore({ amountApplied: newApplied }), { merge: true });'
    )

    body = body.replace(
        'return { success: true, allocatedCount: newAllocations.length };',
        'await batch.commit();\n    return { success: true, allocatedCount: newAllocations.length };'
    )

    new_content = content[:match.start()] + prefix + body + suffix + content[match.end():]
    with open('src/context/DataContext.tsx', 'w') as f:
        f.write(new_content)
    print("Patched liquidateUnallocatedAdvance")
else:
    print("Could not find liquidateUnallocatedAdvance")

