const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const route = `
// Receipt QR Code Verification
app.get("/api/verify/receipt/:token", async (req, res) => {
  try {
    const token = req.params.token;
    if (!token) return res.status(400).json({ error: "Missing verification token" });

    const db = getFirestore();
    const docRef = db.collection('collections').doc(token);
    const docSnap = await docRef.get();

    if (!docSnap.exists) {
      return res.status(404).json({ valid: false, error: "NOT_FOUND" });
    }

    const receipt = docSnap.data();

    // Check if reversed
    let status = "VERIFIED";
    if (receipt.isReversed || receipt.status === 'CANCELLED' || receipt.status === 'REVERSED') {
      status = "REVERSED";
    }

    res.json({
      valid: true,
      receiptNumber: receipt.receiptNumber,
      amount: receipt.amountEntered || receipt.amountApplied,
      currency: "AED",
      paymentDate: receipt.paymentDate,
      paymentMethod: receipt.paymentMethod,
      tenantId: receipt.tenantId, // Can't easily look up tenant name without another query, so we'll do that
      payerName: receipt.payerName,
      status: status
    });
  } catch (error) {
    console.error("Receipt Verification Error:", error);
    res.status(500).json({ error: "INTERNAL_SERVER_ERROR" });
  }
});
`;

code = code.replace('// Download Audit Report (Markdown format)', route + '\n// Download Audit Report (Markdown format)');
fs.writeFileSync('server.ts', code);
