const fs = require('fs');
let content = fs.readFileSync('src/components/financials/FinancialOverview.tsx', 'utf8');

// 1. Calculate the total net and vat for all commissions
const targetKPIs = `  const totalTransfers = systemFinancials.reduce((sum, o) => sum + o.totalTransfersPaid, 0);`;
const replacementKPIs = `  const totalTransfers = systemFinancials.reduce((sum, o) => sum + o.totalTransfersPaid, 0);

  // Office Revenue (All Commissions: Owner + Tenant)
  const validCommissions = commissions.filter(c => c.status !== "CANCELLED" && c.status !== "REVERSED");
  const totalGrossCommissions = validCommissions.reduce((sum, c) => sum + (c.totalCommissionAmount || 0), 0);
  const totalNetCommissions = validCommissions.reduce((sum, c) => sum + (c.netRevenueAmount || c.totalCommissionAmount - (c.vatAmount || 0) || 0), 0);
  const totalVatCommissions = validCommissions.reduce((sum, c) => sum + (c.vatAmount || 0), 0);`;
content = content.replace(targetKPIs, replacementKPIs);

// 2. Modify the kpis array
const targetKpiArray = `    {
      id: "commissions",
      title: isAr ? "إجمالي العمولات" : "Total Commissions",
      value: totalCommissions.toLocaleString(),
      change: "+8%",
      icon: TrendingUp,
      color: "text-indigo-600",
      bg: "bg-indigo-50",
    },`;
const replacementKpiArray = `    {
      id: "commissions",
      title: isAr ? "العمولات (إجمالي)" : "Gross Commissions",
      value: totalGrossCommissions.toLocaleString(),
      change: "+8%",
      icon: TrendingUp,
      color: "text-indigo-600",
      bg: "bg-indigo-50",
      subMetrics: [
        { label: isAr ? "الصافي:" : "Net:", value: totalNetCommissions },
        { label: isAr ? "الضريبة:" : "VAT:", value: totalVatCommissions }
      ]
    },`;
content = content.replace(targetKpiArray, replacementKpiArray);

// 3. Render the subMetrics
const targetRender = `            <div className="text-2xl font-black text-slate-900 dark:text-white mb-1">
              {kpi.value} <span className="text-xs font-bold text-slate-400">AED</span>
            </div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">{kpi.title}</div>
          </div>`;
const replacementRender = `            <div className="text-2xl font-black text-slate-900 dark:text-white mb-1">
              {kpi.value} <span className="text-xs font-bold text-slate-400">AED</span>
            </div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{kpi.title}</div>
            {kpi.subMetrics && (
              <div className="flex items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-700/50">
                {kpi.subMetrics.map((sm, idx) => (
                  <div key={idx} className="flex items-center gap-1">
                    <span className="text-[10px] text-slate-400">{sm.label}</span>
                    <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300">{sm.value.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>`;
content = content.replace(targetRender, replacementRender);

fs.writeFileSync('src/components/financials/FinancialOverview.tsx', content);
console.log("Patch applied to FinancialOverview.");
