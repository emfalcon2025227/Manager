import fs from 'fs';

let content = fs.readFileSync('src/context/DataContext.tsx', 'utf8');

const oldInterface = `collectAdministrativeFee: (id: string, amount: number, paymentMethod: PaymentMethod, referenceNumber?: string, notes?: string) => Promise<{ success: boolean; error?: string }>;`;
const newInterface = `collectAdministrativeFee: (id: string, amount: number, paymentMethod: PaymentMethod, referenceNumber?: string, notes?: string, idempotencyKey?: string) => Promise<{ success: boolean; error?: string }>;`;

content = content.replace(oldInterface, newInterface);

const oldImplStart = `  const collectAdministrativeFee = (`;
const idx = content.indexOf(oldImplStart);
if (idx === -1) {
  console.log('Impl not found');
  process.exit(1);
}
const reverseIdx = content.indexOf(`  const reverseCommissionObligation = `, idx);
if (reverseIdx === -1) {
  console.log('Reverse not found');
  process.exit(1);
}

const newImpl = `  const collectAdministrativeFee = async (
    id: string,
    amount: number,
    paymentMethod: PaymentMethod,
    referenceNumber?: string,
    notes?: string,
    idempotencyKey?: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const userId = currentUser?.id || "sys";
      const userName = currentUser?.nameAr || currentUser?.nameEn || "مدير النظام";

      // Deterministic IDs for idempotency
      const receiptId = idempotencyKey ? \`col-adm-\${idempotencyKey}\` : \`col-adm-\${id}-\${Date.now()}\`;
      const allocationId = idempotencyKey ? \`all-adm-\${idempotencyKey}\` : \`all-adm-\${id}-\${Date.now()}\`;

      let updatedCommission: CommissionObligation | null = null;
      let newReceipt: CollectionRecord | null = null;
      let newAllocation: PaymentAllocation | null = null;

      await runTransaction(db, async (transaction) => {
        const commRef = doc(db, "commissions", id);
        const commSnap = await transaction.get(commRef);

        if (!commSnap.exists()) {
          throw new Error("سجل الرسوم غير موجود.");
        }

        const commData = commSnap.data() as CommissionObligation;

        if (commData.status === "FULLY_COLLECTED") {
          throw new Error("تم تحصيل هذه الرسوم بالكامل مسبقاً.");
        }

        const availableBalance = commData.totalCommissionAmount - (commData.collectedAmount || 0);
        if (amount > availableBalance + 0.01) {
          throw new Error("المبلغ يتجاوز الرصيد المتبقي.");
        }

        const receiptRef = doc(db, "collections", receiptId);
        const receiptSnap = await transaction.get(receiptRef);
        if (receiptSnap.exists()) {
          // Idempotency: Already processed!
          return;
        }

        updatedCommission = {
          ...commData,
          collectedAmount: (commData.collectedAmount || 0) + amount,
          status: (commData.collectedAmount || 0) + amount >= commData.totalCommissionAmount - 0.01 ? "FULLY_COLLECTED" : "PARTIALLY_COLLECTED",
          paymentMethod,
          transactionReference: referenceNumber,
          notes: notes ? (commData.notes ? \`\${commData.notes} | \${notes}\` : notes) : commData.notes,
          updatedAt: new Date().toISOString(),
          updatedById: userId,
          updatedByName: userName,
        };

        newReceipt = {
          id: receiptId,
          receiptNumber: "RCP-ADM-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000),
          tenantId: commData.tenantId || "",
          ownerId: commData.ownerId || "",
          paymentDate: new Date().toISOString().split("T")[0],
          amountEntered: amount,
          amountApplied: amount,
          adminFeeAmount: amount, // SYNCHRONIZATION FIELD for SaqrOfficeAccountView
          paymentMethod,
          transactionReference: referenceNumber,
          payerName: userName, // Will refine below
          collectedBy: userName,
          collectedByUserId: userId,
          notes: notes || \`Administrative Fee Collection: \${commData.commissionType}\`,
          createdAt: new Date().toISOString(),
          idempotencyKey,
        };

        newAllocation = {
          id: allocationId,
          collectionId: receiptId,
          targetType: "COMMISSION",
          targetId: id,
          targetDescription: \`Administrative Fee: \${commData.commissionType}\`,
          allocatedAmount: amount,
          allocationDate: newReceipt.paymentDate,
          status: "ACTIVE",
          createdAt: newReceipt.createdAt,
          createdById: userId,
          idempotencyKey,
        };

        transaction.set(commRef, updatedCommission, { merge: true });
        transaction.set(receiptRef, newReceipt);
        transaction.set(doc(db, "payment_allocations", allocationId), newAllocation);
      });

      // If return was early due to idempotency, no state update needed
      if (!updatedCommission || !newReceipt || !newAllocation) {
        return { success: true };
      }

      // Refine payer name based on party type for local state (receipt is already written but this is fine, or we can do it inside transaction)
      // Actually let's just do it here to update local state, though ideally it should be inside transaction.
      // Better to do it before write. But we don't have tenants/owners easily inside runTransaction unless we get them.
      // But we have them in closure! They are in state. So we can refine it before set.
      if (updatedCommission.partyType === "TENANT" && updatedCommission.tenantId) {
        const t = tenants.find(tt => tt.id === updatedCommission!.tenantId);
        if (t) newReceipt.payerName = language === "ar" ? t.nameAr : t.nameEn;
      } else if (updatedCommission.partyType === "OWNER" && updatedCommission.ownerId) {
        const o = owners.find(oo => oo.id === updatedCommission!.ownerId);
        if (o) newReceipt.payerName = language === "ar" ? o.nameAr : o.nameEn;
      }
      
      // Update the DB document if we refined the name (this is a fast follow-up, or we could have just passed the name into the transaction)
      if (newReceipt.payerName !== userName) {
        safeSetDoc(doc(db, "collections", receiptId), { payerName: newReceipt.payerName }, { merge: true });
      }

      setCommissions((prev) => prev.map((c) => (c.id === id ? updatedCommission! : c)));
      setCollections((prev) => [newReceipt!, ...prev]);
      setPaymentAllocations((prev) => [newAllocation!, ...prev]);

      logAudit(
        "FINANCIAL_PAYMENT",
        "COLLECTION",
        newReceipt.id,
        \`Receipt #\${newReceipt.receiptNumber}\`,
        \`تحصيل رسوم إدارية بمبلغ \${amount.toLocaleString()} AED (\${paymentMethod})\`
      );

      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

`;

content = content.substring(0, idx) + newImpl + content.substring(reverseIdx);
fs.writeFileSync('src/context/DataContext.tsx', content);
console.log('done');
