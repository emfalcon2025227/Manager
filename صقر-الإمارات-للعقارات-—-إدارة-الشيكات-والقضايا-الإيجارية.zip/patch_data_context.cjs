const fs = require('fs');
let code = fs.readFileSync('src/context/DataContext.tsx', 'utf8');

const interfaceInsertion = `
  extractChequeOCR: (imageBase64: string, mimeType?: string) => Promise<any>;
  extractDocumentOCR: (documentType: string, imageBase64: string, mimeType?: string) => Promise<any>;
`;
code = code.replace(/extractChequeOCR: \(imageBase64: string, mimeType\?: string\) => Promise<any>;/g, interfaceInsertion);

const implementationInsertion = `
  const extractDocumentOCR = async (documentType: string, imageBase64: string, mimeType = "image/jpeg"): Promise<any> => {
    try {
      const res = await fetch("/api/ocr/extract-document", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ documentType, imageBase64, mimeType }),
      });
      const data = await res.json();
      return data;
    } catch (e: any) {
      console.error("OCR API error:", e);
      return { success: false, error: e.message || "Failed to process OCR" };
    }
  };

  const extractChequeOCR = async (imageBase64: string, mimeType = "image/jpeg"): Promise<any> => {
`;

code = code.replace(/const extractChequeOCR = async \(imageBase64: string, mimeType = "image\/jpeg"\): Promise<any> => \{/g, implementationInsertion);

code = code.replace(/extractChequeOCR,\n/g, "extractChequeOCR,\n        extractDocumentOCR,\n");

fs.writeFileSync('src/context/DataContext.tsx', code);
console.log("patched DataContext");
