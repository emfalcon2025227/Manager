import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
try {
  admin.initializeApp();
  console.log("Initialized");
  const db = getFirestore();
  console.log("Got DB");
} catch(e) {
  console.error(e);
}
