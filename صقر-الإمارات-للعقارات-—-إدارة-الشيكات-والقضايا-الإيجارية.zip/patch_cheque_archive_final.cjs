const fs = require('fs');
let code = fs.readFileSync('src/components/cheques/AddChequeModal.tsx', 'utf8');

const commitSaveRegex = /const newChq = addCheque\(\{[\s\S]*?\}\);/;
const match = code.match(commitSaveRegex);
if (!match) {
  console.log('could not find newChq');
  process.exit(1);
}

const archiveInsertion = `
    if (newChq && smartCaptureArchiveDoc && addArchiveItem) {
      addArchiveItem({
        fileName: \`CHEQUE_\${newChq.chequeNumber}\`,
        category: "CHEQUE",
        recordId: newChq.id,
        recordTitle: \`Cheque #\${newChq.chequeNumber}\`,
        fileType: smartCaptureArchiveDoc.mime,
        fileSize: Math.round(smartCaptureArchiveDoc.base64.length * 0.75),
        fileHash: \`\${Date.now()}\`,
        isPrivate: true,
        storagePath: \`cheques/\${newChq.id}\`,
        tags: ["CHEQUE", "OCR", "SMART_CAPTURE"],
        entityType: "CHEQUE",
        entityId: newChq.id,
      });
    }
`;

code = code.replace(commitSaveRegex, match[0] + archiveInsertion);

fs.writeFileSync('src/components/cheques/AddChequeModal.tsx', code);
console.log('patched AddChequeModal with archive');
