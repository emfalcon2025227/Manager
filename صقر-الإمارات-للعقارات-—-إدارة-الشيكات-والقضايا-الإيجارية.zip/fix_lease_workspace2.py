import re
with open('src/components/master/LeaseWorkspaceModal.tsx', 'r') as f:
    text = f.read()

text = re.sub(r'const handleAddPayment = \((.*?)\) => \{', r'const handleAddPayment = async (\1) => {', text)
text = re.sub(r'const handleLiquidate = \((.*?)\) => \{', r'const handleLiquidate = async (\1) => {', text)
text = re.sub(r'const handleChequeAction = \((.*?)\) => \{', r'const handleChequeAction = async (\1) => {', text)
text = re.sub(r'const handleSubmitAction = \((.*?)\) => \{', r'const handleSubmitAction = async (\1) => {', text)

with open('src/components/master/LeaseWorkspaceModal.tsx', 'w') as f:
    f.write(text)
