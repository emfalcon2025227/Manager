const fs = require('fs');
let code = fs.readFileSync('src/services/ocr/v2/OCRV2Engine.ts', 'utf-8');

code = code.replace(
  /if \(\!response\.ok\) \{[\s\S]*?continue;\n\s+\}\n\s+const jsonRes \= await response\.json\(\);/,
  "let jsonRes = await response.json().catch(() => null); if (!jsonRes) continue;"
);

fs.writeFileSync('src/services/ocr/v2/OCRV2Engine.ts', code, 'utf-8');
console.log("Replaced");
