const fs = require('fs');
let code = fs.readFileSync('src/components/master/TenantsView.tsx', 'utf8');

const stateInsertion = `
  const [smartCaptureArchiveDoc, setSmartCaptureArchiveDoc] = useState<{ base64: string, mime: string } | null>(null);
`;
code = code.replace(/const \[isEidModalOpen, setIsEidModalOpen\] = useState\(false\);/, "const [isEidModalOpen, setIsEidModalOpen] = useState(false);\n" + stateInsertion);

const oldModalRegex = /<SmartDocumentCaptureModal[\s\S]*?onApprove=\{\(result\) => \{[\s\S]*?\}\}\n      \/>/;
const newModal = `<SmartDocumentCaptureModal
        isOpen={isEidModalOpen}
        onClose={() => setIsEidModalOpen(false)}
        documentType="EMIRATES_ID"
        onApprove={(result, imageBase64, mimeType, saveToArchive) => {
          if (result.emiratesIdNumber?.value) setEmiratesId(result.emiratesIdNumber.value);
          if (result.arabicName?.value) setFullNameAr(result.arabicName.value);
          if (result.englishName?.value) setFullNameEn(result.englishName.value);
          if (result.dateOfBirth?.value) setDateOfBirth(result.dateOfBirth.value);
          if (result.gender?.value) setGender(result.gender.value);
          if (result.cardNumber?.value) setCardNumber(result.cardNumber.value);
          if (result.issueDate?.value) setIssueDate(result.issueDate.value);
          if (result.expiryDate?.value) setExpiryDate(result.expiryDate.value);
          
          if (!nameEn && result.englishName?.value) setNameEn(result.englishName.value);
          if (!nameAr && result.arabicName?.value) setNameAr(result.arabicName.value);
          if (result.nationality?.value) setNationality(result.nationality.value);
          
          if (saveToArchive) {
            setSmartCaptureArchiveDoc({ base64: imageBase64, mime: mimeType });
          } else {
            setSmartCaptureArchiveDoc(null);
          }
          
          setIsEidModalOpen(false);
        }}
      />`;
code = code.replace(oldModalRegex, newModal);


const addTenantRegex = /addTenant\(\{[\s\S]*?\}\);/;
const match = code.match(addTenantRegex);
if (match) {
  const addTenantInsertion = `
      const newTenant = ${match[0].replace(/addTenant/, 'addTenant')}
      if (newTenant && smartCaptureArchiveDoc && addArchiveItem) {
        addArchiveItem({
          fileName: \`EID_\${newTenant.emiratesId}\`,
          category: "EMIRATES_ID",
          recordId: newTenant.id,
          recordTitle: \`Emirates ID \${newTenant.emiratesId}\`,
          fileType: smartCaptureArchiveDoc.mime,
          fileSize: Math.round(smartCaptureArchiveDoc.base64.length * 0.75),
          fileHash: \`\${Date.now()}\`,
          isPrivate: true,
          storagePath: \`tenants/\${newTenant.id}/documents\`,
          tags: ["EMIRATES_ID", "OCR", "SMART_CAPTURE"],
          entityType: "TENANT",
          entityId: newTenant.id,
        });
      }
      setSmartCaptureArchiveDoc(null);
`;
  code = code.replace(addTenantRegex, addTenantInsertion);
}

fs.writeFileSync('src/components/master/TenantsView.tsx', code);
console.log('patched TenantsView archive');
