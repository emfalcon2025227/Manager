with open("src/components/master/LeaseEditorModal.tsx", "r", encoding="utf-8") as f:
    text = f.read()

stack = []
for i, c in enumerate(text):
    if c in '({[':
        stack.append((c, i))
    elif c in ')}]':
        if not stack:
            print(f"Unmatched {c} at index {i}")
        else:
            op, idx = stack.pop()
            if (op == '(' and c != ')') or (op == '{' and c != '}') or (op == '[' and c != ']'):
                print(f"Mismatched {op} and {c} at index {i}")

if stack:
    print(f"Unclosed items: {stack[-10:]}")
else:
    print("All braces/parentheses balanced!")
