with open("src/components/leases/RenewalView.tsx", "r", encoding="utf-8") as f:
    text = f.read()

import re
tags = []
for m in re.finditer(r'</?(div)\b[^>]*>', text):
    tag = m.group(0)
    is_closing = tag.startswith('</')
    if is_closing:
        tags.append(('close', m.group(1), m.start()))
    elif not tag.endswith('/>'):
        tags.append(('open', m.group(1), m.start()))

stack = []
for t, name, pos in tags:
    line_num = text.count('\n', 0, pos) + 1
    if line_num >= 1122 and line_num <= 1800:
        if t == 'open':
            if len(stack) == 1:
                print(f"Form direct child at line {line_num}: {text[pos:pos+100].splitlines()[0]}")
            elif len(stack) == 2:
                print(f"  Level 2 child at line {line_num}: {text[pos:pos+100].splitlines()[0]}")
            elif len(stack) == 3:
                print(f"    Level 3 child at line {line_num}: {text[pos:pos+100].splitlines()[0]}")
            stack.append(line_num)
        else:
            if stack:
                stack.pop()
