with open("src/components/master/LeaseEditorModal.tsx", "r", encoding="utf-8") as f:
    text = f.read()

target = "{includeAdminFees && ("

replacement = """                <div className="flex items-center justify-between p-3 bg-amber-50 border border-amber-200 rounded-xl mb-4 shadow-2xs">
                  <label htmlFor="include-admin-fees-checkbox" className="text-sm font-black text-amber-900 cursor-pointer select-none w-full flex items-center justify-between">
                    <span>{language === "ar" ? "إدراج الرسوم الإدارية / عمولة المكتب لهذا العقد (اختياري)" : "Include Administrative Fees / Office Commission (Optional)"}</span>
                    <input
                      type="checkbox"
                      id="include-admin-fees-checkbox"
                      checked={includeAdminFees}
                      onChange={(e) => setIncludeAdminFees(e.target.checked)}
                      className="w-5 h-5 rounded-md text-blue-600 border-amber-300 focus:ring-blue-500 cursor-pointer"
                    />
                  </label>
                </div>

                {includeAdminFees && ("""

if target in text:
    new_text = text.replace(target, replacement)
    with open("src/components/master/LeaseEditorModal.tsx", "w", encoding="utf-8") as f:
        f.write(new_text)
    print("Added includeAdminFees toggle!")
else:
    print("Could not find target.")
