with open("src/components/master/LeaseEditorModal.tsx", "r", encoding="utf-8") as f:
    text = f.read()

import re

tags = []
for m in re.finditer(r'</?(div)\b[^>]*>', text):
    tag = m.group(0)
    is_closing = tag.startswith('</')
    if is_closing:
        tags.append(('close', m.group(1), m.start()))
    elif not tag.endswith('/>'):
        tags.append(('open', m.group(1), m.start()))

stack = []
for t, name, pos in tags:
    line_num = text.count('\n', 0, pos) + 1
    if line_num > 2353: # only inside tab 4
        if t == 'open':
            stack.append(line_num)
        else:
            if not stack:
                pass
            else:
                last_line = stack.pop()

print("Unclosed divs:", stack)
