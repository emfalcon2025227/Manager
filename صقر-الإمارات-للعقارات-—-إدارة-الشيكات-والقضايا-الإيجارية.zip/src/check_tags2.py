with open("src/components/master/LeaseEditorModal.tsx", "r", encoding="utf-8") as f:
    text = f.read()

import re

# We will just do a simple HTML tag balancer.
# We will extract all tags like <div, </div, <form, </form, <Modal, </Modal
tags = []
for m in re.finditer(r'</?(div|form|Modal|span|label|button|svg|path|circle|line|rect)\b[^>]*>', text):
    tag = m.group(0)
    is_closing = tag.startswith('</')
    if is_closing:
        tags.append(('close', m.group(1), m.start()))
    elif not tag.endswith('/>'):
        tags.append(('open', m.group(1), m.start()))

stack = []
for t, name, pos in tags:
    line_num = text.count('\n', 0, pos) + 1
    if t == 'open':
        stack.append((name, line_num))
    else:
        if not stack:
            print(f"Unmatched closing tag {name} at line {line_num}")
            break
        last_name, last_line = stack.pop()
        if last_name != name:
            print(f"Mismatched! Closing </{name}> at line {line_num} does not match opening <{last_name}> from line {last_line}")
            break
else:
    if stack:
        print(f"Unclosed tags remaining: {stack}")
    else:
        print("All tags balanced!")
