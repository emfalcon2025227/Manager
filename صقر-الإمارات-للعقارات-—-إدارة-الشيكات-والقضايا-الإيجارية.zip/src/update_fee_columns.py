import re

with open("src/components/master/LeaseEditorModal.tsx", "r", encoding="utf-8") as f:
    text = f.read()

# Owner replacement
owner_target = """                    {/* OWNER COMMISSION COLUMN */}
                    <div className="flex flex-col justify-between p-3 bg-white border border-slate-200 rounded-xl space-y-2.5">
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                          <label className="flex items-center justify-between w-full text-xs font-bold text-slate-900 cursor-pointer select-none">
                            <span>{language === "ar" ? "تحصيل الرسوم من المالك" : "Collect Fee from Owner"}</span>
                            <input
                              type="checkbox"
                              id="owner-fee-enabled"
                              checked={ownerFeeEnabled}
                              onChange={(e) => setOwnerFeeEnabled(e.target.checked)}
                              className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                            />
                          </label>
                        </div>

                        {ownerFeeEnabled && (() => {
                          const total = ownerFeeBasis === "PERCENTAGE_OF_RENT"
                            ? Math.round((Number(annualRent || 0) * Number(ownerFeeRate || 0)) / 100)
                            : Number(ownerFeeFixed || 0);
                            
                          const currentPolicy = {
                            owner: {
                              isExempt: ownerAdminFeeExempt,
                              exemptionReason: ownerAdminFeeExemptionReason,
                              exemptionNote: ownerAdminFeeExemptionNote,
                              approvalStatus: ownerAdminFeeApproved ? ("APPROVED" as const) : ("PENDING" as const)
                            }
                          };

                          const summary = calculateCommissionAmount(
                            ownerFeeBasis === "PERCENTAGE_OF_RENT" ? Number(annualRent || 0) : total * 100 / (Number(ownerFeeRate) || 5),
                            "OWNER",
                            ownerFeeBasis === "PERCENTAGE_OF_RENT" ? Number(ownerFeeRate) : (total / (Number(annualRent) || 1) * 100),
                            DEFAULT_COMMISSION_SETTINGS,
                            "ADMIN_FEE",
                            startDate || new Date().toISOString(),
                            vatRates,
                            owners,
                            tenants,
                            selectedProperty?.ownerId,
                            currentPolicy
                          );

                          return (
                            <div className="space-y-3 pt-1 text-xs">
                              <div className="space-y-3">
                                <div>
                                  <label className="block text-[11px] font-bold text-slate-500 mb-1">{language === "ar" ? "طريقة الاحتساب" : "Calculation Method"}</label>
                                  <select
                                    value={ownerFeeBasis}
                                    onChange={(e) => setOwnerFeeBasis(e.target.value as any)}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none"
                                  >
                                    <option value="PERCENTAGE_OF_RENT">{language === "ar" ? "نسبة مئوية من الإيجار (%)" : "Percentage of Rent (%)"}</option>
                                    <option value="FIXED_AMOUNT">{language === "ar" ? "مبلغ ثابت (درهم)" : "Fixed Amount (AED)"}</option>
                                  </select>
                                </div>

                                <div>
                                  <label className="block text-[11px] font-bold text-slate-500 mb-1">{language === "ar" ? "النسبة المئوية (%)" : "Percentage (%)"}</label>
                                  <input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={ownerFeeBasis === "PERCENTAGE_OF_RENT" ? ownerFeeRate : ownerFeeFixed}
                                    onChange={(e) => ownerFeeBasis === "PERCENTAGE_OF_RENT" ? setOwnerFeeRate(e.target.value) : setOwnerFeeFixed(e.target.value)}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none"
                                  />
                                </div>

                                <div>
                                  <label className="block text-[11px] font-bold text-slate-500 mb-1">{language === "ar" ? "تاريخ الاستحقاق" : "Due Date"}</label>
                                  <input
                                    type="date"
                                    value={ownerFeeDueDate || startDate || ""}
                                    onChange={(e) => setOwnerFeeDueDate(e.target.value)}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none text-slate-700"
                                  />
                                </div>
                              </div>

                              {ownerAdminFeeExempt && (
                                <div className="p-2 bg-amber-50 border border-amber-200 rounded-xl space-y-2 animate-in fade-in zoom-in-95 duration-200">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] font-black text-amber-800 uppercase tracking-tight">{language === "ar" ? "تفاصيل الإعفاء" : "Exemption Details"}</span>
                                    <div className="flex items-center gap-1.5">
                                      <input
                                        type="checkbox"
                                        id="owner-exemption-approved-tab4"
                                        disabled={!canApproveExemption}
                                        checked={ownerAdminFeeApproved}
                                        onChange={(e) => setOwnerAdminFeeApproved(e.target.checked)}
                                        className="w-3 h-3 rounded text-amber-600 border-amber-300"
                                      />
                                      <label htmlFor="owner-exemption-approved-tab4" className="text-[9px] font-bold text-amber-900 cursor-pointer">{language === "ar" ? "اعتماد" : "Approve"}</label>
                                    </div>
                                  </div>
                                  <select
                                    value={ownerAdminFeeExemptionReason}
                                    onChange={(e) => setOwnerAdminFeeExemptReason(e.target.value as any)}
                                    className="w-full px-2 py-1 text-[10px] bg-white border border-amber-200 rounded-lg font-bold outline-none"
                                  >
                                    <option value="MANAGEMENT_DECISION">{language === "ar" ? "قرار إداري" : "Management Decision"}</option>
                                    <option value="SPECIAL_CONTRACT_AGREEMENT">{language === "ar" ? "اتفاقية خاصة" : "Special Agreement"}</option>
                                    <option value="PROMOTIONAL_EXEMPTION">{language === "ar" ? "إعفاء ترويجي" : "Promotional"}</option>
                                    <option value="RENEWAL_INCENTIVE">{language === "ar" ? "حافز تجديد" : "Renewal Incentive"}</option>
                                    <option value="OTHER">{language === "ar" ? "أسباب أخرى" : "Other Reasons"}</option>
                                  </select>
                                  <textarea
                                    value={ownerAdminFeeExemptionNote}
                                    onChange={(e) => setOwnerAdminFeeExemptNote(e.target.value)}
                                    rows={2}
                                    className="w-full px-2 py-1.5 text-[10px] bg-white border border-amber-200 rounded-lg font-bold outline-none resize-none"
                                    placeholder={language === "ar" ? "تفاصيل الإعفاء..." : "Exemption details..."}
                                  />
                                </div>
                              )}

                              <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 text-xs space-y-2 mt-4">
                                <div className="flex justify-between items-center">
                                  <span className="font-bold text-slate-700">{language === "ar" ? "إجمالي الرسوم المحتسبة:" : "Total Fees:"}</span>
                                  <span className="font-bold text-emerald-800">AED {summary.amount.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="font-bold text-amber-700">{language === "ar" ? `الضريبة المستقطعة (${summary.vatRate}%):` : `VAT (${summary.vatRate}%):`}</span>
                                  <span className="font-bold text-amber-800">AED {summary.vatAmount.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between items-center pt-2 border-t border-emerald-200/50">
                                  <span className="font-bold text-emerald-800">{language === "ar" ? "المبلغ الخاضع للضريبة:" : "Amount Subject to VAT:"}</span>
                                  <span className="font-black text-emerald-900">AED {summary.netRevenue.toLocaleString()}</span>
                                </div>
                              </div>

                              <div className="pt-2">
                                <label className="flex items-center justify-between w-full cursor-pointer select-none">
                                  <span className="text-[11px] font-bold text-slate-700">{language === "ar" ? "تحصيل الرسوم فوراً عند إصدار العقد" : "Collect Fee Immediately"}</span>
                                  <input
                                    type="checkbox"
                                    checked={ownerFeeImmediateCollection}
                                    onChange={(e) => setOwnerFeeImmediateCollection(e.target.checked)}
                                    className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                                  />
                                </label>
                              </div>
                            </div>
                          );
                        })()}
                      </div>

                      <div className="pt-3 mt-4 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                          <ShieldCheck className="w-4 h-4 text-slate-400" />
                          <span>{language === "ar" ? "إعفاء من الرسوم" : "Exempt from Fees"}</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={ownerAdminFeeExempt}
                            onChange={(e) => setOwnerAdminFeeExempt(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                      </div>
                    </div>"""

tenant_target = """                    {/* TENANT COMMISSION COLUMN */}
                    <div className="flex flex-col justify-between p-3 bg-white border border-slate-200 rounded-xl space-y-2.5">
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                          <label className="flex items-center justify-between w-full text-xs font-bold text-slate-900 cursor-pointer select-none">
                            <span>{language === "ar" ? "تحصيل الرسوم من المستأجر" : "Collect Fee from Tenant"}</span>
                            <input
                              type="checkbox"
                              id="tenant-fee-enabled"
                              checked={tenantFeeEnabled}
                              onChange={(e) => setTenantFeeEnabled(e.target.checked)}
                              className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                            />
                          </label>
                        </div>

                        {tenantFeeEnabled && (() => {
                          const total = tenantFeeBasis === "PERCENTAGE_OF_RENT"
                            ? Math.round((Number(annualRent || 0) * Number(tenantFeeRate || 0)) / 100)
                            : Number(tenantFeeFixed || 0);
                            
                          const currentPolicy = {
                            tenant: {
                              isExempt: tenantAdminFeeExempt,
                              exemptionReason: tenantAdminFeeExemptionReason,
                              exemptionNote: tenantAdminFeeExemptionNote,
                              approvalStatus: tenantAdminFeeApproved ? ("APPROVED" as const) : ("PENDING" as const)
                            }
                          };

                          const summary = calculateCommissionAmount(
                            tenantFeeBasis === "PERCENTAGE_OF_RENT" ? Number(annualRent || 0) : total * 100 / (Number(tenantFeeRate) || 5),
                            "TENANT",
                            tenantFeeBasis === "PERCENTAGE_OF_RENT" ? Number(tenantFeeRate) : (total / (Number(annualRent) || 1) * 100),
                            DEFAULT_COMMISSION_SETTINGS,
                            "ADMIN_FEE",
                            startDate || new Date().toISOString(),
                            vatRates,
                            owners,
                            tenants,
                            selectedProperty?.ownerId,
                            currentPolicy
                          );

                          return (
                            <div className="space-y-3 pt-1 text-xs">
                              <div className="space-y-3">
                                <div>
                                  <label className="block text-[11px] font-bold text-slate-500 mb-1">{language === "ar" ? "طريقة الاحتساب" : "Calculation Method"}</label>
                                  <select
                                    value={tenantFeeBasis}
                                    onChange={(e) => setTenantFeeBasis(e.target.value as any)}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none"
                                  >
                                    <option value="PERCENTAGE_OF_RENT">{language === "ar" ? "نسبة مئوية من الإيجار (%)" : "Percentage of Rent (%)"}</option>
                                    <option value="FIXED_AMOUNT">{language === "ar" ? "مبلغ ثابت (درهم)" : "Fixed Amount (AED)"}</option>
                                  </select>
                                </div>

                                <div>
                                  <label className="block text-[11px] font-bold text-slate-500 mb-1">{language === "ar" ? "النسبة المئوية (%)" : "Percentage (%)"}</label>
                                  <input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={tenantFeeBasis === "PERCENTAGE_OF_RENT" ? tenantFeeRate : tenantFeeFixed}
                                    onChange={(e) => tenantFeeBasis === "PERCENTAGE_OF_RENT" ? setTenantFeeRate(e.target.value) : setTenantFeeFixed(e.target.value)}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none"
                                  />
                                </div>

                                <div>
                                  <label className="block text-[11px] font-bold text-slate-500 mb-1">{language === "ar" ? "تاريخ الاستحقاق" : "Due Date"}</label>
                                  <input
                                    type="date"
                                    value={tenantFeeDueDate || startDate || ""}
                                    onChange={(e) => setTenantFeeDueDate(e.target.value)}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none text-slate-700"
                                  />
                                </div>
                              </div>

                              {tenantAdminFeeExempt && (
                                <div className="p-2 bg-amber-50 border border-amber-200 rounded-xl space-y-2 animate-in fade-in zoom-in-95 duration-200">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] font-black text-amber-800 uppercase tracking-tight">{language === "ar" ? "تفاصيل الإعفاء" : "Exemption Details"}</span>
                                    <div className="flex items-center gap-1.5">
                                      <input
                                        type="checkbox"
                                        id="tenant-exemption-approved-tab4"
                                        disabled={!canApproveExemption}
                                        checked={tenantAdminFeeApproved}
                                        onChange={(e) => setTenantAdminFeeApproved(e.target.checked)}
                                        className="w-3 h-3 rounded text-amber-600 border-amber-300"
                                      />
                                      <label htmlFor="tenant-exemption-approved-tab4" className="text-[9px] font-bold text-amber-900 cursor-pointer">{language === "ar" ? "اعتماد" : "Approve"}</label>
                                    </div>
                                  </div>
                                  <select
                                    value={tenantAdminFeeExemptionReason}
                                    onChange={(e) => setTenantAdminFeeExemptReason(e.target.value as any)}
                                    className="w-full px-2 py-1 text-[10px] bg-white border border-amber-200 rounded-lg font-bold outline-none"
                                  >
                                    <option value="MANAGEMENT_DECISION">{language === "ar" ? "قرار إداري" : "Management Decision"}</option>
                                    <option value="SPECIAL_CONTRACT_AGREEMENT">{language === "ar" ? "اتفاقية خاصة" : "Special Agreement"}</option>
                                    <option value="PROMOTIONAL_EXEMPTION">{language === "ar" ? "إعفاء ترويجي" : "Promotional"}</option>
                                    <option value="RENEWAL_INCENTIVE">{language === "ar" ? "حافز تجديد" : "Renewal Incentive"}</option>
                                    <option value="OTHER">{language === "ar" ? "أسباب أخرى" : "Other Reasons"}</option>
                                  </select>
                                  <textarea
                                    value={tenantAdminFeeExemptionNote}
                                    onChange={(e) => setTenantAdminFeeExemptNote(e.target.value)}
                                    rows={2}
                                    className="w-full px-2 py-1.5 text-[10px] bg-white border border-amber-200 rounded-lg font-bold outline-none resize-none"
                                    placeholder={language === "ar" ? "تفاصيل الإعفاء..." : "Exemption details..."}
                                  />
                                </div>
                              )}

                              <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 text-xs space-y-2 mt-4">
                                <div className="flex justify-between items-center">
                                  <span className="font-bold text-slate-700">{language === "ar" ? "إجمالي الرسوم المحتسبة:" : "Total Fees:"}</span>
                                  <span className="font-bold text-emerald-800">AED {summary.amount.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="font-bold text-amber-700">{language === "ar" ? `الضريبة المستقطعة (${summary.vatRate}%):` : `VAT (${summary.vatRate}%):`}</span>
                                  <span className="font-bold text-amber-800">AED {summary.vatAmount.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between items-center pt-2 border-t border-emerald-200/50">
                                  <span className="font-bold text-emerald-800">{language === "ar" ? "المبلغ الخاضع للضريبة:" : "Amount Subject to VAT:"}</span>
                                  <span className="font-black text-emerald-900">AED {summary.netRevenue.toLocaleString()}</span>
                                </div>
                              </div>

                              <div className="pt-2">
                                <label className="flex items-center justify-between w-full cursor-pointer select-none">
                                  <span className="text-[11px] font-bold text-slate-700">{language === "ar" ? "تحصيل الرسوم فوراً عند إصدار العقد" : "Collect Fee Immediately"}</span>
                                  <input
                                    type="checkbox"
                                    checked={tenantFeeImmediateCollection}
                                    onChange={(e) => setTenantFeeImmediateCollection(e.target.checked)}
                                    className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500"
                                  />
                                </label>
                              </div>
                            </div>
                          );
                        })()}
                      </div>

                      <div className="pt-3 mt-4 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                          <ShieldCheck className="w-4 h-4 text-slate-400" />
                          <span>{language === "ar" ? "إعفاء من الرسوم" : "Exempt from Fees"}</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={tenantAdminFeeExempt}
                            onChange={(e) => setTenantAdminFeeExempt(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                      </div>
                    </div>"""

# Replace in text
owner_start = text.find("{/* OWNER COMMISSION COLUMN */}")
tenant_start = text.find("{/* TENANT COMMISSION COLUMN */}")
declaration_start = text.find("{/* Administrative Declaration Checkbox */}")

if owner_start != -1 and tenant_start != -1 and declaration_start != -1:
    before = text[:owner_start]
    # We replace from owner_start up to declaration_start but wait, there is a closing div for includeAdminFees!
    # Let's find the closing of includeAdminFees block.
    # It ends with </div> </div> )}
    include_admin_fees_end = text.find(")}", tenant_start)
    if include_admin_fees_end != -1:
        after = text[declaration_start:]
        new_text = before + owner_target + "\n\n" + tenant_target + "\n                  </div>\n                )}\n\n                " + after
        with open("src/components/master/LeaseEditorModal.tsx", "w", encoding="utf-8") as f:
            f.write(new_text)
        print("Updated LeaseEditorModal.tsx successfully!")
    else:
        print("Could not find end of includeAdminFees.")
else:
    print("Could not find markers.")
