import React, { createContext, useContext, useState, useEffect } from "react";
import { User, UserRole, Permission, UserPermissionOverride } from "../types";
import { 
  PERMISSION_REGISTRY, 
  getPermissionDefinition, 
  LEGACY_PERMISSION_MAP,
  PermissionDefinition 
} from "../data/permissionRegistry";

export const ROLE_PERMISSIONS: Record<UserRole, (Permission | string)[]> = {
  SYSTEM_OWNER: [
    "DASHBOARD.VIEW",
    "PROPERTIES.VIEW",
    "PROPERTIES.CREATE",
    "PROPERTIES.EDIT",
    "PROPERTIES.DELETE",
    "UNITS.VIEW",
    "UNITS.CREATE",
    "UNITS.EDIT",
    "OWNERS.VIEW",
    "OWNERS.EDIT",
    "OWNER_TRANSFERS.APPROVE",
    "TENANTS.VIEW",
    "TENANTS.CUSTOMER_EXCEPTION",
    "LEASES.VIEW",
    "LEASES.CREATE",
    "LEASES.RENEW",
    "LEASES.DISCOUNT_OVERRIDE",
    "CHEQUES.VIEW",
    "CHEQUES.RECORD_BOUNCE",
    "COLLECTIONS.VIEW",
    "COLLECTIONS.MODIFY_PAID",
    "EXPENSES.CREATE",
    "EXPENSES.APPROVE",
    "DAILY_DEPOSITS.RECONCILE",
    "REPORTS.FINANCIAL_VIEW",
    "VAT.OVERRIDE",
    "SECURITY.MANAGE_PERMISSIONS",
    "VIEW_DASHBOARD",
    "MANAGE_USERS",
    "EDIT_USER",
    "DELETE_USER",
    "MANAGE_MASTER_DATA",
    "MANAGE_CHEQUES",
    "OCR_SCAN",
    "RECORD_COLLECTIONS",
    "MANAGE_CASES",
    "MANAGE_HEARINGS",
    "VIEW_MAINTENANCE",
    "MANAGE_MAINTENANCE",
    "CREATE_MAINTENANCE",
    "EDIT_MAINTENANCE",
    "MANAGE_ARCHIVE",
    "DISPATCH_NOTIFICATIONS",
    "CONFIGURE_RISK",
    "VIEW_REPORTS",
    "EXPORT_DATA",
    "IMPORT_DATA",
    "VIEW_AUDIT_LOGS",
    "OVERRIDE_RISK",
    "DELETE_RECORDS",
    "EDIT_SAVED_FINANCIAL_RECORDS",
    "VIEW_OFFICE_PETTY_CASH",
    "CREATE_OFFICE_PETTY_CASH_MONTH",
    "ADD_OFFICE_EXPENSE",
    "EDIT_OFFICE_EXPENSE",
    "DELETE_OFFICE_EXPENSE",
    "UPLOAD_OFFICE_PETTY_CASH_RECEIPT",
    "CLOSE_OFFICE_PETTY_CASH_MONTH",
    "REOPEN_OFFICE_PETTY_CASH_MONTH",
    "MANAGE_OFFICE_EXPENSE_CATEGORIES",
    "VIEW_OFFICE_PETTY_CASH_REPORTS",
    "MODIFY_CLOSED_OFFICE_PETTY_CASH",
    "identity.read",
    "identity.view",
    "identity.create",
    "identity.update",
    "identity.document.upload",
    "identity.document.view",
    "identity.settings.manage",
    "identity.bridge.manage"
  ],
  SUPER_ADMIN: [
    "DASHBOARD.VIEW",
    "PROPERTIES.VIEW",
    "PROPERTIES.CREATE",
    "PROPERTIES.EDIT",
    "PROPERTIES.DELETE",
    "UNITS.VIEW",
    "UNITS.CREATE",
    "UNITS.EDIT",
    "OWNERS.VIEW",
    "OWNERS.EDIT",
    "OWNER_TRANSFERS.APPROVE",
    "TENANTS.VIEW",
    "TENANTS.CUSTOMER_EXCEPTION",
    "LEASES.VIEW",
    "LEASES.CREATE",
    "LEASES.RENEW",
    "LEASES.DISCOUNT_OVERRIDE",
    "CHEQUES.VIEW",
    "CHEQUES.RECORD_BOUNCE",
    "COLLECTIONS.VIEW",
    "COLLECTIONS.MODIFY_PAID",
    "EXPENSES.CREATE",
    "EXPENSES.APPROVE",
    "DAILY_DEPOSITS.RECONCILE",
    "REPORTS.FINANCIAL_VIEW",
    "VAT.OVERRIDE",
    "SECURITY.MANAGE_PERMISSIONS",
    "VIEW_DASHBOARD",
    "MANAGE_USERS",
    "EDIT_USER",
    "DELETE_USER",
    "MANAGE_MASTER_DATA",
    "MANAGE_CHEQUES",
    "OCR_SCAN",
    "RECORD_COLLECTIONS",
    "MANAGE_CASES",
    "MANAGE_HEARINGS",
    "VIEW_MAINTENANCE",
    "MANAGE_MAINTENANCE",
    "CREATE_MAINTENANCE",
    "EDIT_MAINTENANCE",
    "MANAGE_ARCHIVE",
    "DISPATCH_NOTIFICATIONS",
    "CONFIGURE_RISK",
    "VIEW_REPORTS",
    "EXPORT_DATA",
    "IMPORT_DATA",
    "VIEW_AUDIT_LOGS",
    "OVERRIDE_RISK",
    "DELETE_RECORDS",
    "EDIT_SAVED_FINANCIAL_RECORDS",
    "VIEW_OFFICE_PETTY_CASH",
    "CREATE_OFFICE_PETTY_CASH_MONTH",
    "ADD_OFFICE_EXPENSE",
    "EDIT_OFFICE_EXPENSE",
    "DELETE_OFFICE_EXPENSE",
    "UPLOAD_OFFICE_PETTY_CASH_RECEIPT",
    "CLOSE_OFFICE_PETTY_CASH_MONTH",
    "REOPEN_OFFICE_PETTY_CASH_MONTH",
    "MANAGE_OFFICE_EXPENSE_CATEGORIES",
    "VIEW_OFFICE_PETTY_CASH_REPORTS",
    "MODIFY_CLOSED_OFFICE_PETTY_CASH",
    "identity.read",
    "identity.view",
    "identity.create",
    "identity.update",
    "identity.document.upload",
    "identity.document.view",
    "identity.settings.manage",
    "identity.bridge.manage"
  ],
  MANAGER: [
    "DASHBOARD.VIEW",
    "PROPERTIES.VIEW",
    "PROPERTIES.CREATE",
    "PROPERTIES.EDIT",
    "UNITS.VIEW",
    "UNITS.CREATE",
    "UNITS.EDIT",
    "OWNERS.VIEW",
    "OWNERS.EDIT",
    "TENANTS.VIEW",
    "TENANTS.CUSTOMER_EXCEPTION",
    "LEASES.VIEW",
    "LEASES.CREATE",
    "LEASES.RENEW",
    "CHEQUES.VIEW",
    "CHEQUES.RECORD_BOUNCE",
    "COLLECTIONS.VIEW",
    "EXPENSES.CREATE",
    "REPORTS.FINANCIAL_VIEW",
    "VIEW_DASHBOARD",
    "MANAGE_MASTER_DATA",
    "MANAGE_CHEQUES",
    "OCR_SCAN",
    "RECORD_COLLECTIONS",
    "MANAGE_CASES",
    "MANAGE_HEARINGS",
    "VIEW_MAINTENANCE",
    "MANAGE_MAINTENANCE",
    "CREATE_MAINTENANCE",
    "EDIT_MAINTENANCE",
    "MANAGE_ARCHIVE",
    "DISPATCH_NOTIFICATIONS",
    "VIEW_REPORTS",
    "EXPORT_DATA",
    "CONFIGURE_RISK",
    "VIEW_AUDIT_LOGS",
    "OVERRIDE_RISK",
    "VIEW_OFFICE_PETTY_CASH",
    "CREATE_OFFICE_PETTY_CASH_MONTH",
    "ADD_OFFICE_EXPENSE",
    "EDIT_OFFICE_EXPENSE",
    "UPLOAD_OFFICE_PETTY_CASH_RECEIPT",
    "VIEW_OFFICE_PETTY_CASH_REPORTS"
  ],
  FINANCE: [
    "DASHBOARD.VIEW",
    "PROPERTIES.VIEW",
    "UNITS.VIEW",
    "OWNERS.VIEW",
    "TENANTS.VIEW",
    "LEASES.VIEW",
    "CHEQUES.VIEW",
    "COLLECTIONS.VIEW",
    "EXPENSES.CREATE",
    "REPORTS.FINANCIAL_VIEW",
    "VIEW_DASHBOARD",
    "MANAGE_MASTER_DATA",
    "MANAGE_CHEQUES",
    "OCR_SCAN",
    "RECORD_COLLECTIONS",
    "VIEW_MAINTENANCE",
    "MANAGE_ARCHIVE",
    "DISPATCH_NOTIFICATIONS",
    "VIEW_REPORTS",
    "EXPORT_DATA",
    "VIEW_AUDIT_LOGS",
    "VIEW_OFFICE_PETTY_CASH",
    "CREATE_OFFICE_PETTY_CASH_MONTH",
    "ADD_OFFICE_EXPENSE",
    "EDIT_OFFICE_EXPENSE",
    "UPLOAD_OFFICE_PETTY_CASH_RECEIPT",
    "VIEW_OFFICE_PETTY_CASH_REPORTS"
  ],
  LEGAL: [
    "DASHBOARD.VIEW",
    "PROPERTIES.VIEW",
    "UNITS.VIEW",
    "TENANTS.VIEW",
    "LEASES.VIEW",
    "CHEQUES.VIEW",
    "CHEQUES.RECORD_BOUNCE",
    "VIEW_DASHBOARD",
    "MANAGE_MASTER_DATA",
    "MANAGE_CHEQUES",
    "MANAGE_CASES",
    "MANAGE_HEARINGS",
    "VIEW_MAINTENANCE",
    "MANAGE_ARCHIVE",
    "DISPATCH_NOTIFICATIONS",
    "VIEW_REPORTS",
    "EXPORT_DATA",
    "VIEW_AUDIT_LOGS"
  ],
  PROPERTY_MANAGER: [
    "DASHBOARD.VIEW",
    "PROPERTIES.VIEW",
    "UNITS.VIEW",
    "TENANTS.VIEW",
    "LEASES.VIEW",
    "VIEW_DASHBOARD",
    "MANAGE_MASTER_DATA",
    "MANAGE_CHEQUES",
    "VIEW_MAINTENANCE",
    "MANAGE_MAINTENANCE",
    "CREATE_MAINTENANCE",
    "EDIT_MAINTENANCE",
    "MANAGE_ARCHIVE",
    "VIEW_REPORTS"
  ],
  DATA_ENTRY: [
    "DASHBOARD.VIEW",
    "PROPERTIES.VIEW",
    "UNITS.VIEW",
    "TENANTS.VIEW",
    "VIEW_DASHBOARD",
    "MANAGE_MASTER_DATA",
    "MANAGE_CHEQUES",
    "OCR_SCAN",
    "VIEW_MAINTENANCE",
    "CREATE_MAINTENANCE",
    "MANAGE_ARCHIVE"
  ],
  TENANT: [
    "TENANT_VIEW_OWN_DATA",
    "CREATE_MAINTENANCE"
  ]
};

export const INITIAL_SYSTEM_OWNER: User = {
  id: "usr-01",
  username: "Mahmoud",
  email: "m_hamed@msn.com",
  nameEn: "Mahmoud Mohamed Mahmoud Hamed",
  nameAr: "محمود محمد محمود حامد",
  role: "SYSTEM_OWNER",
  phone: "+971501234567",
  isActive: true,
  createdAt: "2024-01-01T08:00:00Z",
  lastLogin: new Date().toISOString(),
  password: "mahmoud@123",
};

export const isSystemOwnerUser = (user?: { id?: string; email?: string; username?: string; role?: string } | null): boolean => {
  if (!user) return false;
  const email = (user.email || "").trim().toLowerCase();
  const username = (user.username || "").trim().toLowerCase();
  const id = user.id || "";
  const role = user.role || "";
  return role === "SYSTEM_OWNER" || email === "m_hamed@msn.com" || id === "usr-01" || username === "mahmoud";
};

export interface EffectivePermissionResult {
  permissionId: string;
  granted: boolean;
  source: "SYSTEM_OWNER" | "ADMIN_ONLY_RESTRICTION" | "USER_DENY" | "USER_GRANT" | "ROLE" | "DENIED_BY_DEFAULT";
  reason: string;
  reasonAr: string;
  override?: UserPermissionOverride;
}

export function evaluateEffectivePermission(
  user: User | null,
  permissionId: string,
  userOverrides: UserPermissionOverride[],
  rolePermissions: Record<UserRole, (Permission | string)[]>
): EffectivePermissionResult {
  if (!user || !user.isActive) {
    return {
      permissionId,
      granted: false,
      source: "DENIED_BY_DEFAULT",
      reason: "User is not authenticated or account is disabled",
      reasonAr: "المستخدم غير محقق أو الحساب معطل",
    };
  }

  // SYSTEM_OWNER is absolute Root Super Admin
  if (isSystemOwnerUser(user)) {
    return {
      permissionId,
      granted: true,
      source: "SYSTEM_OWNER",
      reason: "System Owner has absolute root permissions across all modules",
      reasonAr: "مالك النظام يمتلك كافة الصلاحيات الشاملة تلقائياً (ROOT)",
    };
  }

  const normalizedId = LEGACY_PERMISSION_MAP[permissionId] || permissionId;
  const def = getPermissionDefinition(normalizedId);
  const isAdminUser = user.role === "SUPER_ADMIN" || user.role === "MANAGER";

  // Check Admin-Only Non-Delegable constraint
  if (def && def.adminOnly && !isAdminUser) {
    return {
      permissionId,
      granted: false,
      source: "ADMIN_ONLY_RESTRICTION",
      reason: "Permission is classified as Admin-Only and non-delegable to staff via User Overrides",
      reasonAr: "هذه الصلاحية مقتصرة حصرياً على الإدارة العليا ولا يمكن تفويضها للموظفين عبر الاستثناءات",
    };
  }

  // Check User Overrides (GRANT or DENY)
  const activeOverride = userOverrides.find((o) => {
    if (o.userId !== user.id) return false;
    const oNormalized = LEGACY_PERMISSION_MAP[o.permissionId] || o.permissionId;
    if (oNormalized !== normalizedId) return false;
    if (o.status === "REVOKED") return false;
    if (o.expiresAt && new Date(o.expiresAt).getTime() <= Date.now()) return false;
    return true;
  });

  if (activeOverride) {
    if (activeOverride.effect === "DENY") {
      return {
        permissionId,
        granted: false,
        source: "USER_DENY",
        reason: `Explicitly DENIED by User Override (${activeOverride.reason || "Direct Denial"})`,
        reasonAr: `ممنوعة بقرار حظر استثنائي خاص للمستخدم (${activeOverride.reason || "حظر خاص"})`,
        override: activeOverride,
      };
    } else if (activeOverride.effect === "GRANT") {
      return {
        permissionId,
        granted: true,
        source: "USER_GRANT",
        reason: `Explicitly GRANTED by User Override (${activeOverride.reason || "Direct Grant"})`,
        reasonAr: `ممنوحة باستثناء خاص للمستخدم (${activeOverride.reason || "منح خاص"})`,
        override: activeOverride,
      };
    }
  }

  // Check Role Permissions
  const roleList = rolePermissions[user.role] || [];
  const inRole = roleList.some((p) => {
    const pNorm = LEGACY_PERMISSION_MAP[p as string] || p;
    return pNorm === normalizedId;
  });

  if (inRole) {
    return {
      permissionId,
      granted: true,
      source: "ROLE",
      reason: `Granted by default user role: ${user.role}`,
      reasonAr: `ممنوحة افتراضياً عبر الدور الأساسي: ${user.role}`,
    };
  }

  return {
    permissionId,
    granted: false,
    source: "DENIED_BY_DEFAULT",
    reason: "Not granted in default role or active overrides",
    reasonAr: "غير مسموحة افتراضياً في الدور الوظيفي أو الاستثناءات",
  };
}

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  canRemixAndShare: boolean;
  users: User[];
  userPermissionOverrides: UserPermissionOverride[];
  loginMode: "STAFF" | "TENANT" | null;
  login: (usernameOrEmail: string, password: string, mode: "STAFF" | "TENANT") => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  quickSwitchUser: (userId: string) => void;
  hasPermission: (permission: Permission | string, targetUserId?: string) => boolean;
  getEffectivePermission: (permissionId: string, userId?: string) => EffectivePermissionResult;
  addUserPermissionOverride: (overrideData: { userId: string; permissionId: string; effect: "GRANT" | "DENY"; reason?: string; expiresAt?: string | null }) => { success: boolean; error?: string };
  revokeUserPermissionOverride: (overrideId: string) => { success: boolean; error?: string };
  createUser: (userData: Omit<User, "id" | "createdAt">) => { success: boolean; user?: User; error?: string };
  updateUser: (userId: string, patch: Partial<User>) => { success: boolean; error?: string };
  updateUserStatus: (userId: string, isActive: boolean) => { success: boolean; error?: string };
  updateUserRole: (userId: string, newRole: UserRole) => { success: boolean; error?: string };
  resetUserPassword: (userId: string, newPassword?: string) => string;
  changeOwnPassword: (currentPassword: string, newPassword: string) => { success: boolean; error?: string };
  deleteUser: (userId: string) => { success: boolean; error?: string };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem("ef_users");
    let loadedUsers: User[] = [INITIAL_SYSTEM_OWNER];
    if (saved) {
      try {
        loadedUsers = JSON.parse(saved);
      } catch (e) {
        loadedUsers = [INITIAL_SYSTEM_OWNER];
      }
    }
    // Filter out obsolete test accounts
    loadedUsers = loadedUsers.filter(u => u.id !== "usr-02" && u.id !== "usr-tenant" && u.id !== "usr-mahmoud-tenant");
    
    // Ensure Mahmoud (usr-01 / m_hamed@msn.com) is ALWAYS present, active, and SYSTEM_OWNER
    const hasMahmoud = loadedUsers.some(u => isSystemOwnerUser(u));
    if (!hasMahmoud) {
      loadedUsers = [INITIAL_SYSTEM_OWNER, ...loadedUsers];
    } else {
      loadedUsers = loadedUsers.map(u => isSystemOwnerUser(u) ? { 
        ...u, 
        id: "usr-01",
        username: "Mahmoud",
        email: "m_hamed@msn.com", 
        nameEn: "Mahmoud Mohamed Mahmoud Hamed",
        nameAr: "محمود محمد محمود حامد",
        role: "SYSTEM_OWNER", 
        isActive: true,
        password: u.password || "mahmoud@123"
      } : u);
    }
    return loadedUsers;
  });

  const [userPermissionOverrides, setUserPermissionOverrides] = useState<UserPermissionOverride[]>(() => {
    const saved = localStorage.getItem("ef_user_overrides");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const savedId = localStorage.getItem("ef_current_user_id");
    if (savedId) {
      const match = users.find((u) => u.id === savedId && u.isActive);
      return match || null;
    }
    return null;
  });

  const [loginMode, setLoginMode] = useState<"STAFF" | "TENANT" | null>(() => {
    return localStorage.getItem("ef_login_mode") as "STAFF" | "TENANT" | null;
  });

  useEffect(() => {
    // Keep SYSTEM_OWNER immutably protected
    setUsers((prev) => {
      let updated = prev.filter(u => u.id !== "usr-02" && u.id !== "usr-tenant" && u.id !== "usr-mahmoud-tenant");
      const hasMahmoud = updated.some(u => isSystemOwnerUser(u));
      if (!hasMahmoud) {
        updated = [INITIAL_SYSTEM_OWNER, ...updated];
      } else {
        updated = updated.map(u => isSystemOwnerUser(u) ? { 
          ...u, 
          id: "usr-01",
          username: "Mahmoud",
          email: "m_hamed@msn.com", 
          nameEn: "Mahmoud Mohamed Mahmoud Hamed",
          nameAr: "محمود محمد محمود حامد",
          role: "SYSTEM_OWNER", 
          isActive: true,
          password: u.password || "mahmoud@123"
        } : u);
      }
      return updated;
    });
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("ef_users", JSON.stringify(users));
    } catch (e) {
      console.warn("[AuthContext] Unable to save users to localStorage:", e);
    }
  }, [users]);

  useEffect(() => {
    try {
      localStorage.setItem("ef_user_overrides", JSON.stringify(userPermissionOverrides));
    } catch (e) {
      console.warn("[AuthContext] Unable to save userPermissionOverrides to localStorage:", e);
    }
  }, [userPermissionOverrides]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem("ef_current_user_id", currentUser.id);
      } else {
        localStorage.removeItem("ef_current_user_id");
        localStorage.removeItem("ef_login_mode");
        setLoginMode(null);
      }
    } catch (e) {
      console.warn("[AuthContext] Unable to save current user id:", e);
    }
  }, [currentUser]);

  useEffect(() => {
    try {
      if (loginMode) {
        localStorage.setItem("ef_login_mode", loginMode);
      }
    } catch (e) {
      console.warn("[AuthContext] Unable to save login mode:", e);
    }
  }, [loginMode]);

  const login = async (usernameOrEmail: string, password: string, mode: "STAFF" | "TENANT"): Promise<{ success: boolean; error?: string }> => {
    const clean = usernameOrEmail.trim().toLowerCase();
    
    const user = users.find((u) => {
      const uEmail = (u.email || "").trim().toLowerCase();
      const uUsername = (u.username || "").trim().toLowerCase();
      const emailMatch = uEmail === clean;
      const usernameMatch = uUsername === clean;
      
      if (mode === "TENANT") {
        return (emailMatch || usernameMatch) && u.role === "TENANT";
      } else {
        return (emailMatch || usernameMatch) && u.role !== "TENANT";
      }
    });

    if (!user) {
      return { success: false, error: mode === "TENANT" ? "خطأ في البريد الإلكتروني أو كلمة المرور للمستأجر" : "اسم المستخدم أو كلمة المرور غير صحيحة" };
    }

    if (user.password && user.password !== password) {
       return { success: false, error: mode === "TENANT" ? "خطأ في البريد الإلكتروني أو كلمة المرور للمستأجر" : "اسم المستخدم أو كلمة المرور غير صحيحة" };
    }

    if (!user.isActive) {
      return { success: false, error: "الحساب معطل، يرجى التواصل مع مالك النظام SYSTEM_OWNER" };
    }

    const updatedUser = { ...user, lastLogin: new Date().toISOString() };
    setUsers((prev) => prev.map((u) => (u.id === user.id ? updatedUser : u)));
    setLoginMode(mode);
    setCurrentUser(updatedUser);
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const quickSwitchUser = (userId: string) => {
    const user = users.find((u) => u.id === userId);
    if (user && user.isActive) {
      setCurrentUser(user);
    }
  };

  const hasPermission = (permission: Permission | string, targetUserId?: string): boolean => {
    const targetId = targetUserId || currentUser?.id;
    const targetUser = users.find((u) => u.id === targetId) || currentUser;
    if (!targetUser || !targetUser.isActive) return false;
    const res = evaluateEffectivePermission(targetUser, permission as string, userPermissionOverrides, ROLE_PERMISSIONS);
    return res.granted;
  };

  const getEffectivePermission = (permissionId: string, userId?: string): EffectivePermissionResult => {
    const targetId = userId || currentUser?.id;
    const targetUser = users.find((u) => u.id === targetId) || currentUser;
    return evaluateEffectivePermission(targetUser, permissionId, userPermissionOverrides, ROLE_PERMISSIONS);
  };

  const addUserPermissionOverride = (overrideData: {
    userId: string;
    permissionId: string;
    effect: "GRANT" | "DENY";
    reason?: string;
    expiresAt?: string | null;
  }): { success: boolean; error?: string } => {
    if (!currentUser || !isSystemOwnerUser(currentUser)) {
      return { success: false, error: "فقط مالك النظام SYSTEM_OWNER مصرح له بإدارة الاستثناءات والصلاحيات" };
    }
    const targetUser = users.find((u) => u.id === overrideData.userId);
    if (!targetUser) return { success: false, error: "المستخدم المحدد غير موجود" };

    if (isSystemOwnerUser(targetUser)) {
      return { success: false, error: "حساب مالك النظام SYSTEM_OWNER يمتلك كافة الصلاحيات الشاملة ولا يتأثر بالاستثناءات" };
    }

    const def = getPermissionDefinition(overrideData.permissionId);
    if (def?.adminOnly && targetUser.role !== "SUPER_ADMIN" && targetUser.role !== "MANAGER" && overrideData.effect === "GRANT") {
      return { success: false, error: "الصلاحية محددة كـ Admin-Only ولا يمكن تفويضها للموظفين العاديين عبر الاستثناءات" };
    }

    const newOverride: UserPermissionOverride = {
      id: "ovr-" + Date.now() + "-" + Math.floor(Math.random() * 1000),
      userId: overrideData.userId,
      permissionId: overrideData.permissionId,
      effect: overrideData.effect,
      reason: overrideData.reason || "",
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
      expiresAt: overrideData.expiresAt || null,
      status: "ACTIVE",
    };

    setUserPermissionOverrides((prev) => [
      newOverride,
      ...prev.filter((o) => !(o.userId === overrideData.userId && o.permissionId === overrideData.permissionId && o.status === "ACTIVE"))
    ]);
    return { success: true };
  };

  const revokeUserPermissionOverride = (overrideId: string): { success: boolean; error?: string } => {
    if (!currentUser || !isSystemOwnerUser(currentUser)) {
      return { success: false, error: "فقط مالك النظام SYSTEM_OWNER مصرح له بإلغاء استثناءات الصلاحيات" };
    }
    setUserPermissionOverrides((prev) =>
      prev.map((o) => (o.id === overrideId ? { ...o, status: "REVOKED" } : o))
    );
    return { success: true };
  };

  const createUser = (userData: Omit<User, "id" | "createdAt">): { success: boolean; user?: User; error?: string } => {
    if (userData.role === "SYSTEM_OWNER") {
      return { success: false, error: "لا يمكن إنشاء حساب SYSTEM_OWNER آخر. يوجد مالك نظام واحد فقط مقتصر على m_hamed@msn.com" };
    }

    if (!currentUser || !isSystemOwnerUser(currentUser)) {
      return { success: false, error: "فقط مالك النظام SYSTEM_OWNER مصرح له بإنشاء حسابات مستخدمين جديدة" };
    }

    const isTenant = userData.role === "TENANT";
    if (userData.username && users.some((u) => (u.username || "").toLowerCase() === (userData.username || "").toLowerCase() && (isTenant ? u.role === "TENANT" : u.role !== "TENANT"))) {
      return { success: false, error: "اسم المستخدم مسجل مسبقاً في هذا القسم" };
    }
    if (userData.email && users.some((u) => (u.email || "").toLowerCase() === (userData.email || "").toLowerCase() && (isTenant ? u.role === "TENANT" : u.role !== "TENANT"))) {
      return { success: false, error: "البريد الإلكتروني مسجل مسبقاً في هذا القسم" };
    }

    const newUser: User = {
      ...userData,
      id: "usr-" + Date.now(),
      createdAt: new Date().toISOString(),
    };

    setUsers((prev) => [...prev, newUser]);
    return { success: true, user: newUser };
  };

  const updateUser = (userId: string, patch: Partial<User>): { success: boolean; error?: string } => {
    const target = users.find((u) => u.id === userId);
    if (!target) return { success: false, error: "المستخدم غير موجود" };

    if (isSystemOwnerUser(target)) {
      if (!currentUser || !isSystemOwnerUser(currentUser)) {
        return { success: false, error: "لا يمكن لأي مدير أو مستخدم آخر تعديل حساب مالك النظام SYSTEM_OWNER" };
      }
      if (patch.username && patch.username.toLowerCase() !== "mahmoud") {
        return { success: false, error: "لا يمكن تغيير اسم المستخدم لمالك النظام الثابت (Mahmoud)" };
      }
      if (patch.email && patch.email.toLowerCase() !== "m_hamed@msn.com") {
        return { success: false, error: "لا يمكن تغيير البريد الإلكتروني لمالك النظام الثابت (m_hamed@msn.com)" };
      }
      if (patch.role && patch.role !== "SYSTEM_OWNER") {
        return { success: false, error: "لا يمكن تخفيض دور أو رتبة مالك النظام SYSTEM_OWNER" };
      }
    } else {
      if (!currentUser || !isSystemOwnerUser(currentUser)) {
        return { success: false, error: "فقط مالك النظام SYSTEM_OWNER مصرح له بتعديل حسابات المستخدمين" };
      }
    }

    if (patch.role === "SYSTEM_OWNER" && !isSystemOwnerUser(target)) {
      return { success: false, error: "لا يمكن ترقية أي مستخدم إلى SYSTEM_OWNER" };
    }

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const updated = { ...u, ...patch };
          if (currentUser?.id === userId) {
            setCurrentUser(updated);
          }
          return updated;
        }
        return u;
      })
    );
    return { success: true };
  };

  const updateUserStatus = (userId: string, isActive: boolean): { success: boolean; error?: string } => {
    const target = users.find((u) => u.id === userId);
    if (!target) return { success: false, error: "المستخدم غير موجود" };

    if (isSystemOwnerUser(target)) {
      return { success: false, error: "حساب مالك النظام SYSTEM_OWNER محمي نهائياً ولا يمكن تعطيله" };
    }

    if (!currentUser || !isSystemOwnerUser(currentUser)) {
      return { success: false, error: "فقط مالك النظام SYSTEM_OWNER مصرح له بتغيير حالة حسابات المستخدمين" };
    }

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          if (currentUser?.id === userId && !isActive) {
            setTimeout(() => logout(), 100);
          }
          return { ...u, isActive };
        }
        return u;
      })
    );
    return { success: true };
  };

  const updateUserRole = (userId: string, newRole: UserRole): { success: boolean; error?: string } => {
    const target = users.find((u) => u.id === userId);
    if (!target) return { success: false, error: "المستخدم غير موجود" };

    if (isSystemOwnerUser(target) && newRole !== "SYSTEM_OWNER") {
      return { success: false, error: "لا يمكن تغيير أو تخفيض دور مالك النظام SYSTEM_OWNER" };
    }

    if (newRole === "SYSTEM_OWNER" && !isSystemOwnerUser(target)) {
      return { success: false, error: "لا يمكن تعيين دور SYSTEM_OWNER لأي مستخدم آخر" };
    }

    if (!currentUser || !isSystemOwnerUser(currentUser)) {
      return { success: false, error: "فقط مالك النظام SYSTEM_OWNER مصرح له بتعديل أدوار المستخدمين" };
    }

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const updated = { ...u, role: newRole };
          if (currentUser?.id === userId) {
            setCurrentUser(updated);
          }
          return updated;
        }
        return u;
      })
    );
    return { success: true };
  };

  const resetUserPassword = (userId: string, newPassword?: string): string => {
    const finalPass = newPassword || ("Falcon@" + Math.floor(1000 + Math.random() * 9000));
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const updated = { ...u, password: finalPass };
          if (currentUser?.id === userId) {
            setCurrentUser(updated);
          }
          return updated;
        }
        return u;
      })
    );
    return finalPass;
  };

  const changeOwnPassword = (currentPassword: string, newPassword: string): { success: boolean; error?: string } => {
    if (!currentUser) {
      return { success: false, error: "المستخدم غير مسجل الدخول" };
    }
    if (currentUser.password && currentUser.password !== currentPassword) {
      return { success: false, error: "كلمة المرور الحالية غير صحيحة" };
    }
    if (!newPassword || newPassword.trim().length < 4) {
      return { success: false, error: "كلمة المرور الجديدة يجب أن لا تقل عن 4 رموز" };
    }

    const updatedUser = { ...currentUser, password: newPassword };
    setCurrentUser(updatedUser);
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? updatedUser : u))
    );
    return { success: true };
  };

  const deleteUser = (userId: string): { success: boolean; error?: string } => {
    const userToDelete = users.find((u) => u.id === userId);
    if (isSystemOwnerUser(userToDelete)) {
      return { success: false, error: "حساب مالك النظام SYSTEM_OWNER محمي نهائياً ولا يمكن حذفه" };
    }

    if (!currentUser || !isSystemOwnerUser(currentUser)) {
      return { success: false, error: "فقط مالك النظام SYSTEM_OWNER مصرح له بحذف حسابات المستخدمين" };
    }

    setUsers((prev) => prev.filter((u) => u.id !== userId));
    if (currentUser?.id === userId) {
      setTimeout(() => logout(), 100);
    }
    return { success: true };
  };

  const canRemixAndShare = !!currentUser && currentUser.isActive && (isSystemOwnerUser(currentUser) || currentUser.role === "SUPER_ADMIN");

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        canRemixAndShare,
        users,
        userPermissionOverrides,
        loginMode,
        login,
        logout,
        quickSwitchUser,
        hasPermission,
        getEffectivePermission,
        addUserPermissionOverride,
        revokeUserPermissionOverride,
        createUser,
        updateUser,
        updateUserStatus,
        updateUserRole,
        resetUserPassword,
        changeOwnPassword,
        deleteUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
