with open("src/components/leases/RenewalView.tsx", "r", encoding="utf-8") as f:
    text = f.read()

import re
tags = []
for m in re.finditer(r'</?(div|form|main)\b[^>]*>', text):
    tag = m.group(0)
    is_closing = tag.startswith('</')
    if is_closing:
        tags.append(('close', m.group(1), m.start()))
    elif not tag.endswith('/>'):
        tags.append(('open', m.group(1), m.start()))

stack = []
for t, name, pos in tags:
    line_num = text.count('\n', 0, pos) + 1
    if line_num >= 872 and line_num <= 2000:
        if t == 'open':
            if len(stack) == 1:
                print(f"Direct child at line {line_num}: {text[pos:pos+100].splitlines()[0]}")
            stack.append(line_num)
        else:
            if stack:
                stack.pop()
