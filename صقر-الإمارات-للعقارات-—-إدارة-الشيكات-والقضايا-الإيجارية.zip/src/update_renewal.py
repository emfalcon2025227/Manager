import re

with open("src/components/leases/RenewalView.tsx", "r", encoding="utf-8") as f:
    text = f.read()

# Does it have "TENANT FEE CARD" ?
if "TENANT FEE CARD" in text:
    print("Found TENANT FEE CARD in RenewalView")

