with open("src/components/master/LeaseEditorModal.tsx", "r", encoding="utf-8") as f:
    text = f.read()

# Find where the owner commission column ends
owner_col_end = """                      </div>
                    </div>"""

# Check how many times owner_col_end appears or find after owner fee column
owner_toggle = """                       {/* Bottom Exemption Toggle */}
                       <div className="pt-2.5 mt-3 border-t border-slate-200 flex items-center justify-between">
                         <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                           <ShieldCheck className="w-4 h-4 text-amber-600" />
                           <span>{language === "ar" ? "إعفاء من الرسوم" : "Exempt from Fees"}</span>
                         </div>
                         <label className="relative inline-flex items-center cursor-pointer">
                           <input
                             type="checkbox"
                             checked={ownerAdminFeeExempt}
                             onChange={(e) => setOwnerAdminFeeExempt(e.target.checked)}
                             className="sr-only peer"
                           />
                           <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-600"></div>
                         </label>
                       </div>
                     </div>"""

tenant_col_code = """                    {/* TENANT COMMISSION COLUMN */}
                    <div className="flex flex-col justify-between p-3 bg-white border border-slate-200 rounded-xl space-y-2.5">
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between">
                          <label className="flex items-center gap-1.5 text-xs font-bold text-slate-900 cursor-pointer">
                            <input
                              type="checkbox"
                              id="tenant-fee-enabled"
                              checked={tenantFeeEnabled}
                              onChange={(e) => setTenantFeeEnabled(e.target.checked)}
                              className="w-3.5 h-3.5 rounded text-amber-700 border-slate-300 focus:ring-amber-500"
                            />
                            <span>{language === "ar" ? "تحصيل الرسوم من المستأجر" : "Collect Fee from Tenant"}</span>
                          </label>
                        </div>

                        {tenantFeeEnabled && (() => {
                          const total = tenantFeeBasis === "PERCENTAGE_OF_RENT"
                            ? Math.round((Number(annualRent || 0) * Number(tenantFeeRate || 0)) / 100)
                            : Number(tenantFeeFixed || 0);
                          
                          const currentPolicy = {
                            tenant: {
                              isExempt: tenantAdminFeeExempt,
                              exemptionReason: tenantAdminFeeExemptionReason,
                              exemptionNote: tenantAdminFeeExemptionNote,
                              approvalStatus: tenantAdminFeeApproved ? ("APPROVED" as const) : ("PENDING" as const)
                            }
                          };

                          const summary = calculateCommissionAmount(
                            tenantFeeBasis === "PERCENTAGE_OF_RENT" ? Number(annualRent || 0) : total * 100 / (Number(tenantFeeRate) || 5),
                            "TENANT",
                            tenantFeeBasis === "PERCENTAGE_OF_RENT" ? Number(tenantFeeRate) : (total / (Number(annualRent) || 1) * 100),
                            DEFAULT_COMMISSION_SETTINGS,
                            "ADMIN_FEE",
                            startDate || new Date().toISOString(),
                            vatRates,
                            owners,
                            tenants,
                            tenantId,
                            currentPolicy
                          );

                          return (
                            <div className="space-y-2 text-xs">
                              <div className="flex gap-2">
                                <div className="flex-1">
                                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">{language === "ar" ? "طريقة الاحتساب" : "Basis"}</label>
                                  <select
                                    value={tenantFeeBasis}
                                    onChange={(e) => setTenantFeeBasis(e.target.value as any)}
                                    className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[11px] font-bold outline-none"
                                  >
                                    <option value="PERCENTAGE_OF_RENT">{language === "ar" ? "نسبة (%)" : "Rate (%)"}</option>
                                    <option value="FIXED_AMOUNT">{language === "ar" ? "ثابت (AED)" : "Fixed (AED)"}</option>
                                  </select>
                                </div>
                                <div className="flex-1">
                                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">
                                    {tenantFeeBasis === "PERCENTAGE_OF_RENT" ? (language === "ar" ? "النسبة (%)" : "Rate (%)") : (language === "ar" ? "المبلغ" : "Amount")}
                                  </label>
                                  <input
                                    type="number"
                                    value={tenantFeeBasis === "PERCENTAGE_OF_RENT" ? tenantFeeRate : tenantFeeFixed}
                                    onChange={(e) => {
                                      if (tenantFeeBasis === "PERCENTAGE_OF_RENT") setTenantFeeRate(e.target.value);
                                      else setTenantFeeFixed(e.target.value);
                                    }}
                                    className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[11px] font-mono font-bold outline-none"
                                  />
                                </div>
                              </div>

                              <div className="flex items-center justify-between">
                                <div>
                                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">{language === "ar" ? "تاريخ الاستحقاق" : "Due Date"}</label>
                                  <input
                                    type="date"
                                    value={tenantFeeDueDate}
                                    onChange={(e) => setTenantFeeDueDate(e.target.value)}
                                    className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[11px] font-mono outline-none"
                                  />
                                </div>
                                
                                <div className="text-right">
                                  <label className="block text-[10px] font-semibold text-slate-400 mb-0.5">{language === "ar" ? "مصدر السياسة" : "Policy Source"}</label>
                                  <span className={`text-[9px] px-1.5 py-0.5 rounded font-black uppercase ${
                                    summary.isExempt ? 'bg-amber-100 text-amber-700' : 
                                    summary.rate !== Number(tenantFeeRate) ? 'bg-slate-100 text-slate-600' : 'bg-emerald-100 text-emerald-700'
                                  }`}>
                                    {summary.isExempt ? (language === "ar" ? "إعفاء معتمد" : "Approved Exemption") : 
                                     (tenantFeeBasis === "FIXED_AMOUNT" ? (language === "ar" ? "إدخال يدوي" : "Manual Entry") : 
                                     (language === "ar" ? "سياسة مطبقة" : "Applied Policy"))}
                                  </span>
                                </div>
                              </div>

                              {tenantAdminFeeExempt && (
                                <div className="p-2 bg-amber-50 border border-amber-200 rounded-lg space-y-2 animate-in fade-in zoom-in-95 duration-200">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] font-black text-amber-800 uppercase tracking-tight">{language === "ar" ? "تفاصيل الإعفاء" : "Exemption Details"}</span>
                                    <div className="flex items-center gap-1.5">
                                      <input
                                        type="checkbox"
                                        id="tenant-exemption-approved-tab4"
                                        disabled={!canApproveExemption}
                                        checked={tenantAdminFeeApproved}
                                        onChange={(e) => setTenantAdminFeeApproved(e.target.checked)}
                                        className="w-3 h-3 rounded text-amber-600 border-amber-300"
                                      />
                                      <label htmlFor="tenant-exemption-approved-tab4" className="text-[9px] font-bold text-amber-900 cursor-pointer">{language === "ar" ? "اعتماد" : "Approve"}</label>
                                    </div>
                                  </div>
                                  <select
                                    value={tenantAdminFeeExemptionReason}
                                    onChange={(e) => setTenantAdminFeeExemptReason(e.target.value as any)}
                                    className="w-full px-2 py-1 text-[10px] bg-white border border-amber-200 rounded font-bold outline-none"
                                  >
                                    <option value="MANAGEMENT_DECISION">{language === "ar" ? "قرار إداري" : "Management Decision"}</option>
                                    <option value="SPECIAL_CONTRACT_AGREEMENT">{language === "ar" ? "اتفاقية خاصة" : "Special Agreement"}</option>
                                    <option value="PROMOTIONAL_EXEMPTION">{language === "ar" ? "إعفاء ترويجي" : "Promotional"}</option>
                                    <option value="RENEWAL_INCENTIVE">{language === "ar" ? "حافز تجديد" : "Renewal Incentive"}</option>
                                    <option value="OTHER">{language === "ar" ? "أسباب أخرى" : "Other Reasons"}</option>
                                  </select>
                                  <textarea
                                    value={tenantAdminFeeExemptionNote}
                                    onChange={(e) => setTenantAdminFeeExemptNote(e.target.value)}
                                    rows={2}
                                    className="w-full px-2 py-1.5 text-[10px] bg-white border border-amber-200 rounded font-bold outline-none resize-none"
                                    placeholder={language === "ar" ? "تفاصيل الإعفاء..." : "Exemption details..."}
                                  />
                                </div>
                              )}

                              <div className="p-2 bg-emerald-50/80 rounded-lg border border-emerald-200 text-[11px] space-y-1">
                                <div className="flex justify-between">
                                  <span>{language === "ar" ? "إجمالي الرسوم:" : "Gross Fee:"}</span>
                                  <span className="font-mono font-bold text-slate-900">{summary.amount.toLocaleString()} AED</span>
                                </div>
                                <div className="flex justify-between text-[10px] text-amber-800">
                                  <span>{language === "ar" ? `الضريبة (${summary.vatRate}%):` : `VAT (${summary.vatRate}%):`}</span>
                                  <span className="font-mono font-bold">{summary.vatAmount.toLocaleString()} AED</span>
                                </div>
                                <div className="flex justify-between text-[10px] text-emerald-800 border-t border-emerald-200/60 pt-1 font-bold">
                                  <span>{language === "ar" ? "صافي الدخل:" : "Net Revenue:"}</span>
                                  <span className="font-mono">{summary.netRevenue.toLocaleString()} AED</span>
                                </div>
                              </div>

                              <div className="p-2 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                                <label className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-800 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={tenantFeeImmediateCollection}
                                    onChange={(e) => setTenantFeeImmediateCollection(e.target.checked)}
                                    className="w-3.5 h-3.5 rounded text-emerald-600 border-slate-300"
                                  />
                                  <span>{language === "ar" ? "تحصيل فوري عند الإصدار" : "Collect Immediately"}</span>
                                </label>

                                {tenantFeeImmediateCollection && (
                                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-200">
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-500 mb-0.5">{language === "ar" ? "الطريقة" : "Method"}</label>
                                      <SearchableSelect
                                        options={[
                                          { id: "BANK_TRANSFER", label: language === "ar" ? "تحويل" : "Transfer" },
                                          { id: "CASH", label: language === "ar" ? "نقدي" : "Cash" },
                                          { id: "CHEQUE", label: language === "ar" ? "شيك" : "Cheque" },
                                        ]}
                                        value={tenantFeePaymentMethod}
                                        onChange={(val) => setTenantFeePaymentMethod(val as any)}
                                        placeholder="..."
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[9px] font-bold text-slate-500 mb-0.5">{language === "ar" ? "المرجع" : "Ref #"}</label>
                                      <input
                                        type="text"
                                        value={tenantFeeReference}
                                        onChange={(e) => setOwnerFeeReference(e.target.value)}
                                        className="w-full px-2 py-1 bg-white border border-slate-200 rounded text-[11px] outline-none"
                                      />
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })()}
                      </div>

                      {/* Bottom Exemption Toggle */}
                      <div className="pt-2.5 mt-3 border-t border-slate-200 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                          <ShieldCheck className="w-4 h-4 text-amber-600" />
                          <span>{language === "ar" ? "إعفاء من الرسوم" : "Exempt from Fees"}</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={tenantAdminFeeExempt}
                            onChange={(e) => setTenantAdminFeeExempt(e.target.checked)}
                            className="sr-only peer"
                          />
                          <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-600"></div>
                        </label>
                      </div>
                    </div>"""

idx = text.find("{/* Bottom Exemption Toggle */}")
if idx != -1:
    # Find the end of that block (the </div> corresponding to the owner column container)
    # Actually, we can find {/* Administrative Declaration Checkbox */}
    decl_idx = text.find("{/* Administrative Declaration Checkbox */}")
    if decl_idx != -1:
        replacement = owner_toggle + "\n\n                    " + tenant_col_code + "\n                  </div>\n                )}\n\n                "
        text = text[:idx] + replacement + text[decl_idx:]
        with open("src/components/master/LeaseEditorModal.tsx", "w", encoding="utf-8") as f:
            f.write(text)
        print("Successfully inserted tenant column!")
else:
    print("Could not find owner bottom toggle")
