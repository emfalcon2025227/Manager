import re

with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()

# Add addDailyDeposit, updateDailyDeposit, and dailyDeposits to the DataContext return value!
# Searching for `dailyDeposits,` shows it wasn't added to the return.
if "addDailyDeposit," not in dc[11000:]:
    dc = dc.replace("      value={{", "      value={{\n        dailyDeposits,\n        addDailyDeposit,\n        updateDailyDeposit,")

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    t51 = f.read()

# Make sure we didn't screw up the phase51 fix
t51 = re.sub(r'\{\s+id: "DEP-1" as any, \{ id: "ignore"\s+depositDate', '{ id: "DEP-1", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any, {\n      id: "ignore", depositDate', t51)
t51 = re.sub(r'\{\s+id: "DEP-DUP" as any, \{ id: "ignore"\s+depositDate', '{ id: "DEP-DUP", depositReference: "REF-123", amount: 50000, status: "RECONCILED" } as any, {\n        id: "ignore", depositDate', t51)

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t51)

