import re
with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

text = text.replace(
    "const recordLeasePayment = (params: {",
    "const recordLeasePayment = async (params: {"
)
text = text.replace(
    "}): { success: boolean; receipt?: CollectionRecord; error?: string } => {\n    return processUnifiedPayment(params);\n  };",
    "}): Promise<{ success: boolean; receipt?: CollectionRecord; error?: string }> => {\n    return await processUnifiedPayment(params);\n  };"
)

text = text.replace(
    "const updateChequeWithSafetyConfirmation = (",
    "const updateChequeWithSafetyConfirmation = async ("
)
text = text.replace(
    "  ): { success: boolean; receipt?: CollectionRecord; error?: string } => {",
    "  ): Promise<{ success: boolean; receipt?: CollectionRecord; error?: string }> => {"
)
text = text.replace(
    "      return recordLeasePayment({\n",
    "      return await recordLeasePayment({\n"
)
text = text.replace(
    "      return processUnifiedPayment({\n",
    "      return await processUnifiedPayment({\n"
)

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
