const fs = require('fs');
const path = 'src/context/DataContext.tsx';
let content = fs.readFileSync(path, 'utf8');

const target = `
  const extractDocumentOCR = async (documentType: string, imageBase64: string, mimeType = "image/jpeg"): Promise<any> => {
    try {
      const res = await OCRService.extractDocument(imageBase64, documentType, "accurate", mimeType);
`.trim();

const replacement = `
  const extractDocumentOCR = async (documentType: string, imageBase64: string, mimeType = "image/jpeg"): Promise<any> => {
    try {
      if (documentType === "EMIRATES_ID") {
        const { OCRV2Engine } = await import("../services/ocr/v2/OCRV2Engine");
        const dataUrl = \`data:\${mimeType};base64,\${imageBase64}\`;
        const v2Res = await OCRV2Engine.extract(dataUrl, "EMIRATES_ID", "accurate");
        if (v2Res.success && v2Res.data && v2Res.fields) {
          return {
            success: true,
            data: v2Res.fields,
            fields: v2Res.fields,
            metadata: v2Res.diagnostics,
          };
        } else {
          return {
            success: false,
            error: v2Res.diagnostics?.errorMsg || "OCR V2 failed",
            errorAr: v2Res.diagnostics?.errorMsg || "فشلت عملية القراءة V2",
          };
        }
      }

      const res = await OCRService.extractDocument(imageBase64, documentType, "accurate", mimeType);
`.trim();

if(content.includes(target)) {
    content = content.replace(target, replacement);
    fs.writeFileSync(path, content, 'utf8');
    console.log("Success");
} else {
    console.log("Target not found");
}
