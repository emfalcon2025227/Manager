const fs = require('fs');
let tenantsCode = fs.readFileSync('src/components/master/TenantsView.tsx', 'utf8');
let ownersCode = fs.readFileSync('src/components/master/OwnersView.tsx', 'utf8');

tenantsCode = tenantsCode.replace(/const newTenant = \s*const newTenant = addTenant/g, "const newTenant = addTenant");
ownersCode = ownersCode.replace(/const newOwner = \s*const newOwner = addOwner/g, "const newOwner = addOwner");

fs.writeFileSync('src/components/master/TenantsView.tsx', tenantsCode);
fs.writeFileSync('src/components/master/OwnersView.tsx', ownersCode);
console.log('fixed');
