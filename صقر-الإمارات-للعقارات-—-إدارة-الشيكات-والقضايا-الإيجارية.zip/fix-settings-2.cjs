const fs = require('fs');
let file = 'src/components/settings/SettingsView.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(
  /\{ bouncedCheques: 40, paymentDelays: 30, legalCases: 30 \}/g,
  '{ bouncedChequesCountWeight: 40, bouncedRatioWeight: 20, outstandingAmountWeight: 25, delayDaysWeight: 10, casesFiledWeight: 5 }'
);

fs.writeFileSync(file, content);
