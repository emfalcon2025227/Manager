import re

with open("src/components/financials/FinancialsView.tsx", "r", encoding="utf-8") as f:
    content = f.read()

if "DailyDepositsControlCenterView" not in content:
    content = content.replace('import { DailyDepositsView } from "./DailyDepositsView";', 'import { DailyDepositsView } from "./DailyDepositsView";\nimport { DailyDepositsControlCenterView } from "./DailyDepositsControlCenterView";')
    content = content.replace('{activeTab === "DAILY_DEPOSITS" && <DailyDepositsView />}', '{activeTab === "DAILY_DEPOSITS" && <DailyDepositsControlCenterView />}')

    with open("src/components/financials/FinancialsView.tsx", "w", encoding="utf-8") as f:
        f.write(content)
    print("Added DailyDepositsControlCenterView to FinancialsView.tsx")
