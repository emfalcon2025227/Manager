import re

with open("src/services/continuousFinancialControlEngine.ts", "r", encoding="utf-8") as f:
    content = f.read()

# Remove the internal DailyDepositItem
content = re.sub(r'export interface DailyDepositItem \{.*?\}\n', '', content, flags=re.DOTALL)
# Import DailyDepositRecord
if "DailyDepositRecord" not in content:
    content = content.replace("ContinuousControlForensicSnapshot,", "ContinuousControlForensicSnapshot,\n  DailyDepositRecord,")
# Replace DailyDepositItem with DailyDepositRecord
content = content.replace("DailyDepositItem", "DailyDepositRecord")

with open("src/services/continuousFinancialControlEngine.ts", "w", encoding="utf-8") as f:
    f.write(content)
print("Updated continuousFinancialControlEngine.ts")
