const fs = require('fs');
let file = 'src/context/DataContext.tsx';
let content = fs.readFileSync(file, 'utf8');

// Fix Commissions State Updates
content = content.replace(/updatedCommission : c/g, 'updatedCommission as CommissionObligation : c');
content = content.replace(/newReceipt, \.\.\.prev/g, 'newReceipt as CollectionRecord, ...prev');
content = content.replace(/newAllocation, \.\.\.prev/g, 'newAllocation as PaymentAllocation, ...prev');

// Fix addCommissionObligation type
content = content.replace(
  /"id" \| "businessKey" \| "collectedAmount" \| "outstandingBalance" \| "status" \| "createdAt"/g,
  '"id" | "businessKey" | "collectedAmount" | "outstandingBalance" | "status" | "createdAt" | "createdById" | "createdByName"'
);
content = content.replace(
  /> & { businessKeySequence\?: string }/g,
  '> & { createdById?: string; createdByName?: string; businessKeySequence?: string }'
);

// Fix c.settlement
content = content.replace(/c\.settlement\.schedule/g, 'c.settlement?.schedule');
content = content.replace(/c\.settlement\.installmentsCount/g, 'c.settlement?.installmentsCount');
content = content.replace(/c\.settlement\.signedDate/g, 'c.settlement?.signedDate');
content = content.replace(/c\.settlement\.totalAgreedAmount/g, 'c.settlement?.totalAgreedAmount');

fs.writeFileSync(file, content);
