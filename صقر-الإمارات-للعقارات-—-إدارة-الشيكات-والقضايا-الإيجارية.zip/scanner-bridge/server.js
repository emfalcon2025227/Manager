const express = require('express');
const cors = require('cors');
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const PORT = 18622;
const BRIDGE_VERSION = "2.1.0"; // Updated version

app.use(express.json({ limit: '100mb' }));

// Restrict CORS safely to ERP hostnames and localhost
const allowedOrigins = [
    /^https?:\/\/localhost(:\d+)?$/, 
    /^https?:\/\/127\.0\.0\.1(:\d+)?$/, 
    /^https:\/\/.*\.run\.app$/
];

app.use(cors({
    origin: function (origin, callback) {
        if (!origin) return callback(null, true);
        const isAllowed = allowedOrigins.some(regex => regex.test(origin));
        if (isAllowed) {
            callback(null, true);
        } else {
            callback(new Error('CORS policy violation'));
        }
    }
}));

function runWiaScript(args) {
    const psScript = path.join(__dirname, 'wia-scanner.ps1');
    const cmd = `powershell.exe -NoProfile -ExecutionPolicy Bypass -File "${psScript}" ${args}`;
    try {
        const output = execSync(cmd, { encoding: 'utf-8', stdio: ['ignore', 'pipe', 'pipe'] });
        return { success: true, output: output.trim() };
    } catch (error) {
        return { success: false, error: error.stderr ? error.stderr.toString() : error.message };
    }
}

app.get('/health', (req, res) => {
    const result = runWiaScript('-Action "list"');
    if (result.success && result.output) {
        try {
            const scanners = JSON.parse(result.output);
            const available = scanners.length > 0;
            res.json({
                ok: true,
                bridgeVersion: BRIDGE_VERSION,
                scannerAvailable: available,
                scannerName: available ? scanners[0].name : null,
                protocol: "WIA",
                devices: scanners
            });
        } catch (e) {
            res.json({ ok: true, bridgeVersion: BRIDGE_VERSION, scannerAvailable: false, devices: [] });
        }
    } else {
        res.json({ ok: true, bridgeVersion: BRIDGE_VERSION, scannerAvailable: false, devices: [] });
    }
});

app.get('/scanners', (req, res) => {
    const result = runWiaScript('-Action "list"');
    if (result.success && result.output) {
        try {
            const scanners = JSON.parse(result.output);
            res.json({ scanners });
        } catch (e) {
            res.json({ scanners: [] });
        }
    } else {
        res.json({ scanners: [] });
    }
});

app.get('/diagnostics', (req, res) => {
    const result = runWiaScript('-Action "list"');
    let scanners = [];
    if (result.success && result.output) {
        try { scanners = JSON.parse(result.output); } catch (e) {}
    }
    // Determine ADF vs Flatbed support is tricky without connecting to each, 
    // we indicate general WIA availability.
    res.json({
        bridge: { running: true, version: BRIDGE_VERSION },
        wia: { available: scanners.length > 0 },
        scanners: scanners.map(s => ({ 
            id: s.id,
            name: s.name, 
            protocol: "WIA",
            available: true
        }))
    });
});

app.post('/scan', (req, res) => {
    const { scannerId, dpi = 300, colorMode = "COLOR", source = "auto" } = req.body;
    
    // Check if any scanners are available
    const listRes = runWiaScript('-Action "list"');
    if (!listRes.success || !listRes.output || listRes.output === '[]') {
        return res.status(503).json({ error: "لا يوجد ماسح ضوئي متصل عبر WIA." });
    }

    // Secure temp file creation in the OS temp directory
    const tempFile = path.join(os.tmpdir(), `scan_${Date.now()}.jpg`);
    
    // Execute WIA script targeting the specific scanner ID
    const scriptArgs = `-Action "scan" -ScannerId "${scannerId || ''}" -Dpi ${dpi} -ColorMode "${colorMode}" -OutFile "${tempFile}" -Source "${source}"`;
    const result = runWiaScript(scriptArgs);
    
    if (result.success && fs.existsSync(tempFile)) {
        try {
            const base64 = fs.readFileSync(tempFile, { encoding: 'base64' });
            // Secure cleanup of the original scanned file immediately after reading
            fs.unlinkSync(tempFile);
            
            let warnings = [];
            try { 
                const outJson = JSON.parse(result.output);
                if (outJson.warnings) warnings = outJson.warnings;
            } catch (e) {}

            res.json({
                success: true,
                mimeType: "image/jpeg",
                imageBase64: `data:image/jpeg;base64,${base64}`,
                warnings: warnings.length > 0 ? warnings : undefined
            });
        } catch (e) {
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            res.status(500).json({ error: "Failed to read image from scanner: " + e.message });
        }
    } else {
        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
        let errorMsg = result.error || "تعذر تنفيذ عملية المسح.";
        try {
            const outObj = JSON.parse(result.output);
            if (outObj.error) errorMsg = outObj.error;
        } catch(e) {}
        res.status(500).json({ error: errorMsg, code: "WIA_SCAN_FAILED" });
    }
});

app.listen(PORT, '127.0.0.1', () => {
    console.log(`Emirates Falcon Scanner Bridge running on http://127.0.0.1:${PORT}`);
    console.log(`WIA Native Interface Active. Version: ${BRIDGE_VERSION}`);
});
