import re

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "r", encoding="utf-8") as f:
    t51 = f.read()

t51 = t51.replace("""  const dupDeposit = {
    id: "dep-2",
    depositReference: "DEP-2026-001",
    amount: 25000,
    status: "DEPOSITED",
  };""", """  const dupDeposit = {
    id: "dep-2",
    depositReference: "DEP-2026-001",
    amount: 25000,
    status: "RECONCILED",
  } as any;""")

t51 = t51.replace("""  const deposit1 = {
    id: "dep-1",
    depositReference: "DEP-2026-001",
    amount: 50000,
    status: "DEPOSITED",
  };""", """  const deposit1 = {
    id: "dep-1",
    depositReference: "DEP-2026-001",
    amount: 50000,
    status: "RECONCILED",
  } as any;""")
  
# It seems `dailyDeposits` array needs `as any[]`
t51 = t51.replace("dailyDeposits: [deposit1],", "dailyDeposits: [deposit1] as any[],")
t51 = t51.replace("dailyDeposits: [deposit1, dupDeposit],", "dailyDeposits: [deposit1, dupDeposit] as any[],")

with open("src/utils/phase51ContinuousFinancialControlTests.ts", "w", encoding="utf-8") as f:
    f.write(t51)

# Now DataContext
with open("src/context/DataContext.tsx", "r", encoding="utf-8") as f:
    dc = f.read()

# PeriodReconciliationInput fix
# We see around line 7310: 
#   dailyDeposits,
#   updateDailyDeposit,
dc = re.sub(r'      dailyDeposits,\n\s*updateDailyDeposit,\n\s*journalEntries,', '      journalEntries,', dc)

# Also fix the duplicate at line 11484
dc = re.sub(r'      dailyDeposits,\n\s*dailyDeposits,\n', '      dailyDeposits,\n', dc)
dc = re.sub(r'      addDailyDeposit,\n\s*addDailyDeposit,\n', '      addDailyDeposit,\n', dc)
dc = re.sub(r'      updateDailyDeposit,\n\s*updateDailyDeposit,\n', '      updateDailyDeposit,\n', dc)

with open("src/context/DataContext.tsx", "w", encoding="utf-8") as f:
    f.write(dc)

