import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs, query, where, orderBy, limit } from "firebase/firestore";
import fs from "fs";

const firebaseConfig = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf-8'));

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || "(default)");

async function check() {
  console.log("Checking historical records...");
  const q = query(collection(db, "historicalRecords"), where("entityType", "==", "TENANT"));
  const snapshot = await getDocs(q);
  console.log("Historical tenants found:", snapshot.size);
  snapshot.forEach(doc => {
    console.log(doc.id, doc.data());
  });

  console.log("Checking audit logs...");
  const q2 = query(collection(db, "auditLogs"), where("entityType", "==", "TENANT"), orderBy("createdAt", "desc"), limit(50));
  const snapshot2 = await getDocs(q2);
  console.log("Audit logs for tenants:", snapshot2.size);
  snapshot2.forEach(doc => {
    const data = doc.data();
    if (data.action === "UPDATE" && data.details && data.details.includes("Updated existing tenant profile")) {
       console.log(data.createdAt, data.entityId, data.entityName, data.details);
    }
  });
  process.exit(0);
}

check();
