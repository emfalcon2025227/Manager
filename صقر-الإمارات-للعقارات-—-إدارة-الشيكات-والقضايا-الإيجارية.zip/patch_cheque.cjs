const fs = require('fs');
let code = fs.readFileSync('src/components/cheques/AddChequeModal.tsx', 'utf8');

// Add import
const importInsertion = `
import { SmartDocumentCaptureModal } from "../ai/SmartDocumentCaptureModal";
import { ExtractionResult, ChequeExtractionResult } from "../../types/documentIntelligence";
`;
code = code.replace(/import { ScannerModal } from "\.\/ScannerModal";/, importInsertion + '\nimport { ScannerModal } from "./ScannerModal";');

// Add state
const stateInsertion = `
  const [isSmartCaptureOpen, setIsSmartCaptureOpen] = useState(false);
`;
code = code.replace(/const \[isScannerModalOpen, setIsScannerModalOpen\] = useState\(false\);/, "const [isScannerModalOpen, setIsScannerModalOpen] = useState(false);\n" + stateInsertion);

// Add smart capture handler
const handlerInsertion = `
  const handleSmartCaptureApprove = (result: any, imageBase64: string, mimeType: string) => {
    setIsSmartCaptureOpen(false);
    
    // Set preview
    setOcrImagePreview(imageBase64);
    setOcrConfidence(result.confidenceThresholdMet ? 0.95 : 0.7);
    setOcrFeedback("Extracted via Smart Document Capture");
    
    // Populate form fields
    if (result.chequeNumber?.value) {
      const cleanNum = String(result.chequeNumber.value).replace(/\\D/g, "");
      setChequeNumber(cleanNum || String(result.chequeNumber.value));
    }
    if (result.bankName?.value) setBankName(result.bankName.value);
    if (result.amountNumeric?.value) {
      const parsedAmount = typeof result.amountNumeric.value === "number" ? result.amountNumeric.value : parseFloat(String(result.amountNumeric.value).replace(/[^0-9.]/g, ""));
      if (!isNaN(parsedAmount) && parsedAmount > 0) {
        setAmount(parsedAmount);
      }
    } else if (result.amount?.value) {
      const parsedAmount = typeof result.amount.value === "number" ? result.amount.value : parseFloat(String(result.amount.value).replace(/[^0-9.]/g, ""));
      if (!isNaN(parsedAmount) && parsedAmount > 0) setAmount(parsedAmount);
    }
    
    if (result.chequeDate?.value) setChequeDate(result.chequeDate.value);
    if (result.dueDate?.value) setDueDate(result.dueDate.value);
    if (result.drawer?.value) setDrawerName(result.drawer.value);
    if (result.accountNumber?.value) setBankAccountNumber(result.accountNumber.value);
    if (result.returnReason?.value) setReturnReason(result.returnReason.value as any);
  };
`;
code = code.replace(/const handleSaveAttempt = \(e\?: React\.FormEvent\) => \{/, handlerInsertion + "\n  const handleSaveAttempt = (e?: React.FormEvent) => {");

// Replace UI section in OCR Mode
const oldUiRegex = /<div className="flex flex-wrap items-center justify-center gap-2 pt-1">[\s\S]*?<\/div>[\s\S]*?\{\/\* Quick Sample Cheque Fillers \*\/\}/;

const newUi = `<div className="flex flex-wrap items-center justify-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsSmartCaptureOpen(true)}
                disabled={ocrLoading}
                className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-sm font-bold shadow-sm transition-colors cursor-pointer w-full max-w-sm justify-center"
              >
                <Sparkles className="w-5 h-5" />
                <span>{language === "ar" ? "✨ مسح باستخدام الالتقاط الذكي" : "✨ Scan with Smart Capture"}</span>
              </button>
            </div>

            {/* Quick Sample Cheque Fillers */}`;

code = code.replace(oldUiRegex, newUi);

// Add Modal element at bottom
const modalElement = `
      {/* Smart Capture Modal */}
      <SmartDocumentCaptureModal
        isOpen={isSmartCaptureOpen}
        onClose={() => setIsSmartCaptureOpen(false)}
        documentType="CHEQUE"
        onApprove={handleSmartCaptureApprove}
      />
`;

code = code.replace(/<\/Modal>/, "</Modal>\n" + modalElement);

fs.writeFileSync('src/components/cheques/AddChequeModal.tsx', code);
console.log('patched AddChequeModal');
