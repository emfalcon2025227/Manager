const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

code = code.replace(
  /console.error\("\[Gemini AI\] Attempt 1 Error with model", model, ":", err.message \|\| err\);/g,
  `if (err.message !== "GEMINI_AUTH_UNAUTHORIZED" && (!err.status || err.status !== 401)) {
    console.error("[Gemini AI] Attempt 1 Error with model", model, ":", err.message || err);
  }`
);

fs.writeFileSync('server.ts', code, 'utf-8');
console.log("Patched server.ts console.error");
