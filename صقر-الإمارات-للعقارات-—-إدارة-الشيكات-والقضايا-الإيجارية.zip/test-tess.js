import { createWorker } from "tesseract.js";
async function run() {
  try {
    const worker = await createWorker("eng", 1, { cachePath: "/tmp" });
    console.log("Worker created");
    await worker.terminate();
  } catch (e) {
    console.error("Crash:", e);
  }
}
run();
