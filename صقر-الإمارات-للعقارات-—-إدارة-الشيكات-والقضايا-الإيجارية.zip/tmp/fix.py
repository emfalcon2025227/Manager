with open("src/components/master/LeaseEditorModal.tsx", "r", encoding="utf-8") as f:
    text = f.read()

start_idx = text.find("{tenantFeeEnabled && (() => {")
next_section = text.find("{/* EXEMPTION UI */}", start_idx)
if next_section == -1:
    next_section = text.find("tenantAdminFeeExempt", start_idx)

print("start_idx:", start_idx, "next_section:", next_section)

new_tenant_block = """{tenantFeeEnabled && (() => {
                          const total = tenantFeeBasis === "PERCENTAGE_OF_RENT"
                            ? Math.round((Number(annualRent || 0) * Number(tenantFeeRate || 0)) / 100)
                            : Number(tenantFeeFixed || 0);
                          
                          const currentPolicy = {
                            tenant: {
                              isExempt: tenantAdminFeeExempt,
                              exemptionReason: tenantAdminFeeExemptionReason,
                              exemptionNote: tenantAdminFeeExemptionNote,
                              approvalStatus: tenantAdminFeeApproved ? ("APPROVED" as const) : ("PENDING" as const)
                            }
                          };

                          const summary = calculateCommissionAmount(
                            tenantFeeBasis === "PERCENTAGE_OF_RENT" ? Number(annualRent || 0) : total * 100 / (Number(tenantFeeRate) || 5),
                            "TENANT",
                            tenantFeeBasis === "PERCENTAGE_OF_RENT" ? Number(tenantFeeRate) : (total / (Number(annualRent) || 1) * 100),
                            DEFAULT_COMMISSION_SETTINGS,
                            "ADMIN_FEE",
                            startDate || new Date().toISOString(),
                            vatRates,
                            owners,
                            tenants,
                            tenantId,
                            currentPolicy
                          );

                          return (
                            <div className="space-y-2 text-xs">
                              <div className="flex gap-2">
                                <div className="flex-1">
                                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">{language === "ar" ? "طريقة الاحتساب" : "Basis"}</label>
                                  <select
                                    value={tenantFeeBasis}
                                    onChange={(e) => setTenantFeeBasis(e.target.value as any)}
                                    className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[11px] font-bold outline-none"
                                  >
                                    <option value="PERCENTAGE_OF_RENT">{language === "ar" ? "نسبة (%)" : "Rate (%)"}</option>
                                    <option value="FIXED_AMOUNT">{language === "ar" ? "ثابت (AED)" : "Fixed (AED)"}</option>
                                  </select>
                                </div>
                                <div className="flex-1">
                                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">
                                    {tenantFeeBasis === "PERCENTAGE_OF_RENT" ? (language === "ar" ? "النسبة (%)" : "Rate (%)") : (language === "ar" ? "المبلغ" : "Amount")}
                                  </label>
                                  <input
                                    type="number"
                                    value={tenantFeeBasis === "PERCENTAGE_OF_RENT" ? tenantFeeRate : tenantFeeFixed}
                                    onChange={(e) => {
                                      if (tenantFeeBasis === "PERCENTAGE_OF_RENT") setTenantFeeRate(e.target.value);
                                      else setTenantFeeFixed(e.target.value);
                                    }}
                                    className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[11px] font-mono font-bold outline-none"
                                  />
                                </div>
                              </div>

                              <div className="flex items-center justify-between">
                                <div>
                                  <label className="block text-[10px] font-semibold text-slate-500 mb-0.5">{language === "ar" ? "تاريخ الاستحقاق" : "Due Date"}</label>
                                  <input
                                    type="date"
                                    value={tenantFeeDueDate}
                                    onChange={(e) => setTenantFeeDueDate(e.target.value)}
                                    className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[11px] font-mono outline-none"
                                  />
                                </div>
                                
                                {/* Policy Source Badge */}
                                <div className="text-right">
                                  <label className="block text-[10px] font-semibold text-slate-400 mb-0.5">{language === "ar" ? "مصدر السياسة" : "Policy Source"}</label>
                                  <span className={`text-[9px] px-1.5 py-0.5 rounded font-black uppercase ${
                                    summary.isExempt ? 'bg-amber-100 text-amber-700' : 
                                    summary.rate !== Number(tenantFeeRate) ? 'bg-slate-100 text-slate-600' : 'bg-emerald-100 text-emerald-700'
                                  }`}>
                                    {summary.isExempt ? (language === "ar" ? "إعفاء معتمد" : "Approved Exemption") : 
                                     (tenantFeeBasis === "FIXED_AMOUNT" ? (language === "ar" ? "إدخال يدوي" : "Manual Entry") : 
                                     (language === "ar" ? "سياسة مطبقة" : "Applied Policy"))}
                                  </span>
                                </div>
                              </div>

                              {/* Summary Box */}
                              <div className="p-2 bg-emerald-50/80 rounded-lg border border-emerald-200 text-[11px] space-y-1">
                                <div className="flex justify-between">
                                  <span>{language === "ar" ? "إجمالي الرسوم:" : "Gross Fee:"}</span>
                                  <span className="font-mono font-bold text-slate-900">{summary.amount.toLocaleString()} AED</span>
                                </div>
                                <div className="flex justify-between text-[10px] text-amber-800">
                                  <span>{language === "ar" ? `الضريبة (${summary.vatRate}%):` : `VAT (${summary.vatRate}%):`}</span>
                                  <span className="font-mono font-bold">{summary.vatAmount.toLocaleString()} AED</span>
                                </div>
                                <div className="flex justify-between text-[10px] text-emerald-800 border-t border-emerald-200/60 pt-1 font-bold">
                                  <span>{language === "ar" ? "صافي الدخل:" : "Net Revenue:"}</span>
                                  <span className="font-mono">{summary.netRevenue.toLocaleString()} AED</span>
                                </div>
                              </div>
                            </div>
                          );
                        })()}
                        
                        """

if start_idx != -1 and next_section != -1:
    updated = text[:start_idx] + new_tenant_block + text[next_section:]
    with open("src/components/master/LeaseEditorModal.tsx", "w", encoding="utf-8") as f:
        f.write(updated)
    print("Successfully replaced tenant fee block!")
else:
    print("Error finding boundaries")
