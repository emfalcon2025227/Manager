import re
with open('src/context/DataContext.tsx', 'r') as f:
    text = f.read()

text = text.replace(
    'const collectDeferredPayment = (params: {',
    'const collectDeferredPayment = async (params: {'
)
text = text.replace(
    'const allocatePaymentToTargets = (params: {',
    'const allocatePaymentToTargets = async (params: {'
)

with open('src/context/DataContext.tsx', 'w') as f:
    f.write(text)
