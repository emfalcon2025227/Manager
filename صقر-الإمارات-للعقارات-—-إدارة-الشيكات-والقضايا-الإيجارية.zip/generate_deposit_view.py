import os

content = """import React, { useState, useMemo, useEffect } from "react";
import {
  Wallet,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Search,
  Filter,
  Plus,
  Upload,
  FileText,
  Lock,
  X,
  Printer,
  Check,
  Building2,
  ArrowUpRight,
  ShieldAlert,
  RotateCcw,
  Eye,
  ExternalLink,
  ShieldCheck,
  DollarSign
} from "lucide-react";
import { useData } from "../../context/DataContext";
import { useLanguage } from "../../context/LanguageContext";
import { useAuth } from "../../context/AuthContext";
import { DailyDepositRecord, CollectionRecord } from "../../types";
import { SearchableSelect } from "../common/SearchableSelect";

export const DailyDepositsControlCenterView: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === "ar";
  const { currentUser, hasPermission } = useAuth();
  
  const {
    dailyDeposits,
    addDailyDeposit,
    updateDailyDeposit,
    collections,
    ownerTransfers,
    owners,
    tenants,
    archive,
    addArchiveItem
  } = useData();

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>("ALL");
  const [isNewDepositModalOpen, setIsNewDepositModalOpen] = useState(false);
  
  const todayStr = new Date().toISOString().split("T")[0];

  // New Deposit Form State
  const [newDepositDate, setNewDepositDate] = useState(todayStr);
  const [newAmount, setNewAmount] = useState<number | "">("");
  const [newSourceType, setNewSourceType] = useState<"COLLECTION" | "OWNER_TRANSFER">("COLLECTION");
  const [newSourceId, setNewSourceId] = useState("");
  const [newBank, setNewBank] = useState("");
  const [newBankAccount, setNewBankAccount] = useState("");
  const [newDepositReference, setNewDepositReference] = useState("");
  const [newDepositType, setNewDepositType] = useState<"CASH" | "CHEQUE" | "BANK_TRANSFER" | "OTHER">("CASH");
  const [newNotes, setNewNotes] = useState("");
  const [depositError, setDepositError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Selected source item details
  const selectedSourceItem = useMemo(() => {
    if (!newSourceId) return null;
    if (newSourceType === "COLLECTION") return collections.find(c => c.id === newSourceId);
    if (newSourceType === "OWNER_TRANSFER") return ownerTransfers.find(o => o.id === newSourceId);
    return null;
  }, [newSourceId, newSourceType, collections, ownerTransfers]);

  useEffect(() => {
    if (selectedSourceItem) {
      if (newSourceType === "COLLECTION") {
        setNewAmount((selectedSourceItem as CollectionRecord).amountApplied);
      } else {
        setNewAmount((selectedSourceItem as any).amount);
      }
    }
  }, [selectedSourceItem, newSourceType]);

  const filteredDeposits = useMemo(() => {
    return dailyDeposits.filter((d) => {
      if (selectedStatusFilter !== "ALL" && d.status !== selectedStatusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          d.id.toLowerCase().includes(q) ||
          d.depositReference.toLowerCase().includes(q) ||
          d.bank.toLowerCase().includes(q) ||
          d.bankAccount.toLowerCase().includes(q) ||
          (d.sourceId && d.sourceId.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [dailyDeposits, selectedStatusFilter, searchQuery]);

  const handleCreateDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDepositError("");
    
    if (!newSourceId) {
      setDepositError(isAr ? "يرجى اختيار الحركة المالية المرتبطة." : "Please select the related financial movement.");
      return;
    }
    
    if (!newAmount || Number(newAmount) <= 0) {
      setDepositError(isAr ? "مبلغ الإيداع غير صحيح." : "Invalid deposit amount.");
      return;
    }
    
    if (!newBank || !newBankAccount || !newDepositReference) {
      setDepositError(isAr ? "يرجى تعبئة جميع بيانات البنك والمرجع." : "Please fill all bank and reference details.");
      return;
    }
    
    // Validate amount matches source
    let expectedAmount = 0;
    if (newSourceType === "COLLECTION") {
      const col = collections.find(c => c.id === newSourceId);
      expectedAmount = col?.amountApplied || 0;
    } else {
      const trans = ownerTransfers.find(t => t.id === newSourceId);
      expectedAmount = trans?.amount || 0;
    }
    
    if (Number(newAmount) > expectedAmount) {
      setDepositError(isAr ? "مبلغ الإيداع لا يمكن أن يتجاوز قيمة الحركة المالية." : "Deposit amount cannot exceed financial movement amount.");
      return;
    }
    
    // Duplicate reference check
    const existingRef = dailyDeposits.find(d => d.depositReference === newDepositReference);
    if (existingRef) {
      setDepositError(isAr ? "تم اكتشاف رقم إيداع بنكي مكرر." : "Duplicate bank deposit reference detected.");
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const res = await addDailyDeposit({
        depositDate: newDepositDate,
        transactionDate: todayStr,
        amount: Number(newAmount),
        paymentSource: newSourceType,
        sourceId: newSourceId,
        bank: newBank,
        bankAccount: newBankAccount,
        depositReference: newDepositReference,
        depositType: newDepositType,
        notes: newNotes,
        proofStatus: "MISSING",
        reconciliationStatus: "UNRECONCILED",
        status: "DRAFT",
      });
      
      if (res.success) {
        setIsNewDepositModalOpen(false);
        // Reset form
        setNewSourceId("");
        setNewAmount("");
        setNewBank("");
        setNewBankAccount("");
        setNewDepositReference("");
        setNewNotes("");
      } else {
        setDepositError(res.error || "Failed to create deposit");
      }
    } catch (err: any) {
      setDepositError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const collectionOptions = collections
    .filter(c => !dailyDeposits.some(d => d.sourceId === c.id))
    .map(c => ({
      id: c.id,
      label: `${c.receiptNumber} - ${c.payerName} (AED ${c.amountApplied})`,
      subLabel: isAr ? `التاريخ: ${c.paymentDate}` : `Date: ${c.paymentDate}`
    }));

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Wallet className="w-7 h-7 text-emerald-600" />
            {isAr ? "مركز الإيداعات اليومية" : "Daily Deposits Control Center"}
          </h2>
          <p className="text-slate-500 mt-1">
            {isAr
              ? "إدارة ومراقبة وتسوية الإيداعات البنكية المباشرة"
              : "Manage, monitor, and reconcile direct bank deposits"}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsNewDepositModalOpen(true)}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer">
            <Plus className="w-4 h-4" />
            <span>{isAr ? "تسجيل إيداع جديد" : "New Deposit"}</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 bg-emerald-100 rounded-xl text-emerald-700">
              <DollarSign className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold text-slate-700">{isAr ? "إجمالي الإيداعات" : "Total Deposits"}</h3>
          </div>
          <p className="text-2xl font-bold text-slate-900">AED {dailyDeposits.reduce((acc, d) => acc + d.amount, 0).toLocaleString()}</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 bg-amber-100 rounded-xl text-amber-700">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold text-slate-700">{isAr ? "قيد المراجعة" : "Pending Review"}</h3>
          </div>
          <p className="text-2xl font-bold text-slate-900">{dailyDeposits.filter(d => d.status === "SUBMITTED").length}</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 bg-blue-100 rounded-xl text-blue-700">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold text-slate-700">{isAr ? "تم التسوية" : "Reconciled"}</h3>
          </div>
          <p className="text-2xl font-bold text-slate-900">{dailyDeposits.filter(d => d.status === "RECONCILED").length}</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-rose-200 shadow-xs">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 bg-rose-100 rounded-xl text-rose-700">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold text-slate-700">{isAr ? "استثناءات" : "Exceptions"}</h3>
          </div>
          <p className="text-2xl font-bold text-slate-900">{dailyDeposits.filter(d => d.status === "EXCEPTION").length}</p>
        </div>
      </div>
      
      {/* Search & Filters */}
      <div className="flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className={`absolute ${isAr ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? "ابحث برقم الإيداع، المرجع البنكي..." : "Search by deposit ID, bank ref..."}
            className={`w-full ${isAr ? "pr-9 pl-4" : "pl-9 pr-4"} py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500`}
          />
        </div>
        <div className="w-full md:w-48">
          <select
            value={selectedStatusFilter}
            onChange={(e) => setSelectedStatusFilter(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="ALL">{isAr ? "جميع الحالات" : "All Statuses"}</option>
            <option value="DRAFT">{isAr ? "مسودة" : "Draft"}</option>
            <option value="SUBMITTED">{isAr ? "مقدم للمراجعة" : "Submitted"}</option>
            <option value="VERIFIED">{isAr ? "تم التحقق" : "Verified"}</option>
            <option value="RECONCILED">{isAr ? "تم التسوية" : "Reconciled"}</option>
            <option value="EXCEPTION">{isAr ? "استثناء" : "Exception"}</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-xs font-bold text-slate-500">{isAr ? "التاريخ" : "Date"}</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-500">{isAr ? "المرجع البنكي" : "Bank Ref"}</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-500">{isAr ? "البنك" : "Bank"}</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-500">{isAr ? "الارتباط" : "Related"}</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-500">{isAr ? "المبلغ" : "Amount"}</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-500">{isAr ? "الإثبات" : "Proof"}</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-500">{isAr ? "الحالة" : "Status"}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDeposits.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500 text-sm">
                    {isAr ? "لا توجد إيداعات مطابقة" : "No deposits found"}
                  </td>
                </tr>
              ) : (
                filteredDeposits.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3 text-sm text-slate-900 font-medium">
                      {d.depositDate}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600 font-mono">
                      {d.depositReference}
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-sm font-semibold text-slate-900">{d.bank}</div>
                      <div className="text-xs text-slate-500 font-mono">{d.bankAccount}</div>
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-600">
                      {d.paymentSource} <br />
                      <span className="text-xs text-slate-400 font-mono">{d.sourceId.substring(0, 8)}...</span>
                    </td>
                    <td className="px-4 py-3 text-sm font-bold text-slate-900">
                      AED {d.amount.toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      {d.proofStatus === "MISSING" ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-rose-600 bg-rose-50 px-2 py-1 rounded-md">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          {isAr ? "مفقود" : "Missing"}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {isAr ? "مرفق" : "Uploaded"}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold ${
                        d.status === "RECONCILED" ? "bg-emerald-100 text-emerald-800" :
                        d.status === "VERIFIED" ? "bg-blue-100 text-blue-800" :
                        d.status === "SUBMITTED" ? "bg-amber-100 text-amber-800" :
                        d.status === "EXCEPTION" ? "bg-rose-100 text-rose-800" :
                        "bg-slate-100 text-slate-800"
                      }`}>
                        {d.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* New Deposit Modal */}
      {isNewDepositModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-6 shadow-xl animate-in zoom-in duration-200">
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Wallet className="w-5 h-5 text-emerald-600" />
                {isAr ? "تسجيل إيداع جديد" : "Register New Deposit"}
              </h3>
              <button onClick={() => setIsNewDepositModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {depositError && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{depositError}</span>
              </div>
            )}
            
            <form onSubmit={handleCreateDeposit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "مصدر الحركة" : "Source Type"}</label>
                  <select
                    value={newSourceType}
                    onChange={(e) => {
                      setNewSourceType(e.target.value as any);
                      setNewSourceId("");
                      setNewAmount("");
                    }}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="COLLECTION">{isAr ? "تحصيل" : "Collection"}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "تاريخ الإيداع" : "Deposit Date"}</label>
                  <input
                    type="date"
                    required
                    value={newDepositDate}
                    onChange={(e) => setNewDepositDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "الحركة المالية المرتبطة" : "Related Financial Movement"}</label>
                <SearchableSelect
                  options={collectionOptions}
                  value={newSourceId}
                  onChange={setNewSourceId}
                  placeholder={isAr ? "ابحث برقم الإيصال أو اسم الدافع..." : "Search receipt or payer..."}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "مبلغ الإيداع (AED)" : "Deposit Amount (AED)"}</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={newAmount}
                    onChange={(e) => setNewAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "نوع الإيداع" : "Deposit Type"}</label>
                  <select
                    value={newDepositType}
                    onChange={(e) => setNewDepositType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="CASH">{isAr ? "نقدي" : "Cash"}</option>
                    <option value="CHEQUE">{isAr ? "شيك" : "Cheque"}</option>
                    <option value="BANK_TRANSFER">{isAr ? "تحويل بنكي" : "Bank Transfer"}</option>
                    <option value="OTHER">{isAr ? "أخرى" : "Other"}</option>
                  </select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "البنك المودع فيه" : "Deposit Bank"}</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ADCB"
                    value={newBank}
                    onChange={(e) => setNewBank(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "رقم الحساب البنكي" : "Bank Account"}</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 123456789"
                    value={newBankAccount}
                    onChange={(e) => setNewBankAccount(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "المرجع البنكي" : "Bank Reference"}</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. REF-12345"
                  value={newDepositReference}
                  onChange={(e) => setNewDepositReference(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{isAr ? "ملاحظات إضافية" : "Notes"}</label>
                <textarea
                  rows={2}
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                />
              </div>
              
              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsNewDepositModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 text-sm font-bold transition-colors cursor-pointer"
                >
                  {isAr ? "إلغاء" : "Cancel"}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold transition-colors shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Check className="w-4 h-4" />
                  )}
                  <span>{isAr ? "حفظ كمسودة" : "Save as Draft"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
