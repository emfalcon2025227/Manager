#!/bin/bash
while true; do
  if grep -q "error TS" tsc_out.txt 2>/dev/null; then
    break
  fi
  sleep 1
done
